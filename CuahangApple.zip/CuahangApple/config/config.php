<?php
/**
 * Application Configuration
 */

// Base URL
define('BASE_URL', 'http://localhost/CuahangApple/');

// Paths
define('ROOT_PATH', dirname(__DIR__));
define('ASSETS_PATH', BASE_URL . 'assets/');
define('UPLOAD_PATH', ROOT_PATH . '/assets/images/products/');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'apple_store');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application Settings
define('APP_NAME', 'CỬA HÀNG APPLE');
define('ITEMS_PER_PAGE', 12);
define('FEATURED_PRODUCTS_LIMIT', 6);

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour

// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-password');

// Security
define('ENCRYPTION_KEY', 'your-secret-encryption-key');
define('JWT_SECRET', 'your-jwt-secret-key');

// Timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Error Reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);


