<?php require_once __DIR__ . '/../includes/header.php'; ?>

<!-- Carousel/Slider -->
<div id="slides" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
        <li data-target="#slides" data-slide-to="0" class="active"></li>
        <li data-target="#slides" data-slide-to="1"></li>
        <li data-target="#slides" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="intro-slide" src="https://cdnb.artstation.com/p/assets/images/images/016/802/459/large/shuja-shuaib-banner.jpg?1553535424" alt="banner">
            <div class="carousel-caption d-none d-md-block">
                <p class="font-weight-bold">Chào mừng đến với trang web!</p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="intro-slide" src="https://i.ytimg.com/vi/vMVwdSp489E/maxresdefault.jpg" alt="banner">
            <div class="carousel-caption d-none d-md-block">
                <p class="font-weight-bold">Sản phẩm chất lượng cao</p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="intro-slide" src="https://i.ytimg.com/vi/KpI-QDbrf0Y/maxresdefault.jpg" alt="banner">
            <div class="carousel-caption d-none d-md-block">
                <p class="font-weight-bold">Liên hệ ngay hôm nay</p>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <!-- Popular Categories -->
    <h2>Danh mục phổ biến</h2>
    <div class="category-container">
        <?php foreach ($popularCategories as $category): ?>
            <a style="text-decoration: none;" href="<?= BASE_URL ?>index.php?navigate=search1&category_id=<?= $category['category_id'] ?>">
                <div class="category-item">
                  <img src="<?= BASE_URL ?>assets/images/categories/<?= $category['category_id'] ?>.png"
     alt="<?= e($category['category_name']) ?>"
     onerror="this.onerror=null; this.src='<?= BASE_URL ?>assets/images/categories/default.jpg';">
                    <?= e($category['category_name']) ?> (<?= $category['product_count'] ?> sản phẩm)
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Featured Products -->
    <h2>Top sản phẩm nổi bật</h2>
    <div class="product-list">
        <?php foreach ($featuredProducts as $product): 
            $discountedPrice = getDiscountedPrice($product['price'], $product['discount_percent']);
        ?>
            <a href="<?= BASE_URL ?>index.php?navigate=product_info&product_id=<?= $product['product_id'] ?>">
                <div class="product-card">
                    <?php if ($product['discount_percent'] > 0): ?>
                        <div class="discount-badge">-<?= $product['discount_percent'] ?>%</div>
                    <?php endif; ?>
                    
                    <img src="<?= getProductImage($product['image']) ?>" 
                         alt="<?= e($product['product_name']) ?>">
                    
                    <p><strong><?= e($product['product_name']) ?></strong></p>
                    
                    <?php if ($product['discount_percent'] > 0): ?>
                        <p><del><?= formatCurrency($product['price']) ?></del></p>
                        <p><span><?= formatCurrency($discountedPrice) ?></span></p>
                    <?php else: ?>
                        <p><span><?= formatCurrency($product['price']) ?></span></p>
                    <?php endif; ?>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- Category Products Section -->
<div class="container">
    <h2>Danh mục sản phẩm</h2>
    
    <!-- Category Bar -->
    <div class="category-bar">
        <?php foreach ($categories as $category): ?>
            <a href="<?= BASE_URL ?>index.php?navigate=search1&category_id=<?= $category['category_id'] ?>">
                <button><?= e($category['category_name']) ?></button>
            </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Main Content with Products and Banner -->
    <div class="main-content">
        <!-- Latest Products -->
        <div style="flex:2;">
            <div class="product-grid">
                <?php foreach ($latestProducts as $product): 
                    $discountedPrice = getDiscountedPrice($product['price'], $product['discount_percent']);
                ?>
                    <a style="text-decoration: none;" href="<?= BASE_URL ?>index.php?navigate=product_info&product_id=<?= $product['product_id'] ?>">
                        <div class="product-card">
                            <?php if ($product['discount_percent'] > 0): ?>
                                <div class="discount-badge">-<?= $product['discount_percent'] ?>%</div>
                            <?php endif; ?>
                            
                            <img src="<?= getProductImage($product['image']) ?>" 
                                 alt="<?= e($product['product_name']) ?>">                            <div class="product-title"><?= e($product['product_name']) ?></div>
                            
                            <?php if ($product['discount_percent'] > 0): ?>
                                <div class="old-price"><?= formatCurrency($product['price']) ?></div>
                            <?php endif; ?>
                            
                            <div class="product-price"><?= formatCurrency($discountedPrice) ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Banner -->
        <div class="banner">
            <img src="<?= BASE_URL ?>assets/images/products/image.png" alt="Banner quảng cáo">
        </div>
    </div>
</div>

<!-- About Section -->
<section class="section-1">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-6 col-12">
                <div class="pray">
                    <img src="https://cdn.tgdd.vn/Files/2022/01/17/1411356/cuahangtopzone-760x367.jpg"
                         alt="Store" class="img-fluid"/>
                </div>
            </div>
            <div class="col-md-6 col-12">
                <div class="panel text-left">
                    <h1>Cửa hàng Apple</h1>
                    <p class="pt-4">
                        Chào mừng bạn đến với cửa hàng công nghệ trực tuyến của chúng tôi,
                        nơi thế giới công nghệ trở nên sống động.
                        Chúng tôi cung cấp các sản phẩm Apple chính hãng với chất lượng cao nhất.
                    </p>
                    <p>
                        Khám phá, trải nghiệm và để công nghệ phục vụ cuộc sống của bạn.
                        Với giao diện thân thiện với người dùng và đặt hàng dễ dàng,
                        sản phẩm yêu thích của bạn chỉ là một cú nhấp chuột.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="section-4">
    <div class="container text-center">
        <h1 class="text-dark">Khách hàng nói gì về chúng tôi</h1>
        <p class="font-italic">Phản hồi từ khách hàng trung thành của chúng tôi</p>
    </div>
    <div class="team row">
        <div class="col-md-4 col-12 text-center">
            <div class="card mr-2 d-inline-block shadow-lg">
                <div class="card-img-top">
                    <img src="<?= BASE_URL ?>assets/images/banners/feedback1.jpg" class="img-fluid p-4" alt=""/>
                </div>
                <div class="card-body">
                    <h3 class="card-title">Quan Lam</h3>
                    <p class="card-text">
                        "Tôi thực sự hài lòng với trang web này! Giao diện người dùng dễ điều hướng,
                        và tìm sản phẩm thật nhanh chóng và đơn giản."
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12 text-center">
            <div class="card mr-2 d-inline-block shadow-lg">
                <div class="card-img-top">
                    <img src="<?= BASE_URL ?>assets/images/banners/feedback2.jpg" class="img-fluid p-4" alt=""/>
                </div>
                <div class="card-body">
                    <h3 class="card-title">Trung</h3>
                    <p class="card-text">
                        "Dịch vụ khách hàng tuyệt vời.
                        Họ đã giúp tôi giải quyết vấn đề với đơn đặt hàng một cách nhanh chóng và chuyên nghiệp."
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12 text-center">
            <div class="card mr-2 d-inline-block shadow-lg">
                <div class="card-img-top">
                    <img src="<?= BASE_URL ?>assets/images/banners/feedback4.jpg" class="img-fluid p-4" alt=""/>
                </div>
                <div class="card-body">
                    <h3 class="card-title">Giáp Nguyễn</h3>
                    <p class="card-text">
                        "Giao hàng nhanh và đóng gói cẩn thận.
                        Sản phẩm đến trong tình trạng tốt, không bị hư hại gì."
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>


