<?php 
require_once __DIR__ . '/../../includes/header.php';
$discountedPrice = getDiscountedPrice($product['price'], $product['discount_percent']);
?>

<!-- Custom Styles for Product Detail -->
<style>
    .product-detail-section {
        padding: 40px 0;
        background: #f8f9fa;
    }
    
    .product-image-main {
        position: relative;
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        text-align: center;
    }
    
    .product-image-main img {
        max-width: 100%;
        height: auto;
        border-radius: 10px;
        transition: transform 0.3s ease;
    }
    
    .product-image-main:hover img {
        transform: scale(1.05);
    }
    
    .product-info-card {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        height: 100%;
    }
    
    .product-title-detail {
        font-size: 32px;
        font-weight: 700;
        margin-bottom: 20px;
        color: #1a1a1a;
        line-height: 1.3;
    }
    
    .product-meta {
        display: flex;
        align-items: center;
        gap: 20px;
        padding: 15px 0;
        border-bottom: 1px solid #e9ecef;
        margin-bottom: 20px;
    }
    
    .product-meta .badge {
        font-size: 14px;
        padding: 8px 15px;
    }
    
    .product-meta .views {
        color: #6c757d;
        font-size: 14px;
    }
    
    .product-price-detail {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 25px;
        border-radius: 12px;
        margin-bottom: 30px;
        color: white;
    }
    
    .price-old {
        text-decoration: line-through;
        color: rgba(255,255,255,0.7);
        font-size: 18px;
        margin-bottom: 5px;
    }
    
    .price-new {
        font-size: 38px;
        font-weight: 800;
        color: #fff;
        margin: 10px 0;
    }
    
    .discount-badge-large {
        background: #ff4757;
        color: white;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 16px;
        font-weight: 600;
        display: inline-block;
        margin-bottom: 10px;
    }
    
    .price-save {
        font-size: 16px;
        color: #fff;
        margin-top: 8px;
    }
    
    .stock-status {
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
        margin-bottom: 25px;
    }
    
    .stock-status .badge {
        font-size: 15px;
        padding: 10px 20px;
    }
    
    .quantity-selector {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 20px;
    }
    
    .quantity-selector label {
        font-weight: 600;
        margin-bottom: 0;
    }
    
    .quantity-input {
        display: flex;
        align-items: center;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        overflow: hidden;
    }
    
    .quantity-input button {
        background: #f8f9fa;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    .quantity-input button:hover {
        background: #e9ecef;
    }
    
    .quantity-input input {
        border: none;
        width: 60px;
        text-align: center;
        font-weight: 600;
        padding: 8px;
    }
    
    .btn-add-cart {
        width: 100%;
        padding: 15px;
        font-size: 18px;
        font-weight: 600;
        border-radius: 10px;
        margin-bottom: 15px;
        transition: all 0.3s;
    }
    
    .btn-add-cart:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,123,255,0.3);
    }
    
    .product-description,
    .product-specs {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        margin-top: 20px;
    }
    
    .product-description h4,
    .product-specs h4 {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 15px;
        color: #1a1a1a;
        padding-bottom: 10px;
        border-bottom: 3px solid #007bff;
    }
    
    .related-products {
        padding: 50px 0;
    }
    
    .related-products h3 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 30px;
        text-align: center;
    }
    
    .product-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 25px;
    }
    
    .product-card {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.3s;
        box-shadow: 0 3px 10px rgba(0,0,0,0.08);
    }
    
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    .product-card img {
        width: 100%;
        height: 250px;
        object-fit: cover;
    }
    
    .product-card > div {
        padding: 20px;
    }
    
    .product-card .discount-badge {
        position: absolute;
        top: 10px;
        right: 10px;
        background: #ff4757;
        color: white;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 14px;
    }
    
    .breadcrumb {
        background: white;
        padding: 15px 20px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
</style>

<div class="product-detail-section">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php"><i class="fas fa-home"></i> Trang chủ</a></li>
                <li class="breadcrumb-item">
                    <a href="<?= BASE_URL ?>index.php?navigate=search1&category_id=<?= $product['category_id'] ?>">
                        <?= e($product['category_name']) ?>
                    </a>
                </li>
                <li class="breadcrumb-item active"><?= e($product['product_name']) ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Product Image -->
            <div class="col-lg-5 mb-4">
                <div class="product-image-main">
                    <img src="<?= getProductImage($product['image']) ?>" 
                         alt="<?= e($product['product_name']) ?>" 
                         class="img-fluid">
                </div>
            </div>
            
            <!-- Product Info -->
            <div class="col-lg-7">
                <div class="product-info-card">
                    <h1 class="product-title-detail"><?= e($product['product_name']) ?></h1>
                    
                    <div class="product-meta">
                        <span class="badge badge-primary">
                            <i class="fas fa-tag"></i> <?= e($product['category_name']) ?>
                        </span>
                        <span class="views">
                            <i class="fas fa-eye"></i> <?= number_format($product['views']) ?> lượt xem
                        </span>
                    </div>
                    
                    <div class="product-price-detail">
                        <?php if ($product['discount_percent'] > 0): ?>
                            <span class="discount-badge-large">
                                <i class="fas fa-bolt"></i> GIẢM <?= $product['discount_percent'] ?>%
                            </span>
                            <div class="price-old"><?= formatCurrency($product['price']) ?></div>
                            <div class="price-new"><?= formatCurrency($discountedPrice) ?></div>
                            <div class="price-save">
                                <i class="fas fa-gift"></i> Tiết kiệm: <?= formatCurrency($product['price'] - $discountedPrice) ?>
                            </div>
                        <?php else: ?>
                            <div class="price-new"><?= formatCurrency($product['price']) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Stock Status -->
                    <div class="stock-status">
                        <?php if ($product['stock_quantity'] > 0): ?>
                            <span class="badge badge-success">
                                <i class="fas fa-check-circle"></i> Còn hàng (<?= number_format($product['stock_quantity']) ?> sản phẩm)
                            </span>
                        <?php else: ?>
                            <span class="badge badge-danger">
                                <i class="fas fa-times-circle"></i> Tạm hết hàng
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Add to Cart Form -->
                    <?php if ($product['stock_quantity'] > 0): ?>
                        <form action="<?= BASE_URL ?>index.php?navigate=cart_add" method="POST" id="addToCartForm">
                            <?= Auth::csrfField() ?>
                            <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                            
                            <div class="quantity-selector">
                                <label for="quantity">Số lượng:</label>
                                <div class="quantity-input">
                                    <button type="button" onclick="decreaseQty()">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <input type="number" class="form-control" id="quantity" name="quantity" 
                                           value="1" min="1" max="<?= $product['stock_quantity'] ?>" readonly>
                                    <button type="button" onclick="increaseQty()">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <?php if (Auth::check()): ?>
                                <button type="submit" class="btn btn-primary btn-add-cart">
                                    <i class="fas fa-shopping-cart"></i> THÊM VÀO GIỎ HÀNG
                                </button>
                            <?php else: ?>
                                <a href="<?= BASE_URL ?>index.php?navigate=login" class="btn btn-warning btn-add-cart">
                                    <i class="fas fa-sign-in-alt"></i> ĐĂNG NHẬP ĐỂ MUA HÀNG
                                </a>
                            <?php endif; ?>
                        </form>
                        
                        <?php if (Auth::check() && $product['stock_quantity'] > 0): ?>
                            <!-- Buy Now Form - adds to cart and goes to checkout -->
                            <form action="<?= BASE_URL ?>index.php?navigate=cart_add" method="POST" style="display: inline;">
                                <?= Auth::csrfField() ?>
                                <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                                <input type="hidden" name="quantity" id="buyNowQty" value="1">
                                <input type="hidden" name="buy_now" value="1">
                                <button type="submit" class="btn btn-success btn-add-cart">
                                    <i class="fas fa-bolt"></i> MUA NGAY
                                </button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Product Description -->
        <?php if (!empty($product['description'])): ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="product-description">
                        <h4><i class="fas fa-info-circle"></i> Mô tả sản phẩm</h4>
                        <p style="line-height: 1.8; color: #555;"><?= nl2br(e($product['description'])) ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Specifications -->
        <?php if (!empty($product['specifications'])): ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="product-specs">
                        <h4><i class="fas fa-cog"></i> Thông số kỹ thuật</h4>
                        <p style="line-height: 1.8; color: #555;"><?= nl2br(e($product['specifications'])) ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Related Products -->
<?php if (!empty($relatedProducts)): ?>
    <div class="container">
        <div class="related-products">
            <h3><i class="fas fa-layer-group"></i> Sản phẩm liên quan</h3>
            <div class="product-list">
                <?php foreach ($relatedProducts as $relatedProduct): 
                    $relatedDiscountedPrice = getDiscountedPrice($relatedProduct['price'], $relatedProduct['discount_percent']);
                ?>
                    <a href="<?= BASE_URL ?>index.php?navigate=product_info&product_id=<?= $relatedProduct['product_id'] ?>" style="text-decoration: none; color: inherit;">
                        <div class="product-card">
                            <div style="position: relative;">
                                <?php if ($relatedProduct['discount_percent'] > 0): ?>
                                    <div class="discount-badge">-<?= $relatedProduct['discount_percent'] ?>%</div>
                                <?php endif; ?>
                                
                                <img src="<?= getProductImage($relatedProduct['image']) ?>" 
                                     alt="<?= e($relatedProduct['product_name']) ?>">
                            </div>
                            
                            <div>
                                <p style="font-weight: 600; margin-bottom: 10px; min-height: 45px;">
                                    <?= e($relatedProduct['product_name']) ?>
                                </p>
                                
                                <?php if ($relatedProduct['discount_percent'] > 0): ?>
                                    <p style="text-decoration: line-through; color: #999; margin-bottom: 5px;">
                                        <?= formatCurrency($relatedProduct['price']) ?>
                                    </p>
                                <?php endif; ?>
                                <p style="color: #dc3545; font-size: 20px; font-weight: 700;">
                                    <?= formatCurrency($relatedDiscountedPrice) ?>
                                </p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
    function increaseQty() {
        const qtyInput = document.getElementById('quantity');
        const buyNowQty = document.getElementById('buyNowQty');
        const max = parseInt(qtyInput.getAttribute('max'));
        let currentValue = parseInt(qtyInput.value);
        if (currentValue < max) {
            qtyInput.value = currentValue + 1;
            if (buyNowQty) buyNowQty.value = currentValue + 1;
        }
    }
    
    function decreaseQty() {
        const qtyInput = document.getElementById('quantity');
        const buyNowQty = document.getElementById('buyNowQty');
        let currentValue = parseInt(qtyInput.value);
        if (currentValue > 1) {
            qtyInput.value = currentValue - 1;
            if (buyNowQty) buyNowQty.value = currentValue - 1;
        }
    }
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
