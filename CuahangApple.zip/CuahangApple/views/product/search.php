<?php require_once __DIR__ . '/../../includes/header.php'; ?>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/filters.css">

<div class="container my-4">
    <!-- Header -->
    <div class="search-header mb-4">
        <h2>
            <?php if (!empty($keyword)): ?>
                Kết quả tìm kiếm cho: "<?= e($keyword) ?>"
            <?php elseif ($categoryId != 0): ?>
                <?php
                $currentCat = array_filter($categories, function($cat) use ($categoryId) {
                    return $cat['category_id'] == $categoryId;
                });
                $currentCat = reset($currentCat);
                echo e($currentCat['category_name'] ?? 'Sản phẩm');
                ?>
            <?php else: ?>
                Tất cả sản phẩm
            <?php endif; ?>
        </h2>
        <p class="text-muted mb-0"><?= $totalProducts ?> sản phẩm được tìm thấy</p>
    </div>
    
    <div class="row">
        <!-- Filters Sidebar -->
        <div class="col-lg-3 col-md-4 mb-4">
            <div class="filters-sidebar">
                <div class="filters-header d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">FILTERS</h5>
                    <button type="button" id="clearAllFilters" class="btn btn-link btn-sm p-0">Clear All</button>
                </div>
                
                <!-- Category Filter -->
                <div class="filter-group mb-4">
                    <h6 class="filter-title mb-3">Danh mục</h6>
                    <div class="filter-options">
                        <div class="form-check">
                            <input class="form-check-input category-filter" type="radio" 
                                   name="category" value="0" id="cat_all" 
                                   <?= $categoryId == 0 ? 'checked' : '' ?>>
                            <label class="form-check-label" for="cat_all">
                                Tất cả
                            </label>
                        </div>
                        <?php foreach ($categories as $category): ?>
                        <div class="form-check">
                            <input class="form-check-input category-filter" type="radio" 
                                   name="category" value="<?= $category['category_id'] ?>" 
                                   id="cat_<?= $category['category_id'] ?>"
                                   <?= $categoryId == $category['category_id'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="cat_<?= $category['category_id'] ?>">
                                <?= e($category['category_name']) ?>
                                <small class="text-muted">(<?= $category['product_count'] ?? 0 ?>)</small>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Price Range Filter -->
                <div class="filter-group mb-4">
                    <h6 class="filter-title mb-3">Giá</h6>
                    <div class="filter-options">
                        <?php foreach ($priceRanges as $value => $label): ?>
                        <div class="form-check">
                            <input class="form-check-input price-filter" type="radio" 
                                   name="price_range" value="<?= $value ?>" 
                                   id="price_<?= md5($value) ?>"
                                   <?= $priceRange === $value ? 'checked' : '' ?>>
                            <label class="form-check-label" for="price_<?= md5($value) ?>">
                                <?= $label ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Status Filter -->
                <div class="filter-group mb-4">
                    <h6 class="filter-title mb-3">Trạng thái</h6>
                    <div class="filter-options">
                        <?php foreach ($statusOptions as $value => $label): ?>
                        <div class="form-check">
                            <input class="form-check-input status-filter" type="radio" 
                                   name="status" value="<?= $value ?>" 
                                   id="status_<?= md5($value) ?>"
                                   <?= $status === $value ? 'checked' : '' ?>>
                            <label class="form-check-label" for="status_<?= md5($value) ?>">
                                <?= $label ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Products Content -->
        <div class="col-lg-9 col-md-8">
            <!-- Sort Options -->
            <div class="sort-bar d-flex justify-content-between align-items-center mb-4">
                <div class="sort-options">
                    <label for="sortSelect" class="form-label me-2">Sắp xếp theo:</label>
                    <select class="form-select form-select-sm d-inline-block w-auto" id="sortSelect">
                        <?php foreach ($sortOptions as $value => $label): ?>
                        <option value="<?= $value ?>" <?= $sortBy === $value ? 'selected' : '' ?>>
                            <?= $label ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="view-toggle">
                    <button type="button" class="btn btn-outline-secondary btn-sm active" id="gridView">
                        <i class="fas fa-th"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="listView">
                        <i class="fas fa-list"></i>
                    </button>
                </div>
            </div>
            <!-- Products Grid -->
            <?php if (empty($products)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Không tìm thấy sản phẩm nào phù hợp với bộ lọc của bạn.
                    <br>
                    <small>Hãy thử thay đổi bộ lọc hoặc xóa tất cả bộ lọc để xem thêm sản phẩm.</small>
                </div>
            <?php else: ?>
                <div id="productsContainer" class="products-grid">
                    <?php foreach ($products as $product): 
                        $discountedPrice = getDiscountedPrice($product['price'], $product['discount_percent']);
                        $finalPrice = $product['final_price'] ?? $discountedPrice;
                    ?>
                        <div class="product-item">
                            <a href="<?= BASE_URL ?>index.php?navigate=product_info&product_id=<?= $product['product_id'] ?>" 
                               class="product-link">
                                <div class="product-card">
                                    <?php if ($product['discount_percent'] > 0): ?>
                                        <span class="discount-badge">-<?= $product['discount_percent'] ?>%</span>
                                    <?php endif; ?>
                                    
                                    <?php if ($product['stock_quantity'] <= 0): ?>
                                        <span class="stock-badge out-of-stock">Hết hàng</span>
                                    <?php elseif ($product['stock_quantity'] <= 5): ?>
                                        <span class="stock-badge low-stock">Sắp hết</span>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($product['is_featured'])): ?>
                                        <span class="featured-badge">Nổi bật</span>
                                    <?php endif; ?>
                                    
                                    <div class="product-image">
                                        <img src="<?= getProductImage($product['image']) ?>"
                                             alt="<?= e($product['product_name']) ?>"
                                             loading="lazy">
                                    </div>
                                    
                                    <div class="product-info">
                                        <h6 class="product-title"><?= e($product['product_name']) ?></h6>
                                        
                                        <div class="product-category">
                                            <small class="text-muted"><?= e($product['category_name']) ?></small>
                                        </div>
                                        
                                        <div class="product-pricing">
                                            <?php if ($product['discount_percent'] > 0): ?>
                                                <span class="old-price"><?= formatCurrency($product['price']) ?></span>
                                            <?php endif; ?>
                                            <span class="current-price"><?= formatCurrency($finalPrice) ?></span>
                                        </div>
                                        
                                        <div class="product-actions">
                                            <button type="button" class="btn btn-primary btn-sm add-to-cart-btn" 
                                                    data-product-id="<?= $product['product_id'] ?>"
                                                    <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                                <i class="fas fa-shopping-cart"></i>
                                                <?= $product['stock_quantity'] <= 0 ? 'Hết hàng' : 'Thêm vào giỏ' ?>
                                            </button>
                                            <button type="button" class="btn btn-outline-secondary btn-sm wishlist-btn" 
                                                    data-product-id="<?= $product['product_id'] ?>">
                                                <i class="far fa-heart"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center" id="pagination">
                            <?php if ($currentPage > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="#" data-page="<?= $currentPage - 1 ?>">
                                        <i class="fas fa-chevron-left"></i> Trước
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php 
                            $startPage = max(1, $currentPage - 2);
                            $endPage = min($totalPages, $currentPage + 2);
                            
                            if ($startPage > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="#" data-page="1">1</a>
                                </li>
                                <?php if ($startPage > 2): ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">...</span>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?= $i == $currentPage ? 'active' : '' ?>">
                                    <a class="page-link" href="#" data-page="<?= $i ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($endPage < $totalPages): ?>
                                <?php if ($endPage < $totalPages - 1): ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">...</span>
                                    </li>
                                <?php endif; ?>
                                <li class="page-item">
                                    <a class="page-link" href="#" data-page="<?= $totalPages ?>"><?= $totalPages ?></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if ($currentPage < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="#" data-page="<?= $currentPage + 1 ?>">
                                        Sau <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Filter form (hidden) -->
<form id="filterForm" method="GET" action="<?= BASE_URL ?>index.php" style="display: none;">
    <input type="hidden" name="navigate" value="search1">
    <input type="hidden" name="search" value="<?= e($keyword) ?>">
    <input type="hidden" name="category_id" value="<?= $categoryId ?>">
    <input type="hidden" name="price_range" value="<?= $priceRange ?>">
    <input type="hidden" name="status" value="<?= $status ?>">
    <input type="hidden" name="sort" value="<?= $sortBy ?>">
    <input type="hidden" name="page" value="1">
</form>


<!-- JavaScript for Filter Interactions -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    const productsContainer = document.getElementById('productsContainer');
    const sortSelect = document.getElementById('sortSelect');
    const clearAllBtn = document.getElementById('clearAllFilters');
    const pagination = document.getElementById('pagination');
    
    // Loading overlay
    function showLoading() {
        if (!document.getElementById('loadingOverlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div>';
            document.body.appendChild(overlay);
        }
    }
    
    function hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.remove();
        }
    }
    
    // Update form and submit
    function updateFilters(resetPage = true) {
        if (resetPage) {
            filterForm.querySelector('input[name="page"]').value = 1;
        }
        
        // Update form values
        const categoryFilter = document.querySelector('input[name="category"]:checked');
        const priceFilter = document.querySelector('input[name="price_range"]:checked');
        const statusFilter = document.querySelector('input[name="status"]:checked');
        
        filterForm.querySelector('input[name="category_id"]').value = categoryFilter ? categoryFilter.value : 0;
        filterForm.querySelector('input[name="price_range"]').value = priceFilter ? priceFilter.value : '';
        filterForm.querySelector('input[name="status"]').value = statusFilter ? statusFilter.value : '';
        filterForm.querySelector('input[name="sort"]').value = sortSelect.value;
        
        // Show loading and submit
        showLoading();
        filterForm.submit();
    }
    
    // Category filter change
    document.querySelectorAll('.category-filter').forEach(function(filter) {
        filter.addEventListener('change', function() {
            updateFilters();
        });
    });
    
    // Price filter change
    document.querySelectorAll('.price-filter').forEach(function(filter) {
        filter.addEventListener('change', function() {
            updateFilters();
        });
    });
    
    // Status filter change
    document.querySelectorAll('.status-filter').forEach(function(filter) {
        filter.addEventListener('change', function() {
            updateFilters();
        });
    });
    
    // Sort change
    sortSelect.addEventListener('change', function() {
        updateFilters();
    });
    
    // Clear all filters
    clearAllBtn.addEventListener('click', function() {
        // Reset all filters
        document.querySelector('input[name="category"][value="0"]').checked = true;
        document.querySelector('input[name="price_range"][value=""]').checked = true;
        document.querySelector('input[name="status"][value=""]').checked = true;
        sortSelect.value = 'name_asc';
        
        updateFilters();
    });
    
    // Pagination handling
    if (pagination) {
        pagination.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (e.target.tagName === 'A' && e.target.hasAttribute('data-page')) {
                const page = e.target.getAttribute('data-page');
                filterForm.querySelector('input[name="page"]').value = page;
                
                showLoading();
                filterForm.submit();
            }
        });
    }
    
    // Add to cart functionality
    document.querySelectorAll('.add-to-cart-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = this.getAttribute('data-product-id');
            const originalText = this.innerHTML;
            
            // Disable button
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang thêm...';
            
            // AJAX call to add to cart
            fetch('<?= BASE_URL ?>api/index.php?request=cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: 1
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update cart count if exists
                    const cartCount = document.querySelector('.cart-count');
                    if (cartCount) {
                        cartCount.textContent = data.cart_count || '';
                        cartCount.style.display = data.cart_count > 0 ? 'inline' : 'none';
                    }
                    
                    // Show success message
                    this.innerHTML = '<i class="fas fa-check"></i> Đã thêm';
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-success');
                    
                    // Reset after 2 seconds
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.classList.remove('btn-success');
                        this.classList.add('btn-primary');
                        this.disabled = false;
                    }, 2000);
                } else {
                    throw new Error(data.message || 'Có lỗi xảy ra');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Lỗi';
                this.classList.add('btn-danger');
                
                // Reset after 2 seconds
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.classList.remove('btn-danger');
                    this.disabled = false;
                }, 2000);
            });
        });
    });
    
    // Wishlist functionality
    document.querySelectorAll('.wishlist-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = this.getAttribute('data-product-id');
            const icon = this.querySelector('i');
            
            // Toggle wishlist status
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas', 'text-danger');
                this.setAttribute('title', 'Xóa khỏi yêu thích');
            } else {
                icon.classList.remove('fas', 'text-danger');
                icon.classList.add('far');
                this.setAttribute('title', 'Thêm vào yêu thích');
            }
            
            // Here you can add AJAX call to update wishlist in backend
        });
    });
    
    // View toggle functionality
    const gridViewBtn = document.getElementById('gridView');
    const listViewBtn = document.getElementById('listView');
    
    gridViewBtn.addEventListener('click', function() {
        productsContainer.className = 'products-grid';
        this.classList.add('active');
        listViewBtn.classList.remove('active');
    });
    
    listViewBtn.addEventListener('click', function() {
        productsContainer.className = 'products-list';
        this.classList.add('active');
        gridViewBtn.classList.remove('active');
    });
    
    // Smooth scroll to top on page change
    window.addEventListener('load', function() {
        hideLoading();
        
        // Smooth scroll to top if coming from pagination
        if (window.location.hash === '#top' || document.querySelector('.pagination .active')) {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    });
    
    // Prevent form double submission
    let isSubmitting = false;
    filterForm.addEventListener('submit', function(e) {
        if (isSubmitting) {
            e.preventDefault();
            return false;
        }
        isSubmitting = true;
        
        // Reset flag after 2 seconds
        setTimeout(() => {
            isSubmitting = false;
        }, 2000);
    });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


