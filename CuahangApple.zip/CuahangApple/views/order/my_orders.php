<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<div class="container my-5">
    <h2 class="mb-4">
        <i class="fas fa-box"></i> Đơn hàng của tôi
    </h2>
    
    <?php if (empty($orders)): ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-box-open fa-3x mb-3"></i>
            <h4>Bạn chưa có đơn hàng nào</h4>
            <p>Hãy bắt đầu mua sắm ngay!</p>
            <a href="<?= BASE_URL ?>index.php?navigate=search1" class="btn btn-primary">
                <i class="fas fa-shopping-bag"></i> Mua sắm ngay
            </a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Ngày đặt</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th>Thanh toán</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong><?= e($order['order_number']) ?></strong>
                            </td>
                            <td><?= formatDate($order['created_at']) ?></td>
                            <td><strong class="text-danger"><?= formatCurrency($order['final_amount']) ?></strong></td>
                            <td>
                                <?php
                                $statusClass = [
                                    'pending' => 'warning',
                                    'confirmed' => 'info',
                                    'processing' => 'primary',
                                    'shipping' => 'info',
                                    'delivered' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                $class = $statusClass[$order['order_status']] ?? 'secondary';
                                ?>
                                <span class="badge badge-<?= $class ?>">
                                    <?= getOrderStatus($order['order_status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $paymentClass = [
                                    'pending' => 'warning',
                                    'paid' => 'success',
                                    'failed' => 'danger'
                                ];
                                $class = $paymentClass[$order['payment_status']] ?? 'secondary';
                                ?>
                                <span class="badge badge-<?= $class ?>">
                                    <?= getPaymentStatus($order['payment_status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?= BASE_URL ?>index.php?navigate=order_detail&order_id=<?= $order['order_id'] ?>" 
                                   class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Chi tiết
                                </a>
                                <?php if ($order['order_status'] == 'pending'): ?>
                                    <a href="<?= BASE_URL ?>index.php?navigate=order_cancel&order_id=<?= $order['order_id'] ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này?')">
                                        <i class="fas fa-times"></i> Hủy
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


