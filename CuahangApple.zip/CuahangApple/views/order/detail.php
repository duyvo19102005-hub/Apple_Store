<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>
            <i class="fas fa-file-invoice"></i> Chi tiết đơn hàng
        </h2>
        <a href="<?= BASE_URL ?>index.php?navigate=my_orders" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <!-- Order Info -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Thông tin đơn hàng #<?= e($order['order_number']) ?></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Ngày đặt:</strong> <?= formatDate($order['created_at']) ?></p>
                            <p><strong>Trạng thái:</strong> 
                                <?php
                                $statusClass = [
                                    'pending' => 'warning',
                                    'confirmed' => 'info',
                                    'processing' => 'primary',
                                    'shipping' => 'info',
                                    'delivered' => 'success',
                                    'cancelled' => 'danger'
                                ];
                                $class = $statusClass[$order['order_status']] ?? 'secondary';
                                ?>
                                <span class="badge badge-<?= $class ?>">
                                    <?= getOrderStatus($order['order_status']) ?>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Thanh toán:</strong> 
                                <?php
                                $paymentClass = [
                                    'pending' => 'warning',
                                    'paid' => 'success',
                                    'failed' => 'danger'
                                ];
                                $class = $paymentClass[$order['payment_status']] ?? 'secondary';
                                ?>
                                <span class="badge badge-<?= $class ?>">
                                    <?= getPaymentStatus($order['payment_status']) ?>
                                </span>
                            </p>
                            <p><strong>Phương thức:</strong> <?= getPaymentMethod($order['payment_method']) ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Shipping Info -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Thông tin giao hàng</h5>
                </div>
                <div class="card-body">
                    <p><strong>Địa chỉ:</strong> <?= nl2br(e($order['shipping_address'])) ?></p>
                    <p><strong>Số điện thoại:</strong> <?= e($order['phone']) ?></p>
                    <?php if (!empty($order['notes'])): ?>
                        <p><strong>Ghi chú:</strong> <?= nl2br(e($order['notes'])) ?></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Sản phẩm đã đặt</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th>Đơn giá</th>
                                <th>Số lượng</th>
                                <th>Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order['items'] as $item): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if ($item['image']): ?>
                                                <img src="<?= getProductImage($item['image']) ?>" 
                                                     alt="<?= e($item['product_name']) ?>" 
                                                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                            <?php endif; ?>
                                            <div class="ml-3">
                                                <?= e($item['product_name']) ?>
                                                <?php if ($item['discount_percent'] > 0): ?>
                                                    <br><small class="text-success">Giảm <?= $item['discount_percent'] ?>%</small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($item['discount_percent'] > 0): ?>
                                            <del class="text-muted d-block"><?= formatCurrency($item['price']) ?></del>
                                        <?php endif; ?>
                                        <?= formatCurrency(getDiscountedPrice($item['price'], $item['discount_percent'])) ?>
                                    </td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td><strong><?= formatCurrency($item['subtotal']) ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Order Summary -->
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Tổng đơn hàng</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tổng tiền hàng:</span>
                        <strong><?= formatCurrency($order['total_amount']) ?></strong>
                    </div>
                    <?php if ($order['discount_amount'] > 0): ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Giảm giá:</span>
                            <span class="text-success">-<?= formatCurrency($order['discount_amount']) ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Phí vận chuyển:</span>
                        <span class="text-success">Miễn phí</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <h5>Tổng thanh toán:</h5>
                        <h5 class="text-danger"><?= formatCurrency($order['final_amount']) ?></h5>
                    </div>
                    
                    <?php if ($order['order_status'] == 'pending'): ?>
                        <hr>
                        <a href="<?= BASE_URL ?>index.php?navigate=order_cancel&order_id=<?= $order['order_id'] ?>" 
                           class="btn btn-danger btn-block"
                           onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này?')">
                            <i class="fas fa-times"></i> Hủy đơn hàng
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


