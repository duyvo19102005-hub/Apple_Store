<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<div class="container my-5">
    <h2 class="mb-4">
        <i class="fas fa-credit-card"></i> Thanh toán
    </h2>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Thông tin giao hàng</h5>
                </div>
                <div class="card-body">
                    <form action="<?= BASE_URL ?>index.php?navigate=process_checkout" method="POST" id="checkoutForm">
                        <?= Auth::csrfField() ?>
                        
                        <div class="form-group">
                            <label for="full_name">Họ và tên <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?= e($_SESSION['full_name'] ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Số điện thoại <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="phone" name="phone" 
                                   placeholder="Nhập số điện thoại" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="shipping_address">Địa chỉ giao hàng <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="shipping_address" name="shipping_address" 
                                      rows="3" placeholder="Nhập địa chỉ chi tiết" required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="payment_method">Phương thức thanh toán <span class="text-danger">*</span></label>
                            <select class="form-control" id="payment_method" name="payment_method" required>
                                <option value="cod">Thanh toán khi nhận hàng (COD)</option>
                                <option value="bank_transfer">Chuyển khoản ngân hàng</option>
                                <option value="momo">Ví MoMo</option>
                                <option value="vnpay">VNPay</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="notes">Ghi chú</label>
                            <textarea class="form-control" id="notes" name="notes" 
                                      rows="2" placeholder="Ghi chú cho đơn hàng (tùy chọn)"></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg btn-block">
                            <i class="fas fa-check"></i> Xác nhận đặt hàng
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Đơn hàng của bạn</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($cartItems as $item): 
                        $itemPrice = getDiscountedPrice($item['price'], $item['discount_percent']);
                        $itemTotal = $itemPrice * $item['quantity'];
                    ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center">
                                <img src="<?= getProductImage($item['image']) ?>" 
                                     alt="<?= e($item['product_name']) ?>" 
                                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                <div class="ml-2">
                                    <div style="font-size: 14px;"><?= truncate($item['product_name'], 30) ?></div>
                                    <small class="text-muted">SL: <?= $item['quantity'] ?></small>
                                </div>
                            </div>
                            <div class="text-right">
                                <strong><?= formatCurrency($itemTotal) ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <hr>
                    
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tạm tính:</span>
                        <strong><?= formatCurrency($cartTotal) ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Phí vận chuyển:</span>
                        <span class="text-success">Miễn phí</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <h5>Tổng cộng:</h5>
                        <h5 class="text-danger"><?= formatCurrency($cartTotal) ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


