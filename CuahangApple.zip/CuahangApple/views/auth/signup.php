<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">Đăng ký tài khoản</h3>
                </div>
                <div class="card-body">
                    <form action="<?= BASE_URL ?>index.php?navigate=process_signup" method="POST">
                        <?= Auth::csrfField() ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="username">Tên đăng nhập <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           placeholder="Nhập tên đăng nhập" 
                                           value="<?= e($_SESSION['old']['username'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="Nhập email" 
                                           value="<?= e($_SESSION['old']['email'] ?? '') ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="full_name">Họ và tên <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   placeholder="Nhập họ và tên" 
                                   value="<?= e($_SESSION['old']['full_name'] ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Số điện thoại</label>
                            <input type="text" class="form-control" id="phone" name="phone" 
                                   placeholder="Nhập số điện thoại" 
                                   value="<?= e($_SESSION['old']['phone'] ?? '') ?>">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password">Mật khẩu <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           placeholder="Nhập mật khẩu (tối thiểu 6 ký tự)" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="confirm_password">Xác nhận mật khẩu <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                           placeholder="Nhập lại mật khẩu" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="agree" required>
                            <label class="form-check-label" for="agree">
                                Tôi đồng ý với các <a href="#">điều khoản và điều kiện</a>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-user-plus"></i> Đăng ký
                        </button>
                        
                        <hr>
                        
                        <p class="text-center mb-0">
                            Đã có tài khoản? 
                            <a href="<?= BASE_URL ?>index.php?navigate=login">Đăng nhập ngay</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
unset($_SESSION['old']); 
require_once __DIR__ . '/../../includes/footer.php'; 
?>


