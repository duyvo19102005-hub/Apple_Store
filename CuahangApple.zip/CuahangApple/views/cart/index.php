<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<div class="container my-5">
    <h2 class="mb-4">
        <i class="fas fa-shopping-cart"></i> Giỏ hàng của bạn
    </h2>
    
    <?php if (empty($cartItems)): ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-shopping-cart fa-3x mb-3"></i>
            <h4>Giỏ hàng trống</h4>
            <p>Bạn chưa có sản phẩm nào trong giỏ hàng.</p>
            <a href="<?= BASE_URL ?>index.php?navigate=search1" class="btn btn-primary">
                <i class="fas fa-shopping-bag"></i> Tiếp tục mua sắm
            </a>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th>Đơn giá</th>
                                    <th>Số lượng</th>
                                    <th>Thành tiền</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cartItems as $item): 
                                    $itemPrice = getDiscountedPrice($item['price'], $item['discount_percent']);
                                    $itemTotal = $itemPrice * $item['quantity'];
                                ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?= getProductImage($item['image']) ?>" 
                                                     alt="<?= e($item['product_name']) ?>" 
                                                     style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;">
                                                <div class="ml-3">
                                                    <h6 class="mb-0">
                                                        <a href="<?= BASE_URL ?>index.php?navigate=product_info&product_id=<?= $item['product_id'] ?>">
                                                            <?= e($item['product_name']) ?>
                                                        </a>
                                                    </h6>
                                                    <?php if ($item['discount_percent'] > 0): ?>
                                                        <small class="text-success">Giảm <?= $item['discount_percent'] ?>%</small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($item['discount_percent'] > 0): ?>
                                                <del class="text-muted"><?= formatCurrency($item['price']) ?></del><br>
                                            <?php endif; ?>
                                            <strong><?= formatCurrency($itemPrice) ?></strong>
                                        </td>
                                        <td>
                                            <form action="<?= BASE_URL ?>index.php?navigate=cart_update" method="POST" class="d-inline">
                                                <?= Auth::csrfField() ?>
                                                <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                                <input type="number" name="quantity" value="<?= $item['quantity'] ?>" 
                                                       min="1" max="<?= $item['stock_quantity'] ?>" 
                                                       class="form-control form-control-sm" 
                                                       style="width: 70px; display: inline-block;"
                                                       onchange="this.form.submit()">
                                            </form>
                                        </td>
                                        <td>
                                            <strong class="text-danger"><?= formatCurrency($itemTotal) ?></strong>
                                        </td>
                                        <td>
                                            <a href="<?= BASE_URL ?>index.php?navigate=cart_remove&product_id=<?= $item['product_id'] ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div class="text-right">
                            <a href="<?= BASE_URL ?>index.php?navigate=cart_clear" 
                               class="btn btn-outline-danger"
                               onclick="return confirm('Bạn có chắc muốn xóa tất cả sản phẩm?')">
                                <i class="fas fa-trash-alt"></i> Xóa tất cả
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Thông tin đơn hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Tạm tính:</span>
                            <strong><?= formatCurrency($cartTotal) ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Phí vận chuyển:</span>
                            <span class="text-success">Miễn phí</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <h5>Tổng cộng:</h5>
                            <h5 class="text-danger"><?= formatCurrency($cartTotal) ?></h5>
                        </div>
                        
                        <a href="<?= BASE_URL ?>index.php?navigate=checkout" class="btn btn-primary btn-block btn-lg">
                            <i class="fas fa-credit-card"></i> Thanh toán
                        </a>
                        
                        <a href="<?= BASE_URL ?>index.php?navigate=search1" class="btn btn-outline-secondary btn-block mt-2">
                            <i class="fas fa-arrow-left"></i> Tiếp tục mua sắm
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


