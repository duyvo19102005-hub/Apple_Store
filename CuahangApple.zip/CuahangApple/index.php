<?php
/**
 * Main Application Entry Point
 */

// Start session
session_start();

// Load configuration
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/Database.php';

// Load helpers
require_once __DIR__ . '/helpers/Helper.php';
require_once __DIR__ . '/helpers/Session.php';
require_once __DIR__ . '/helpers/Auth.php';
require_once __DIR__ . '/helpers/Validator.php';

// Load core classes
require_once __DIR__ . '/core/Model.php';
require_once __DIR__ . '/core/Controller.php';

// Load controllers
require_once __DIR__ . '/controllers/HomeController.php';
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/ProductController.php';
require_once __DIR__ . '/controllers/CartController.php';
require_once __DIR__ . '/controllers/OrderController.php';

// Load Router class
require_once __DIR__ . '/core/Router.php';

// Create and configure router
$router = new Router();
$router->registerRoutes();

// Dispatch request
$router->dispatch();

