<?php
/**
 * Repository Interface
 * Interface cho Repository Pattern
 */
interface RepositoryInterface {
    
    /**
     * Lấy tất cả items
     * @return array
     */
    public function getAll();
    
    /**
     * Lấy item theo ID
     * @param int $id
     * @return array|null
     */
    public function getById($id);
    
    /**
     * Tạo item mới
     * @param array $data
     * @return int|false
     */
    public function create(array $data);
    
    /**
     * Cập nhật item
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, array $data);
    
    /**
     * Xóa item
     * @param int $id
     * @return bool
     */
    public function delete($id);
    
    /**
     * Tìm items theo criteria
     * @param array $criteria
     * @return array
     */
    public function findBy(array $criteria);
}


