<?php
/**
 * Database Interface
 * Interface cho Database connection
 */
interface DatabaseInterface {
    
    /**
     * Lấy database connection
     * @return PDO
     */
    public function getConnection();
    
    /**
     * Bắt đầu transaction
     * @return bool
     */
    public function beginTransaction();
    
    /**
     * Commit transaction
     * @return bool
     */
    public function commit();
    
    /**
     * Rollback transaction
     * @return bool
     */
    public function rollback();
    
    /**
     * Execute query
     * @param string $sql
     * @param array $params
     * @return PDOStatement
     */
    public function query($sql, array $params = []);
}


