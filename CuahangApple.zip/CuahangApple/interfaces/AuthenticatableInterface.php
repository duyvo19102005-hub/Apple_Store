<?php
/**
 * Authenticatable Interface
 * Interface cho các class có chức năng xác thực
 */
interface AuthenticatableInterface {
    
    /**
     * Đăng nhập user
     * @param string $email
     * @param string $password
     * @return array ['success' => bool, 'message' => string, 'user' => array|null]
     */
    public function login($email, $password);
    
    /**
     * Đăng xuất user
     * @return bool
     */
    public function logout();
    
    /**
     * Kiểm tra email tồn tại
     * @param string $email
     * @return bool
     */
    public function emailExists($email);
    
    /**
     * Đổi mật khẩu
     * @param int $userId
     * @param string $oldPassword
     * @param string $newPassword
     * @return bool
     */
    public function changePassword($userId, $oldPassword, $newPassword);
}


