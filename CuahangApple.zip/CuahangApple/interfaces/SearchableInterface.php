<?php
/**
 * Searchable Interface
 * Interface cho các class có chức năng tìm kiếm
 */
interface SearchableInterface {
    
    /**
     * Tìm kiếm theo keyword
     * @param string $keyword
     * @param int|null $categoryId
     * @param int|null $limit
     * @param int $offset
     * @return array
     */
    public function search($keyword, $categoryId = null, $limit = null, $offset = 0);
}


