<?php
/**
 * Model Interface
 * Định nghĩa các phương thức cơ bản mà mọi Model phải implement
 */
interface ModelInterface {
    
    /**
     * Tìm record theo ID
     * @param int $id
     * @return array|false
     */
    public function find($id);
    
    /**
     * Lấy tất cả records
     * @param int|null $limit
     * @param int $offset
     * @return array
     */
    public function all($limit = null, $offset = 0);
    
    /**
     * Tìm records theo điều kiện
     * @param string $column
     * @param mixed $value
     * @param string $operator
     * @return array
     */
    public function where($column, $value, $operator = '=');
    
    /**
     * Tạo record mới
     * @param array $data
     * @return int|false ID của record mới hoặc false nếu thất bại
     */
    public function create($data);
    
    /**
     * Cập nhật record
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data);
    
    /**
     * Xóa record
     * @param int $id
     * @return bool
     */
    public function delete($id);
    
    /**
     * Đếm số lượng records
     * @param string|null $where
     * @return int
     */
    public function count($where = null);
}


