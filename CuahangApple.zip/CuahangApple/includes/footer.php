<div class="footer primary-background mt-5">
    <div class="container-fluid p-0">
        <div class="row text-left">
            <div class="col-md-5 col-sm-5">
                <h4 class="text-light">Ghé thăm cửa hàng hôm nay</h4>
                <p class="pt-2 text-light">
                    <i>Thứ 2 đến chủ nhật 6 giờ đến 23 giờ</i>
                </p>
                <p class="pt-2 text-light">
                    <i>Địa chỉ: 273 An Dương Vương, phường 8, quận 5, TP.HCM</i>
                </p>
                <p class="pt-2 text-light">
                    <i>Email: Lowkey051203@gmail.com</i>
                </p>
                <p>
                    <a class="pt-2 text-light" href="tel:+0772317060"><i>Phone: 0772317060</i></a>
                </p>
            </div>
            <div class="col-md-5 col-sm-12 pb-4">
                <h4 class="text-light">Câu hỏi</h4>
                <p class="text-light"><i>Bạn có câu hỏi nào không?</i></p>
                <form class="form-inline">
                    <div class="col pl-0">
                        <div class="input-group pr-5">
                            <input
                                type="text"
                                class="form-control border-0"
                                id="inlineFormInputGroupUsername2"
                                placeholder="Email"
                            />
                            <div class="input-group-prepend">
                                <div class="input-group-text bg-transparent">
                                    <a class="text-light" href="mailto:Lowkey051203@gmail.com">
                                        <i class="fas fa-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-2 col-sm-12">
                <h4 class="text-light">Theo dõi tôi</h4>
                <p class="text-light"><i>Liên hệ với chúng tôi</i></p>
                <div class="column text-light">
                    <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Fixed Service Icons -->
<ul class="icon-service-wrap">
    <li data-toggle="tooltip" data-placement="left" title="Gọi ngay cho chúng tôi">
        <a href="tel:0772317060">
            <img width="60px" src="<?= BASE_URL ?>assets/images/banners/icon-phone.png" class="icon-service-img"/>
        </a>
    </li>
    <li data-toggle="tooltip" data-placement="left" title="Chat với chúng tôi qua Zalo">
        <a href="https://chat.zalo.me/index.html" target="_blank">
            <img width="60px" src="<?= BASE_URL ?>assets/images/banners/icon-zalo.png" class="icon-service-img"/>
        </a>
    </li>
    <li data-toggle="tooltip" data-placement="left" title="Chat với chúng tôi qua Facebook">
        <a href="https://www.facebook.com/" target="_blank">
            <img width="60px" src="<?= BASE_URL ?>assets/images/banners/icon-facebook.png" class="icon-service-img"/>
        </a>
    </li>
    <li data-toggle="tooltip" data-placement="left" title="Liên hệ với chúng tôi">
        <a href="https://www.google.com/maps" target="_blank">
            <img width="60px" src="<?= BASE_URL ?>assets/images/banners/icon-map.png" class="icon-service-img"/>
        </a>
    </li>
</ul>

<!-- jQuery and Bootstrap JS from CDN -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" 
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" 
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" 
        crossorigin="anonymous"></script>

<!-- Initialize tooltips -->
<script>
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
</script>

</body>
</html>

