<?php
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Category.php';

// Get cart count
$cartCount = 0;
if (Auth::check()) {
    $cartModel = new Cart();
    $cartCount = $cartModel->getCartCount(Auth::id());
}

// Get categories
$categoryModel = new Category();
$categories = $categoryModel->getActiveCategories();
?>

<div class="menu sticky-top">
    <nav class="navbar navbar-expand-lg primary-background">
        <div class="container-fluid font-weight-bold">
            <a class="navbar-branch" href="<?= BASE_URL ?>index.php">
                <i class="fas fa-robot fa-2x mx-3"></i>
            </a>
            <button
                class="navbar-toggler text-light"
                type="button"
                data-toggle="collapse"
                data-target="#collapsibleNavbar"
            >
                <i class="fas fa-align-right"></i>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="collapsibleNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>index.php">Trang chủ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=search1">Sản phẩm</a>
                    </li>
                    
                    <?php if (Auth::check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=cart">
                                Giỏ hàng <?php if ($cartCount > 0): ?><span class="badge badge-danger"><?= $cartCount ?></span><?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=my_orders">Đơn hàng</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-user"></i> <?= e($_SESSION['full_name'] ?? 'User') ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="userDropdown">
                                <?php if (Auth::isAdmin()): ?>
                                    <a class="dropdown-item" href="<?= BASE_URL ?>admin/index.php">
                                        <i class="fas fa-cog"></i> Quản trị
                                    </a>
                                    <div class="dropdown-divider"></div>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?= BASE_URL ?>index.php?navigate=logout">
                                    <i class="fas fa-sign-out-alt"></i> Đăng xuất
                                </a>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=login">Đăng nhập</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=signup">Đăng ký</a>
                        </li>
                    <?php endif; ?>
                </ul>
                <form
                    action="<?= BASE_URL ?>index.php"
                    class="d-flex"
                    role="search"
                    method="get"
                >
                    <input type="hidden" name="navigate" value="search1">
                    <input
                        type="search"
                        placeholder="Nhập tên sản phẩm"
                        class="form-control border-0"
                        style="border-radius: 4px 0 0 4px"
                        name="search"
                        aria-label="Search"
                        value="<?= e($_GET['search'] ?? '') ?>"
                    />
                    <input type="hidden" name="category_id" value="0">
                    <input
                        type="submit"
                        class="btn bg-transparent border-light text-light"
                        style="border-radius: 0 4px 4px 0"
                        value="Tìm kiếm"
                    />
                </form>
            </div>
        </div>
    </nav>
</div>


