-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 25, 2025 lúc 04:33 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `apple_store`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `product_id`, `quantity`, `added_at`) VALUES
(7, 2, 18, 2, '2025-11-25 13:05:55');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `description`, `image`, `display_order`, `status`, `created_at`, `updated_at`) VALUES
(1, 'iPhone', 'Điện thoại iPhone chính hãng', 'iphone-11-tim.jpg.webp', 1, 'active', '2025-11-25 08:50:31', '2025-11-25 08:50:50'),
(2, 'MacBook', 'Laptop MacBook cao cấp', 'macbook1.jpg', 2, 'active', '2025-11-25 08:50:31', '2025-11-25 08:50:50'),
(3, 'Apple Watch', 'Đồng hồ thông minh Apple Watch', 'dongho1.jpg', 3, 'active', '2025-11-25 08:50:31', '2025-11-25 08:50:50'),
(4, 'AirPods', 'Tai nghe không dây AirPods', 'tainghe1.jpg', 4, 'active', '2025-11-25 08:50:31', '2025-11-25 08:50:50');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) DEFAULT 0.00,
  `final_amount` decimal(12,2) NOT NULL,
  `shipping_address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `payment_method` enum('cod','bank_transfer','momo','vnpay') DEFAULT 'cod',
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `order_status` enum('pending','confirmed','processing','shipping','delivered','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_number`, `total_amount`, `discount_amount`, `final_amount`, `shipping_address`, `phone`, `payment_method`, `payment_status`, `order_status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 2, 'ORD20251125645099', 29990000.00, 2999000.00, 26991000.00, 'abc', '0932716519', 'cod', 'paid', 'delivered', '', '2025-11-25 09:14:11', '2025-11-25 11:46:23'),
(2, 2, 'ORD20251125546729', 23990000.00, 2399000.00, 21591000.00, 'abc', '0932716519', 'cod', 'paid', 'delivered', '', '2025-11-25 09:15:07', '2025-11-25 09:21:32'),
(3, 3, 'ORD20251125938803', 12990000.00, 1299000.00, 11691000.00, 'dh Sai Gon', '123456789', 'momo', 'pending', 'confirmed', '', '2025-11-25 11:50:33', '2025-11-25 11:51:54'),
(4, 2, 'ORD20251125229757', 23990000.00, 2399000.00, 21591000.00, 'abc', '0932716519', 'cod', 'paid', 'delivered', '', '2025-11-25 12:48:22', '2025-11-25 12:50:45'),
(5, 2, 'ORD20251125516190', 29990000.00, 2999000.00, 26991000.00, 'abc', '0932716519', 'cod', 'pending', 'cancelled', '', '2025-11-25 13:02:45', '2025-11-25 13:02:58');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `discount_percent` int(11) DEFAULT 0,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `product_name`, `price`, `discount_percent`, `quantity`, `subtotal`) VALUES
(1, 1, 1, 'iPhone 14 Pro Max 256GB', 29990000.00, 10, 1, 26991000.00),
(2, 2, 3, 'iPhone 12 Pro Max Vàng', 23990000.00, 10, 1, 21591000.00),
(3, 3, 5, 'iPhone 11 Pro Xanh', 12990000.00, 10, 1, 11691000.00),
(4, 4, 3, 'iPhone 12 Pro Max Vàng', 23990000.00, 10, 1, 21591000.00),
(5, 5, 1, 'iPhone 14 Pro Max 256GB', 29990000.00, 10, 1, 26991000.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `specifications` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `discount_percent` int(11) DEFAULT 0,
  `stock_quantity` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `images` text DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `product_name`, `description`, `specifications`, `price`, `discount_percent`, `stock_quantity`, `image`, `images`, `is_featured`, `status`, `views`, `created_at`, `updated_at`) VALUES
(1, 1, 'iPhone 14 Pro Max 256GB', 'iPhone 14 Pro Max với chip A16 Bionic mạnh mẽ, camera 48MP ProRAW', 'Chip A16 Bionic\nCamera 48MP\nMàn hình 6.7\" Super Retina XDR\nRAM 6GB', 29990000.00, 10, 49, '1764061673_1763984215_ip14.webp', NULL, 1, 'active', 8, '2025-11-25 08:50:50', '2025-11-25 13:02:58'),
(2, 1, 'iPhone 13 128GB', 'iPhone 13 với chip A15 Bionic, camera kép 12MP', 'Chip A15 Bionic\nCamera 12MP\nMàn hình 6.1\" Super Retina XDR\nRAM 4GB', 19990000.00, 5, 100, 'iphone-13-pro-max-old-blue.jpg.webp', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 12:55:37'),
(3, 1, 'iPhone 12 Pro Max Vàng', 'iPhone 12 Pro Max màu vàng sang trọng', 'Chip A14 Bionic\nCamera 12MP Pro\nMàn hình 6.7\"\nRAM 6GB', 23990000.00, 10, 28, 'iphone-12-pro-max-cu-vang.jpg.webp', NULL, 1, 'active', 3, '2025-11-25 08:50:50', '2025-11-25 12:48:22'),
(4, 1, 'iPhone 11 Pro Max Tím', 'iPhone 11 Pro Max màu tím đặc biệt', 'Chip A13 Bionic\nCamera 12MP\nMàn hình 6.5\"\nRAM 4GB', 15690000.00, 10, 40, 'iphone-11-tim.jpg.webp', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(5, 1, 'iPhone 11 Pro Xanh', 'iPhone 11 Pro màu xanh midnight', 'Chip A13 Bionic\nCamera 12MP Pro\nMàn hình 5.8\"\nRAM 4GB', 12990000.00, 10, 34, 'iphone-11-pro-xanh.jpg.webp', NULL, 1, 'active', 2, '2025-11-25 08:50:50', '2025-11-25 13:03:59'),
(6, 1, 'iPhone 12 Xanh Navy', 'iPhone 12 màu xanh navy đẹp mắt', 'Chip A14 Bionic\nCamera 12MP\nMàn hình 6.1\"\nRAM 4GB', 18990000.00, 10, 60, 'iphone-12-xanh.jpg.webp', NULL, 1, 'active', 1, '2025-11-25 08:50:50', '2025-11-25 12:56:38'),
(7, 1, 'iPhone 11 Pro Max Vàng', 'iPhone 11 Pro Max màu vàng gold', 'Chip A13 Bionic\nCamera 12MP\nMàn hình 6.5\"\nRAM 4GB', 14590000.00, 10, 25, 'iphone-11-pro-max-vang.jpg.webp', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(8, 1, 'iPhone 13 Pro Max Xanh', 'iPhone 13 Pro Max màu xanh sierra', 'Chip A15 Bionic\nCamera 12MP ProRAW\nMàn hình 6.7\"\nRAM 6GB', 27990000.00, 10, 45, 'iphone-13-pro-max-old-blue.jpg.webp', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(9, 2, 'MacBook Pro 14\" M2 Pro', 'MacBook Pro 14 inch với chip M2 Pro, RAM 16GB, SSD 512GB', 'Chip M2 Pro 10 cores\nRAM 16GB\nSSD 512GB\nMàn hình 14.2\" Liquid Retina XDR', 52990000.00, 0, 20, '1764061697_macbook4.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:08:17'),
(10, 2, 'MacBook Air M2 2022', 'MacBook Air siêu mỏng với chip M2, thiết kế mới', 'Chip M2 8 cores\nRAM 8GB\nSSD 256GB\nMàn hình 13.6\" Liquid Retina', 32990000.00, 5, 35, '1764061686_macbook3.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:08:06'),
(11, 2, 'MacBook Pro 16\" M1 Pro', 'MacBook Pro 16 inch với chip M1 Pro mạnh mẽ', 'Chip M1 Pro\nRAM 16GB\nSSD 512GB\nMàn hình 16.2\"', 48990000.00, 0, 15, 'macbook1.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(12, 3, 'Apple Watch Series 8 45mm', 'Apple Watch Series 8 với cảm biến nhiệt độ, theo dõi sức khỏe toàn diện', 'Chip S8\nMàn hình Always-On Retina\nCảm biến nhiệt độ\nChống nước 50m', 11990000.00, 15, 75, '1764061648_dongho10.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:07:28'),
(13, 3, 'Apple Watch SE 2022 40mm', 'Apple Watch SE phiên bản mới với giá hợp lý', 'Chip S8\nMàn hình Retina\nTheo dõi sức khỏe\nChống nước 50m', 7990000.00, 10, 100, '1764061619_dongho3.jpg', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:06:59'),
(14, 3, 'Apple Watch Ultra', 'Apple Watch Ultra cho những người yêu thể thao mạo hiểm', 'Chip S8\nMàn hình 49mm titanium\nGPS chính xác\nChống nước 100m', 21990000.00, 0, 30, 'dongho1.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(15, 4, 'AirPods Pro 2nd Gen', 'AirPods Pro thế hệ thứ 2 với chip H2, chống ồn chủ động tốt hơn', 'Chip H2\nChống ồn chủ động\nÂm thanh không gian\nThời lượng pin 6h', 6490000.00, 10, 150, '1764061587_tainghe1.jpg', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:06:27'),
(16, 4, 'AirPods 3rd Gen', 'AirPods thế hệ thứ 3 với âm thanh không gian', 'Chip H1\nÂm thanh không gian\nChống nước IPX4\nThời lượng pin 6h', 4990000.00, 5, 200, '1764061556_1763984014_tainghe5.png', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:05:56'),
(17, 4, 'AirPods Max', 'Tai nghe over-ear cao cấp từ Apple', 'Chip H1\nChống ồn chủ động\nÂm thanh Hi-Fi\nThời lượng pin 20h', 13990000.00, 0, 25, '1764061567_airpods2.webp', NULL, 1, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:06:07'),
(18, 4, 'AirPods Basic', 'AirPods cơ bản với giá phải chăng', 'Chip W1\nThời lượng pin 5h\nHộp sạc Lightning\nTự động kết nối', 3490000.00, 5, 180, 'tainghe1.jpg', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(19, 4, 'AirPods Sport', 'AirPods Sport chuyên cho thể thao', 'Chip H1\nChống mồ hôi\nKhóa ôm tai\nThời lượng pin 7h', 4990000.00, 10, 120, 'tainghe8.jpg', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(20, 4, 'AirPods Lite', 'AirPods Lite nhẹ nhàng thoải mái', 'Chip W1\nThiết kế nhẹ\nThời lượng pin 5h\nSạc không dây', 2990000.00, 5, 150, 'tainghe6.jpg', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(21, 4, 'AirPods SE', 'AirPods SE phiên bản tiết kiệm', 'Chip W1\nÂm thanh cân bằng\nThời lượng pin 5h\nSạc Lightning', 2490000.00, 0, 200, 'tainghe7.webp', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(22, 4, 'AirPods Pro Max', 'AirPods Pro Max cao cấp', 'Chip H1\nChống ồn cao cấp\nÂm thanh Dolby\nThời lượng pin 8h', 8990000.00, 15, 80, 'tainghe5.png', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(23, 4, 'AirPods Pro Gen 1', 'AirPods Pro thế hệ đầu tiên', 'Chip H1\nChống ồn chủ động\nChống nước IPX4\nThời lượng pin 4.5h', 5490000.00, 10, 100, 'tainghe3.jpg', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50'),
(24, 4, 'AirPods 2', 'AirPods thế hệ 2 với chip H1', 'Chip H1\nHey Siri\nSạc không dây\nThời lượng pin 5h', 3990000.00, 5, 140, '1764061540_1763983846_airpods2.webp', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 09:05:40'),
(25, 4, 'AirPods Pro 2022', 'AirPods Pro phiên bản 2022', 'Chip H2\nChống ồn thế hệ mới\nÂm thanh 3D\nThời lượng pin 6h', 6990000.00, 10, 90, 'tainghe4.png', NULL, 0, 'active', 0, '2025-11-25 08:50:50', '2025-11-25 08:50:50');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` enum('customer','admin') DEFAULT 'customer',
  `status` enum('active','inactive','banned') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@applestore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Quản trị viên', '0123456789', 'TP. Hồ Chí Minh', 'admin', 'active', '2025-11-25 08:50:31', '2025-11-25 08:50:31'),
(2, 'Duy', 'duyvo19102005@gmail.com', '$2y$10$Vz3hmuJT0Vnv5I4wcTFw2eC.rXiRm6da7om4XPEoiG7rZ34LddTSO', 'Võ Thanh Duy', '0932716519', 'abc', 'customer', 'active', '2025-11-25 09:13:42', '2025-11-25 11:45:52'),
(3, 'Thư', 'thu@gmail.com', '$2y$10$2yeSdqOzjqlH.Zbcy.b34.tgk4ghp6AUIaKJK6apSsxylnlRWaBkS', 'Phạm Trần Minh Thư', '123456789', NULL, 'customer', 'active', '2025-11-25 11:48:21', '2025-11-25 11:48:21');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD UNIQUE KEY `unique_cart_item` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`order_status`),
  ADD KEY `idx_order_number` (`order_number`);

--
-- Chỉ mục cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_featured` (`is_featured`);
ALTER TABLE `products` ADD FULLTEXT KEY `idx_search` (`product_name`,`description`);

--
-- Chỉ mục cho bảng `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_status` (`status`);

--
-- Chỉ mục cho bảng `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_username` (`username`);

--
-- Chỉ mục cho bảng `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wishlist_id`),
  ADD UNIQUE KEY `unique_wishlist` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT cho bảng `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
