<?php
/**
 * RESTful API Entry Point
 */

// Headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Start session
session_start();

// Load configuration
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Load core classes
require_once __DIR__ . '/../core/Model.php';

// Load models
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Order.php';

// Get request method and endpoint
$method = $_SERVER['REQUEST_METHOD'];
$request = isset($_GET['request']) ? $_GET['request'] : '';

// Handle OPTIONS request
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Helper function to send JSON response
function sendResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Helper function to get request body
function getRequestBody() {
    return json_decode(file_get_contents('php://input'), true);
}

// Router
try {
    switch ($request) {
        // Product endpoints
        case 'products':
            if ($method === 'GET') {
                $productModel = new Product();
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;
                $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
                $categoryId = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
                $search = isset($_GET['search']) ? $_GET['search'] : null;
                
                if ($search) {
                    $products = $productModel->search($search, $categoryId, $limit, $offset);
                } elseif ($categoryId) {
                    $products = $productModel->getByCategory($categoryId, $limit, $offset);
                } else {
                    $products = $productModel->getAllProducts($limit, $offset);
                }
                
                sendResponse(['success' => true, 'data' => $products]);
            }
            break;
            
        case 'products/featured':
            if ($method === 'GET') {
                $productModel = new Product();
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 6;
                $products = $productModel->getFeaturedProducts($limit);
                sendResponse(['success' => true, 'data' => $products]);
            }
            break;
            
        case 'product':
            if ($method === 'GET') {
                $productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                if (!$productId) {
                    sendResponse(['success' => false, 'message' => 'Product ID required'], 400);
                }
                
                $productModel = new Product();
                $product = $productModel->getProductDetails($productId);
                
                if ($product) {
                    sendResponse(['success' => true, 'data' => $product]);
                } else {
                    sendResponse(['success' => false, 'message' => 'Product not found'], 404);
                }
            }
            break;
            
        // Category endpoints
        case 'categories':
            if ($method === 'GET') {
                $categoryModel = new Category();
                $categories = $categoryModel->getCategoriesWithCount();
                sendResponse(['success' => true, 'data' => $categories]);
            }
            break;
            
        // Auth endpoints
        case 'auth/login':
            if ($method === 'POST') {
                $data = getRequestBody();
                $email = $data['email'] ?? '';
                $password = $data['password'] ?? '';
                
                if (empty($email) || empty($password)) {
                    sendResponse(['success' => false, 'message' => 'Email and password required'], 400);
                }
                
                $userModel = new User();
                $result = $userModel->login($email, $password);
                
                if ($result['success']) {
                    sendResponse([
                        'success' => true,
                        'message' => 'Login successful',
                        'user' => $result['user']
                    ]);
                } else {
                    sendResponse(['success' => false, 'message' => $result['message']], 401);
                }
            }
            break;
            
        case 'auth/register':
            if ($method === 'POST') {
                $data = getRequestBody();
                
                $required = ['username', 'email', 'password', 'full_name'];
                foreach ($required as $field) {
                    if (empty($data[$field])) {
                        sendResponse(['success' => false, 'message' => "Field {$field} is required"], 400);
                    }
                }
                
                $userModel = new User();
                
                // Check existing user
                if ($userModel->emailExists($data['email'])) {
                    sendResponse(['success' => false, 'message' => 'Email already exists'], 400);
                }
                if ($userModel->usernameExists($data['username'])) {
                    sendResponse(['success' => false, 'message' => 'Username already exists'], 400);
                }
                
                // Force customer role for security - prevent privilege escalation
                $data['role'] = 'customer';
                $data['status'] = 'active';
                
                $userId = $userModel->register($data);
                
                if ($userId) {
                    sendResponse(['success' => true, 'message' => 'Registration successful', 'user_id' => $userId], 201);
                } else {
                    sendResponse(['success' => false, 'message' => 'Registration failed'], 500);
                }
            }
            break;
            
        case 'auth/logout':
            if ($method === 'POST') {
                $userModel = new User();
                $userModel->logout();
                sendResponse(['success' => true, 'message' => 'Logout successful']);
            }
            break;
            
        // Cart endpoints (requires authentication)
        case 'cart':
            if (!Auth::check()) {
                sendResponse(['success' => false, 'message' => 'Authentication required'], 401);
            }
            
            $cartModel = new Cart();
            $userId = Auth::id();
            
            if ($method === 'GET') {
                $items = $cartModel->getCartItems($userId);
                $total = $cartModel->getCartTotal($userId);
                $count = $cartModel->getCartCount($userId);
                
                sendResponse([
                    'success' => true,
                    'data' => [
                        'items' => $items,
                        'total' => $total,
                        'count' => $count
                    ]
                ]);
            } elseif ($method === 'POST') {
                $data = getRequestBody();
                $productId = $data['product_id'] ?? 0;
                $quantity = $data['quantity'] ?? 1;
                
                if (!$productId) {
                    sendResponse(['success' => false, 'message' => 'Product ID required'], 400);
                }
                
                $result = $cartModel->addItem($userId, $productId, $quantity);
                
                if ($result) {
                    $cartCount = $cartModel->getCartCount($userId);
                    sendResponse([
                        'success' => true, 
                        'message' => 'Item added to cart',
                        'cart_count' => $cartCount
                    ], 201);
                } else {
                    sendResponse(['success' => false, 'message' => 'Failed to add item'], 500);
                }
            } elseif ($method === 'PUT') {
                $data = getRequestBody();
                $productId = $data['product_id'] ?? 0;
                $quantity = $data['quantity'] ?? 1;
                
                if (!$productId) {
                    sendResponse(['success' => false, 'message' => 'Product ID required'], 400);
                }
                
                $result = $cartModel->updateQuantity($userId, $productId, $quantity);
                
                if ($result) {
                    sendResponse(['success' => true, 'message' => 'Cart updated']);
                } else {
                    sendResponse(['success' => false, 'message' => 'Failed to update cart'], 500);
                }
            } elseif ($method === 'DELETE') {
                $productId = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
                
                if (!$productId) {
                    sendResponse(['success' => false, 'message' => 'Product ID required'], 400);
                }
                
                $result = $cartModel->removeItem($userId, $productId);
                
                if ($result) {
                    sendResponse(['success' => true, 'message' => 'Item removed from cart']);
                } else {
                    sendResponse(['success' => false, 'message' => 'Failed to remove item'], 500);
                }
            }
            break;
            
        // Order endpoints (requires authentication)
        case 'orders':
            if (!Auth::check()) {
                sendResponse(['success' => false, 'message' => 'Authentication required'], 401);
            }
            
            $orderModel = new Order();
            $userId = Auth::id();
            
            if ($method === 'GET') {
                $orders = $orderModel->getOrdersByUser($userId);
                sendResponse(['success' => true, 'data' => $orders]);
            } elseif ($method === 'POST') {
                $data = getRequestBody();
                
                $required = ['shipping_address', 'phone'];
                foreach ($required as $field) {
                    if (empty($data[$field])) {
                        sendResponse(['success' => false, 'message' => "Field {$field} is required"], 400);
                    }
                }
                
                // Get cart items
                $cartModel = new Cart();
                $cartItems = $cartModel->getCartItems($userId);
                
                if (empty($cartItems)) {
                    sendResponse(['success' => false, 'message' => 'Cart is empty'], 400);
                }
                
                // Create order
                $result = $orderModel->createOrder($userId, $data, $cartItems);
                
                if ($result['success']) {
                    sendResponse([
                        'success' => true,
                        'message' => 'Order created successfully',
                        'order_id' => $result['order_id'],
                        'order_number' => $result['order_number']
                    ], 201);
                } else {
                    sendResponse(['success' => false, 'message' => $result['message']], 500);
                }
            }
            break;
            
        case 'order':
            if (!Auth::check()) {
                sendResponse(['success' => false, 'message' => 'Authentication required'], 401);
            }
            
            $orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
            if (!$orderId) {
                sendResponse(['success' => false, 'message' => 'Order ID required'], 400);
            }
            
            $orderModel = new Order();
            $order = $orderModel->getOrderDetails($orderId);
            
            if (!$order || $order['user_id'] != Auth::id()) {
                sendResponse(['success' => false, 'message' => 'Order not found'], 404);
            }
            
            sendResponse(['success' => true, 'data' => $order]);
            break;
            
        default:
            sendResponse(['success' => false, 'message' => 'Invalid endpoint'], 404);
            break;
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    sendResponse(['success' => false, 'message' => 'Internal server error: ' . $e->getMessage()], 500);
}


