<?php
/**
 * Admin Categories Management
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/Category.php';

$categoryModel = new Category();

// Handle actions
$action = $_GET['action'] ?? 'list';
$categoryId = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $data = [
                    'category_name' => trim($_POST['category_name']),
                    'description' => trim($_POST['description']),
                    'display_order' => intval($_POST['display_order'] ?? 0),
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                if ($categoryModel->create($data)) {
                    $_SESSION['success'] = 'Thêm danh mục thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi thêm danh mục'];
                }
                header('Location: ' . BASE_URL . 'admin/categories.php');
                exit;
                
            case 'update':
                $data = [
                    'category_name' => trim($_POST['category_name']),
                    'description' => trim($_POST['description']),
                    'display_order' => intval($_POST['display_order'] ?? 0),
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                if ($categoryModel->update($_POST['category_id'], $data)) {
                    $_SESSION['success'] = 'Cập nhật danh mục thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật danh mục'];
                }
                header('Location: ' . BASE_URL . 'admin/categories.php');
                exit;
                
            case 'delete':
                if ($categoryModel->delete($_POST['category_id'])) {
                    $_SESSION['success'] = 'Xóa danh mục thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi xóa danh mục'];
                }
                header('Location: ' . BASE_URL . 'admin/categories.php');
                exit;
        }
    }
}

// Get data based on action
$categories = [];
$category = null;

switch ($action) {
    case 'view':
        if ($categoryId) {
            $category = $categoryModel->getCategoryWithProducts($categoryId);
            
            // If AJAX request, return only the content
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                // Return only the view content
                include __DIR__ . '/../helpers/Helper.php';
                ?>
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="mb-4"><?= e($category['category_name']) ?></h4>
                        
                        <table class="table table-bordered">
                            <tr>
                                <th width="30%">Tên danh mục</th>
                                <td><strong><?= e($category['category_name']) ?></strong></td>
                            </tr>
                            <tr>
                                <th>Mô tả</th>
                                <td><?= e($category['description'] ?? 'Chưa có mô tả') ?></td>
                            </tr>
                            <tr>
                                <th>Số sản phẩm</th>
                                <td>
                                    <span class="badge badge-info" style="font-size: 16px;">
                                        <?= isset($category['product_count']) ? $category['product_count'] : 0 ?> sản phẩm
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Thứ tự hiển thị</th>
                                <td><?= e($category['display_order']) ?></td>
                            </tr>
                            <tr>
                                <th>Trạng thái</th>
                                <td>
                                    <span class="badge <?= $category['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>" style="font-size: 14px;">
                                        <?= $category['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Ngày tạo</th>
                                <td><?= date('d/m/Y H:i', strtotime($category['created_at'])) ?></td>
                            </tr>
                            <?php if (isset($category['updated_at']) && $category['updated_at']): ?>
                            <tr>
                                <th>Cập nhật lần cuối</th>
                                <td><?= date('d/m/Y H:i', strtotime($category['updated_at'])) ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>

                        <?php if (isset($category['products']) && !empty($category['products'])): ?>
                        <div class="mt-4">
                            <h5 class="mb-3"><i class="fas fa-boxes"></i> Sản phẩm trong danh mục</h5>
                            <div class="row">
                                <?php foreach (array_slice($category['products'], 0, 6) as $product): ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card">
                                        <img src="<?= getProductImage($product['image']) ?>" class="card-img-top" alt="<?= e($product['product_name']) ?>" style="height: 150px; object-fit: cover;">
                                        <div class="card-body">
                                            <h6 class="card-title" style="font-size: 14px;"><?= e($product['product_name']) ?></h6>
                                            <p class="card-text">
                                                <strong class="text-primary"><?= formatCurrency($product['price']) ?></strong>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php if (count($category['products']) > 6): ?>
                            <p class="text-muted"><small>Và <?= count($category['products']) - 6 ?> sản phẩm khác...</small></p>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info mt-4">
                            <i class="fas fa-info-circle"></i> Danh mục này chưa có sản phẩm nào.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php
                exit; // Stop execution here for AJAX
            }
        }
        $categories = $categoryModel->getCategoriesWithCount();
        break;
    case 'list':
        $categories = $categoryModel->getCategoriesWithCount();
        break;
    case 'edit':
        if ($categoryId) {
            $category = $categoryModel->find($categoryId);
            
            // If AJAX request, return only the content
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                include __DIR__ . '/../helpers/Helper.php';
                
                // Get product count
                $countResult = $categoryModel->query(
                    "SELECT COUNT(*) as product_count FROM products WHERE category_id = ?",
                    [$categoryId]
                );
                $productCount = $countResult[0]['product_count'] ?? 0;
                ?>
                <div class="form-group">
                    <label>Tên danh mục *</label>
                    <input type="text" class="form-control" name="category_name" value="<?= e($category['category_name']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Mô tả</label>
                    <textarea class="form-control" name="description" rows="3"><?= e($category['description']) ?></textarea>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Thứ tự hiển thị</label>
                            <input type="number" class="form-control" name="display_order" value="<?= $category['display_order'] ?>" min="0">
                            <small class="form-text text-muted">Số thứ tự càng nhỏ sẽ hiển thị càng trước</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Trạng thái</label>
                            <select class="form-control" name="status">
                                <option value="active" <?= $category['status'] === 'active' ? 'selected' : '' ?>>Hoạt động</option>
                                <option value="inactive" <?= $category['status'] === 'inactive' ? 'selected' : '' ?>>Không hoạt động</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Danh mục này có <strong><?= $productCount ?></strong> sản phẩm.
                </div>
                <?php
                exit;
            }
        }
        $categories = $categoryModel->getCategoriesWithCount();
        break;
}

$title = 'Quản lý danh mục - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table thead th {
            border: none;
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px;
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 8px 16px;
        }
        
        .btn-sm {
            padding: 6px 12px;
        }
        
        /* Forms */
        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 10px 15px;
        }
        
        .form-control:focus {
            border-color: #0ea5e9;
            box-shadow: 0 0 0 0.2rem rgba(14, 165, 233, 0.25);
        }
        
        /* Modal */
        .modal-content {
            border-radius: 15px;
            border: none;
        }
        
        .modal-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-store"></i> APPLE STORE</h4>
            <div class="admin-name"><?= e($_SESSION['full_name']) ?></div>
        </div>

        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-list"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i> Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php">
                        <i class="fas fa-home"></i> Về trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=logout">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1>Quản lý danh mục</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>admin/index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Danh mục</li>
                    </ol>
                </nav>
            </div>
            <div>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addCategoryModal">
                    <i class="fas fa-plus"></i> Thêm danh mục
                </button>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?= e($error) ?><br>
                <?php endforeach; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <!-- Categories List -->
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-list"></i> Danh sách danh mục</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="categoriesTable">
                        <thead>
                            <tr>
                                <th>Tên danh mục</th>
                                <th>Mô tả</th>
                                <th>Số sản phẩm</th>
                                <th>Thứ tự hiển thị</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($categories)): ?>
                                <tr>
                                    <td colspan="6" class="text-center" style="padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 3rem; color: #d1d5db; margin-bottom: 15px;"></i>
                                        <p style="color: #6b7280; font-size: 1.1rem;">Chưa có danh mục nào</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($categories as $category): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($category['category_name']) ?></strong>
                                        </td>
                                        <td><?= e($category['description'] ?? '') ?></td>
                                        <td>
                                            <span class="badge badge-info"><?= $category['product_count'] ?? 0 ?></span>
                                        </td>
                                        <td><?= $category['display_order'] ?></td>
                                        <td>
                                            <span class="badge <?= $category['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>">
                                                <?= $category['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" onclick="viewCategory(<?= $category['category_id'] ?>)" title="Xem chi tiết">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-info" onclick="editCategory(<?= $category['category_id'] ?>)" title="Chỉnh sửa">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteCategory(<?= $category['category_id'] ?>, '<?= e($category['category_name']) ?>')" title="Xóa">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Thêm danh mục mới</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="create">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Tên danh mục *</label>
                            <input type="text" class="form-control" name="category_name" required>
                        </div>

                        <div class="form-group">
                            <label>Mô tả</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Thứ tự hiển thị</label>
                                    <input type="number" class="form-control" name="display_order" min="0" value="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Trạng thái</label>
                                    <select class="form-control" name="status">
                                        <option value="active">Hoạt động</option>
                                        <option value="inactive">Không hoạt động</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Thêm danh mục</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Category Modal -->
    <div class="modal fade" id="viewCategoryModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-eye"></i> Chi tiết danh mục</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" id="viewCategoryBody">
                    <!-- Content will be loaded dynamically -->
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Chỉnh sửa danh mục</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" id="editCategoryForm">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="category_id" id="edit_category_id">
                    <div class="modal-body" id="editCategoryBody">
                        <!-- Content will be loaded dynamically -->
                        <div class="text-center">
                            <div class="spinner-border" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-trash"></i> Xác nhận xóa</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa danh mục <strong id="deleteCategoryName"></strong>?</p>
                    <p class="text-danger"><small>Hành động này không thể hoàn tác!</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="category_id" id="delete_category_id">
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize DataTable only if table has rows
            <?php if (!empty($categories)): ?>
            $('#categoriesTable').DataTable({
                "language": {
                    "sProcessing": "Đang xử lý...",
                    "sLengthMenu": "Xem _MENU_ mục",
                    "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
                    "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
                    "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
                    "sInfoFiltered": "(được lọc từ _MAX_ mục)",
                    "sInfoPostFix": "",
                    "sSearch": "Tìm kiếm:",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "Đầu",
                        "sPrevious": "Trước",
                        "sNext": "Tiếp",
                        "sLast": "Cuối"
                    }
                },
                "order": [[ 3, "asc" ]],
                "pageLength": 25
            });
            <?php endif; ?>

            // Auto-hide alerts
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        });

        // View category details
        function viewCategory(categoryId) {
            $('#viewCategoryModal').modal('show');
            $('#viewCategoryBody').html('<div class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            
            // Fetch category details via AJAX
            $.ajax({
                url: '<?= BASE_URL ?>admin/categories.php?action=view&id=' + categoryId,
                method: 'GET',
                dataType: 'html',
                success: function(response) {
                    $('#viewCategoryBody').html(response);
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    $('#viewCategoryBody').html('<div class="alert alert-danger">Không thể tải thông tin danh mục</div>');
                }
            });
        }

        // Edit category
        function editCategory(categoryId) {
            $('#edit_category_id').val(categoryId);
            $('#editCategoryModal').modal('show');
            $('#editCategoryBody').html('<div class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            
            // Fetch category form via AJAX
            $.ajax({
                url: '<?= BASE_URL ?>admin/categories.php?action=edit&id=' + categoryId,
                method: 'GET',
                dataType: 'html',
                success: function(response) {
                    $('#editCategoryBody').html(response);
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    $('#editCategoryBody').html('<div class="alert alert-danger">Không thể tải form sửa danh mục</div>');
                }
            });
        }

        // Delete category
        function deleteCategory(categoryId, categoryName) {
            $('#delete_category_id').val(categoryId);
            $('#deleteCategoryName').text(categoryName);
            $('#deleteCategoryModal').modal('show');
        }
    </script>
</body>
</html>
