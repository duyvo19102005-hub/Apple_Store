<?php
/**
 * Admin Order Detail Page
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/User.php';

$orderModel = new Order();
$userModel = new User();

// Get order ID from URL
$orderId = $_GET['id'] ?? null;

if (!$orderId) {
    $_SESSION['errors'] = ['Không tìm thấy đơn hàng'];
    header('Location: ' . BASE_URL . 'admin/orders.php');
    exit;
}

// Get order details
$order = $orderModel->getOrderDetails($orderId);

if (!$order) {
    $_SESSION['errors'] = ['Không tìm thấy đơn hàng'];
    header('Location: ' . BASE_URL . 'admin/orders.php');
    exit;
}

// Get customer info
$customer = $userModel->find($order['user_id']);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_status':
                $data = [
                    'order_status' => $_POST['order_status']
                ];
                
                if ($orderModel->update($orderId, $data)) {
                    $_SESSION['success'] = 'Cập nhật trạng thái đơn hàng thành công!';
                    // Refresh order data
                    $order = $orderModel->getOrderDetails($orderId);
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật trạng thái đơn hàng'];
                }
                break;
                
            case 'update_payment':
                $data = [
                    'payment_status' => $_POST['payment_status']
                ];
                
                if ($orderModel->update($orderId, $data)) {
                    $_SESSION['success'] = 'Cập nhật trạng thái thanh toán thành công!';
                    // Refresh order data
                    $order = $orderModel->getOrderDetails($orderId);
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật trạng thái thanh toán'];
                }
                break;
        }
    }
}

$title = 'Chi tiết đơn hàng #' . $order['order_number'] . ' - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Status Badges */
        .badge {
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            border-radius: 20px;
        }
        
        .badge-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-confirmed {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-shipping {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .badge-delivered {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-cancelled {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .badge-paid {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-unpaid {
            background: #fef3c7;
            color: #92400e;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table th {
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            padding: 15px;
            border: 1px solid #e5e7eb;
        }
        
        .table td {
            padding: 15px;
            vertical-align: middle;
            border: 1px solid #e5e7eb;
        }
        
        /* Info Box */
        .info-box {
            background: #f8f9fa;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid #0ea5e9;
        }
        
        .info-box .label {
            font-size: 0.85rem;
            color: #6b7280;
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .info-box .value {
            font-size: 1rem;
            color: #1a1a2e;
            font-weight: 600;
        }
        
        /* Timeline */
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e5e7eb;
        }
        
        .timeline-item {
            position: relative;
            padding-bottom: 20px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -24px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #0ea5e9;
            border: 3px solid #fff;
            box-shadow: 0 0 0 2px #0ea5e9;
        }
        
        .timeline-item.active::before {
            background: #10b981;
            box-shadow: 0 0 0 2px #10b981;
        }
        
        .timeline-item .timeline-content {
            background: #f8f9fa;
            padding: 12px 15px;
            border-radius: 8px;
        }
        
        .timeline-item .timeline-title {
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 3px;
        }
        
        .timeline-item .timeline-time {
            font-size: 0.85rem;
            color: #6b7280;
        }
        
        /* Buttons */
        .btn {
            padding: 10px 20px;
            font-weight: 500;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            border: none;
            color: #fff;
        }
        
        .btn-warning:hover {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            border: none;
        }
        
        .btn-danger:hover {
            background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        .btn-secondary {
            background: #6b7280;
            border: none;
        }
        
        .btn-secondary:hover {
            background: #4b5563;
        }
        
        /* Alerts */
        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }
        
        .alert i {
            margin-right: 10px;
        }
        
        /* Product Image */
        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        /* Summary Box */
        .summary-box {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            padding: 25px;
            border-radius: 15px;
            margin-top: 20px;
        }
        
        .summary-box h4 {
            font-size: 1.1rem;
            margin-bottom: 15px;
            font-weight: 600;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .summary-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
            font-size: 1.2rem;
            font-weight: 700;
            padding-top: 10px;
            border-top: 2px solid rgba(255,255,255,0.3);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -260px;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-apple-alt"></i> Apple Store</h4>
            <p class="admin-name">Quản trị viên</p>
        </div>
        
        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i>
                        Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-tags"></i>
                        Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i>
                        Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i>
                        Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>">
                        <i class="fas fa-home"></i>
                        Trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>?action=logout">
                        <i class="fas fa-sign-out-alt"></i>
                        Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1><i class="fas fa-file-invoice"></i> Chi tiết đơn hàng</h1>
                <p class="text-muted mb-0" style="margin-top: 5px;">Mã đơn hàng: <strong class="text-primary"><?= e($order['order_number']) ?></strong></p>
            </div>
            <div>
                <a href="<?= BASE_URL ?>admin/orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Quay lại
                </a>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?= e($error) ?><br>
                <?php endforeach; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <div class="row">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Order Items -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-shopping-bag"></i> Sản phẩm đã đặt</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th width="80">Hình ảnh</th>
                                        <th>Sản phẩm</th>
                                        <th width="120" class="text-center">Đơn giá</th>
                                        <th width="100" class="text-center">Giảm giá</th>
                                        <th width="80" class="text-center">Số lượng</th>
                                        <th width="140" class="text-right">Thành tiền</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (isset($order['items']) && !empty($order['items'])): ?>
                                        <?php foreach ($order['items'] as $item): ?>
                                        <tr>
                                            <td>
                                                <img src="<?= getProductImage($item['image']) ?>" alt="<?= e($item['product_name']) ?>" class="product-img">
                                            </td>
                                            <td>
                                                <strong><?= e($item['product_name']) ?></strong>
                                            </td>
                                            <td class="text-center"><?= formatCurrency($item['price']) ?></td>
                                            <td class="text-center">
                                                <?php if ($item['discount_percent'] > 0): ?>
                                                    <span class="badge badge-danger"><?= $item['discount_percent'] ?>%</span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <strong><?= $item['quantity'] ?></strong>
                                            </td>
                                            <td class="text-right">
                                                <strong class="text-primary"><?= formatCurrency($item['subtotal']) ?></strong>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted py-4">
                                                <i class="fas fa-inbox" style="font-size: 2rem;"></i>
                                                <p class="mt-2 mb-0">Không có sản phẩm</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Order Summary -->
                        <div class="summary-box">
                            <h4><i class="fas fa-calculator"></i> Tổng kết đơn hàng</h4>
                            <div class="summary-item">
                                <span>Tổng tiền hàng:</span>
                                <strong><?= formatCurrency($order['total_amount']) ?></strong>
                            </div>
                            <?php if ($order['discount_amount'] > 0): ?>
                            <div class="summary-item">
                                <span>Giảm giá:</span>
                                <strong>-<?= formatCurrency($order['discount_amount']) ?></strong>
                            </div>
                            <?php endif; ?>
                            <div class="summary-item">
                                <span>Tổng thanh toán:</span>
                                <strong><?= formatCurrency($order['final_amount']) ?></strong>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Shipping Information -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-truck"></i> Thông tin giao hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-box">
                                    <div class="label">Người nhận</div>
                                    <div class="value"><?= e($customer['full_name'] ?? 'N/A') ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <div class="label">Số điện thoại</div>
                                    <div class="value"><?= e($order['phone']) ?></div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="info-box">
                                    <div class="label">Địa chỉ giao hàng</div>
                                    <div class="value"><?= e($order['shipping_address']) ?></div>
                                </div>
                            </div>
                            <?php if (!empty($order['notes'])): ?>
                            <div class="col-12">
                                <div class="info-box">
                                    <div class="label">Ghi chú</div>
                                    <div class="value"><?= e($order['notes']) ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Order Status -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-info-circle"></i> Trạng thái đơn hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="info-box">
                            <div class="label">Trạng thái hiện tại</div>
                            <div class="value">
                                <?php
                                $statusClass = 'badge-secondary';
                                $statusText = 'Không xác định';
                                switch($order['order_status']) {
                                    case 'pending':
                                        $statusClass = 'badge-pending';
                                        $statusText = 'Chờ xác nhận';
                                        break;
                                    case 'confirmed':
                                        $statusClass = 'badge-confirmed';
                                        $statusText = 'Đã xác nhận';
                                        break;
                                    case 'shipping':
                                        $statusClass = 'badge-shipping';
                                        $statusText = 'Đang giao';
                                        break;
                                    case 'delivered':
                                        $statusClass = 'badge-delivered';
                                        $statusText = 'Đã giao';
                                        break;
                                    case 'cancelled':
                                        $statusClass = 'badge-cancelled';
                                        $statusText = 'Đã hủy';
                                        break;
                                }
                                ?>
                                <span class="badge <?= $statusClass ?>" style="font-size: 14px;"><?= $statusText ?></span>
                            </div>
                        </div>
                        
                        <form method="POST" class="mt-3">
                            <input type="hidden" name="action" value="update_status">
                            <div class="form-group">
                                <label><strong>Cập nhật trạng thái</strong></label>
                                <select class="form-control" name="order_status">
                                    <option value="pending" <?= $order['order_status'] === 'pending' ? 'selected' : '' ?>>Chờ xác nhận</option>
                                    <option value="confirmed" <?= $order['order_status'] === 'confirmed' ? 'selected' : '' ?>>Đã xác nhận</option>
                                    <option value="shipping" <?= $order['order_status'] === 'shipping' ? 'selected' : '' ?>>Đang giao</option>
                                    <option value="delivered" <?= $order['order_status'] === 'delivered' ? 'selected' : '' ?>>Đã giao</option>
                                    <option value="cancelled" <?= $order['order_status'] === 'cancelled' ? 'selected' : '' ?>>Đã hủy</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Cập nhật trạng thái
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Payment Status -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-credit-card"></i> Thanh toán</h5>
                    </div>
                    <div class="card-body">
                        <div class="info-box">
                            <div class="label">Phương thức thanh toán</div>
                            <div class="value">
                                <?php
                                $paymentMethod = $order['payment_method'] ?? 'cod';
                                echo $paymentMethod === 'cod' ? '<i class="fas fa-money-bill-wave"></i> Thanh toán khi nhận hàng (COD)' : '<i class="fas fa-university"></i> Chuyển khoản ngân hàng';
                                ?>
                            </div>
                        </div>
                        
                        <div class="info-box">
                            <div class="label">Trạng thái thanh toán</div>
                            <div class="value">
                                <span class="badge <?= $order['payment_status'] === 'paid' ? 'badge-paid' : 'badge-unpaid' ?>" style="font-size: 14px;">
                                    <?= $order['payment_status'] === 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán' ?>
                                </span>
                            </div>
                        </div>
                        
                        <form method="POST" class="mt-3">
                            <input type="hidden" name="action" value="update_payment">
                            <div class="form-group">
                                <label><strong>Cập nhật trạng thái thanh toán</strong></label>
                                <select class="form-control" name="payment_status">
                                    <option value="unpaid" <?= $order['payment_status'] === 'unpaid' ? 'selected' : '' ?>>Chưa thanh toán</option>
                                    <option value="paid" <?= $order['payment_status'] === 'paid' ? 'selected' : '' ?>>Đã thanh toán</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success btn-block">
                                <i class="fas fa-save"></i> Cập nhật thanh toán
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Order Info -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-clock"></i> Thông tin đơn hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="info-box">
                            <div class="label">Mã đơn hàng</div>
                            <div class="value"><?= e($order['order_number']) ?></div>
                        </div>
                        
                        <div class="info-box">
                            <div class="label">Khách hàng</div>
                            <div class="value">
                                <?= e($customer['full_name'] ?? 'N/A') ?><br>
                                <small class="text-muted"><?= e($customer['email'] ?? 'N/A') ?></small>
                            </div>
                        </div>
                        
                        <div class="info-box">
                            <div class="label">Ngày đặt hàng</div>
                            <div class="value"><?= date('d/m/Y H:i:s', strtotime($order['created_at'])) ?></div>
                        </div>
                        
                        <?php if ($order['updated_at']): ?>
                        <div class="info-box">
                            <div class="label">Cập nhật lần cuối</div>
                            <div class="value"><?= date('d/m/Y H:i:s', strtotime($order['updated_at'])) ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Order Timeline -->
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-history"></i> Lịch sử đơn hàng</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <div class="timeline-item <?= in_array($order['order_status'], ['pending', 'confirmed', 'shipping', 'delivered']) ? 'active' : '' ?>">
                                <div class="timeline-content">
                                    <div class="timeline-title">Đơn hàng đã đặt</div>
                                    <div class="timeline-time"><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></div>
                                </div>
                            </div>
                            
                            <div class="timeline-item <?= in_array($order['order_status'], ['confirmed', 'shipping', 'delivered']) ? 'active' : '' ?>">
                                <div class="timeline-content">
                                    <div class="timeline-title">Đã xác nhận</div>
                                    <div class="timeline-time">
                                        <?php if (in_array($order['order_status'], ['confirmed', 'shipping', 'delivered'])): ?>
                                            <?= date('d/m/Y H:i', strtotime($order['updated_at'])) ?>
                                        <?php else: ?>
                                            Chờ xác nhận
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="timeline-item <?= in_array($order['order_status'], ['shipping', 'delivered']) ? 'active' : '' ?>">
                                <div class="timeline-content">
                                    <div class="timeline-title">Đang giao hàng</div>
                                    <div class="timeline-time">
                                        <?php if (in_array($order['order_status'], ['shipping', 'delivered'])): ?>
                                            Đang vận chuyển
                                        <?php else: ?>
                                            Chưa giao
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="timeline-item <?= $order['order_status'] === 'delivered' ? 'active' : '' ?>">
                                <div class="timeline-content">
                                    <div class="timeline-title">Đã giao hàng</div>
                                    <div class="timeline-time">
                                        <?php if ($order['order_status'] === 'delivered'): ?>
                                            Giao hàng thành công
                                        <?php else: ?>
                                            Chưa giao
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if ($order['order_status'] === 'cancelled'): ?>
                            <div class="timeline-item active">
                                <div class="timeline-content">
                                    <div class="timeline-title text-danger">Đơn hàng đã bị hủy</div>
                                    <div class="timeline-time"><?= date('d/m/Y H:i', strtotime($order['updated_at'])) ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            // Auto-hide alerts
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        });
    </script>
</body>
</html>
