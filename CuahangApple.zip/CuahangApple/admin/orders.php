<?php
/**
 * Admin Orders Management
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/User.php';

$orderModel = new Order();
$userModel = new User();

// Handle actions
$action = $_GET['action'] ?? 'list';
$orderId = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_status':
                $data = [
                    'order_status' => $_POST['order_status']
                ];
                
                if ($orderModel->update($_POST['order_id'], $data)) {
                    $_SESSION['success'] = 'Cập nhật trạng thái đơn hàng thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật trạng thái đơn hàng'];
                }
                header('Location: ' . BASE_URL . 'admin/orders.php');
                exit;
                
            case 'delete':
                if ($orderModel->delete($_POST['order_id'])) {
                    $_SESSION['success'] = 'Xóa đơn hàng thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi xóa đơn hàng'];
                }
                header('Location: ' . BASE_URL . 'admin/orders.php');
                exit;
        }
    }
}

// Get data based on action
$orders = [];
$order = null;

switch ($action) {
    case 'view':
        if ($orderId) {
            $order = $orderModel->getOrderDetails($orderId);
        }
        $orders = $orderModel->getAllOrders();
        break;
    case 'list':
        $orders = $orderModel->getAllOrders();
        break;
}

$title = 'Quản lý đơn hàng - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table thead th {
            border: none;
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px;
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 8px 16px;
        }
        
        .btn-sm {
            padding: 6px 12px;
        }
        
        /* Forms */
        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 10px 15px;
        }
        
        .form-control:focus {
            border-color: #0ea5e9;
            box-shadow: 0 0 0 0.2rem rgba(14, 165, 233, 0.25);
        }
        
        /* Modal */
        .modal-content {
            border-radius: 15px;
            border: none;
        }
        
        .modal-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        /* Order Status Badges */
        .badge-pending { background-color: #f59e0b; }
        .badge-confirmed { background-color: #3b82f6; }
        .badge-shipping { background-color: #8b5cf6; }
        .badge-delivered { background-color: #10b981; }
        .badge-cancelled { background-color: #ef4444; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-store"></i> APPLE STORE</h4>
            <div class="admin-name"><?= e($_SESSION['full_name']) ?></div>
        </div>

        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-list"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i> Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php">
                        <i class="fas fa-home"></i> Về trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=logout">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1>Quản lý đơn hàng</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>admin/index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Đơn hàng</li>
                    </ol>
                </nav>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?= e($error) ?><br>
                <?php endforeach; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <!-- Orders List -->
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-shopping-cart"></i> Danh sách đơn hàng</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="ordersTable">
                        <thead>
                            <tr>
                                <th>Mã đơn hàng</th>
                                <th>Khách hàng</th>
                                <th>Tổng tiền</th>
                                <th>Trạng thái</th>
                                <th>Ngày đặt</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($orders)): ?>
                                <tr>
                                    <td colspan="6" class="text-center" style="padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 3rem; color: #d1d5db; margin-bottom: 15px;"></i>
                                        <p style="color: #6b7280; font-size: 1.1rem;">Chưa có đơn hàng nào</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($order['order_number']) ?></strong>
                                        </td>
                                        <td>
                                            <?= e($order['full_name']) ?><br>
                                            <small class="text-muted"><?= e($order['email']) ?></small>
                                        </td>
                                        <td><strong><?= formatCurrency($order['final_amount']) ?></strong></td>
                                        <td>
                                            <?php
                                            $statusClass = 'badge-secondary';
                                            $statusText = 'Không xác định';

                                            switch($order['order_status']) {
                                                case 'pending':
                                                    $statusClass = 'badge-pending';
                                                    $statusText = 'Chờ xác nhận';
                                                    break;
                                                case 'confirmed':
                                                    $statusClass = 'badge-confirmed';
                                                    $statusText = 'Đã xác nhận';
                                                    break;
                                                case 'shipping':
                                                    $statusClass = 'badge-shipping';
                                                    $statusText = 'Đang giao';
                                                    break;
                                                case 'delivered':
                                                    $statusClass = 'badge-delivered';
                                                    $statusText = 'Đã giao';
                                                    break;
                                                case 'cancelled':
                                                    $statusClass = 'badge-cancelled';
                                                    $statusText = 'Đã hủy';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?= $statusClass ?>"><?= $statusText ?></span>
                                        </td>
                                        <td><?= formatDate($order['created_at']) ?></td>
                                        <td>
                                            <a href="<?= BASE_URL ?>admin/order_detail.php?id=<?= $order['order_id'] ?>" class="btn btn-sm btn-primary" data-toggle="tooltip" title="Xem chi tiết">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-warning" onclick="updateOrderStatus(<?= $order['order_id'] ?>, '<?= e($order['order_number']) ?>', '<?= $order['order_status'] ?>')" data-toggle="tooltip" title="Cập nhật trạng thái">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteOrder(<?= $order['order_id'] ?>, '<?= e($order['order_number']) ?>')" data-toggle="tooltip" title="Xóa">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- View Order Modal -->
    <div class="modal fade" id="viewOrderModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-eye"></i> Chi tiết đơn hàng</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" id="viewOrderBody">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Order Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Cập nhật trạng thái đơn hàng</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" id="update_order_id">
                    <div class="modal-body">
                        <p>Đơn hàng: <strong id="updateOrderNumber"></strong></p>
                        <div class="form-group">
                            <label>Trạng thái mới</label>
                            <select class="form-control" name="order_status" id="new_order_status">
                                <option value="pending">Chờ xác nhận</option>
                                <option value="confirmed">Đã xác nhận</option>
                                <option value="shipping">Đang giao</option>
                                <option value="delivered">Đã giao</option>
                                <option value="cancelled">Đã hủy</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteOrderModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-trash"></i> Xác nhận xóa</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa đơn hàng <strong id="deleteOrderNumber"></strong>?</p>
                    <p class="text-danger"><small>Hành động này không thể hoàn tác!</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="order_id" id="delete_order_id">
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize DataTable only if table has rows
            <?php if (!empty($orders)): ?>
            $('#ordersTable').DataTable({
                "language": {
                    "sProcessing": "Đang xử lý...",
                    "sLengthMenu": "Xem _MENU_ mục",
                    "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
                    "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
                    "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
                    "sInfoFiltered": "(được lọc từ _MAX_ mục)",
                    "sInfoPostFix": "",
                    "sSearch": "Tìm kiếm:",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "Đầu",
                        "sPrevious": "Trước",
                        "sNext": "Tiếp",
                        "sLast": "Cuối"
                    }
                },
                "order": [[ 4, "desc" ]],
                "pageLength": 25
            });
            <?php endif; ?>

            // Auto-hide alerts
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        });

        function viewOrder(orderId) {
            $('#viewOrderModal').modal('show');
            
            $.ajax({
                url: '<?= BASE_URL ?>admin/orders.php?action=view&id=' + orderId,
                method: 'GET',
                success: function(response) {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const content = doc.getElementById('viewOrderContent');
                    
                    if (content) {
                        $('#viewOrderBody').html(content.innerHTML);
                    }
                },
                error: function() {
                    $('#viewOrderBody').html('<div class="alert alert-danger">Không thể tải thông tin đơn hàng</div>');
                }
            });
        }

        function updateOrderStatus(orderId, orderNumber, currentStatus) {
            $('#update_order_id').val(orderId);
            $('#updateOrderNumber').text(orderNumber);
            $('#new_order_status').val(currentStatus);
            $('#updateStatusModal').modal('show');
        }

        function deleteOrder(orderId, orderNumber) {
            $('#delete_order_id').val(orderId);
            $('#deleteOrderNumber').text(orderNumber);
            $('#deleteOrderModal').modal('show');
        }
    </script>
</body>
</html>

<?php if ($action === 'view' && $order): ?>
    <!-- View Order Content (for AJAX) -->
    <div id="viewOrderContent" style="display:none;">
        <div class="row">
            <div class="col-md-6">
                <h5 class="mb-3">Thông tin đơn hàng</h5>
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Mã đơn hàng</th>
                        <td><strong class="text-primary"><?= e($order['order_number']) ?></strong></td>
                    </tr>
                    <tr>
                        <th>Ngày đặt</th>
                        <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                    </tr>
                    <tr>
                        <th>Trạng thái đơn hàng</th>
                        <td>
                            <?php
                            $statusClass = 'badge-secondary';
                            $statusText = 'Không xác định';
                            switch($order['order_status']) {
                                case 'pending': $statusClass = 'badge-pending'; $statusText = 'Chờ xác nhận'; break;
                                case 'confirmed': $statusClass = 'badge-confirmed'; $statusText = 'Đã xác nhận'; break;
                                case 'shipping': $statusClass = 'badge-shipping'; $statusText = 'Đang giao'; break;
                                case 'delivered': $statusClass = 'badge-delivered'; $statusText = 'Đã giao'; break;
                                case 'cancelled': $statusClass = 'badge-cancelled'; $statusText = 'Đã hủy'; break;
                            }
                            ?>
                            <span class="badge <?= $statusClass ?>" style="font-size: 14px;"><?= $statusText ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th>Phương thức thanh toán</th>
                        <td>
                            <?php
                            $paymentMethod = $order['payment_method'] ?? 'cod';
                            echo $paymentMethod === 'cod' ? 'Thanh toán khi nhận hàng (COD)' : 'Chuyển khoản ngân hàng';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Trạng thái thanh toán</th>
                        <td>
                            <span class="badge <?= $order['payment_status'] === 'paid' ? 'badge-success' : 'badge-warning' ?>">
                                <?= $order['payment_status'] === 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán' ?>
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="col-md-6">
                <h5 class="mb-3">Thông tin giao hàng</h5>
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Địa chỉ giao hàng</th>
                        <td><?= e($order['shipping_address']) ?></td>
                    </tr>
                    <tr>
                        <th>Số điện thoại</th>
                        <td><?= e($order['phone']) ?></td>
                    </tr>
                    <?php if (!empty($order['notes'])): ?>
                    <tr>
                        <th>Ghi chú</th>
                        <td><?= e($order['notes']) ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-12">
                <h5 class="mb-3">Sản phẩm đặt hàng</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th width="60">Hình</th>
                                <th>Sản phẩm</th>
                                <th width="120" class="text-center">Đơn giá</th>
                                <th width="100" class="text-center">Giảm giá</th>
                                <th width="80" class="text-center">SL</th>
                                <th width="130" class="text-right">Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (isset($order['items']) && !empty($order['items'])): ?>
                                <?php foreach ($order['items'] as $item): ?>
                                <tr>
                                    <td>
                                        <img src="<?= getProductImage($item['image']) ?>" alt="<?= e($item['product_name']) ?>" class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                    </td>
                                    <td>
                                        <strong><?= e($item['product_name']) ?></strong>
                                    </td>
                                    <td class="text-center"><?= formatCurrency($item['price']) ?></td>
                                    <td class="text-center">
                                        <?php if ($item['discount_percent'] > 0): ?>
                                            <span class="badge badge-danger"><?= $item['discount_percent'] ?>%</span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?= $item['quantity'] ?></td>
                                    <td class="text-right"><strong><?= formatCurrency($item['subtotal']) ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted">Không có sản phẩm</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5" class="text-right"><strong>Tổng tiền hàng:</strong></td>
                                <td class="text-right"><strong><?= formatCurrency($order['total_amount']) ?></strong></td>
                            </tr>
                            <?php if ($order['discount_amount'] > 0): ?>
                            <tr>
                                <td colspan="5" class="text-right"><strong>Giảm giá:</strong></td>
                                <td class="text-right"><strong class="text-danger">-<?= formatCurrency($order['discount_amount']) ?></strong></td>
                            </tr>
                            <?php endif; ?>
                            <tr class="table-info">
                                <td colspan="5" class="text-right"><strong>Tổng thanh toán:</strong></td>
                                <td class="text-right"><strong class="text-primary" style="font-size: 18px;"><?= formatCurrency($order['final_amount']) ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
