<?php
/**
 * Admin Panel Entry Point
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/User.php';

// Get statistics
$productModel = new Product();
$categoryModel = new Category();
$orderModel = new Order();
$userModel = new User();

$totalProducts = $productModel->count();
$totalCategories = $categoryModel->count();
$totalOrders = $orderModel->count();
$totalUsers = $userModel->count();

$orderStats = $orderModel->getStatistics();
$recentOrders = $orderModel->getAllOrders(10);

$title = 'Quản trị - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" 
          integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" 
          crossorigin="anonymous">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        .sidebar-menu .nav-link.active i {
            color: #fff;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        .breadcrumb {
            background: transparent;
            margin: 0;
            padding: 0;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #fff;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border: none;
            border-left: 4px solid #0ea5e9;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, rgba(14, 165, 233, 0.1) 0%, transparent 100%);
            border-radius: 0 0 0 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        .stat-card.success {
            border-left-color: #10b981;
        }
        
        .stat-card.success::before {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, transparent 100%);
        }
        
        .stat-card.warning {
            border-left-color: #f59e0b;
        }
        
        .stat-card.warning::before {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, transparent 100%);
        }
        
        .stat-card.danger {
            border-left-color: #ef4444;
        }
        
        .stat-card.danger::before {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, transparent 100%);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }
        
        .stat-card .stat-icon {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
        }
        
        .stat-card.success .stat-icon {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }
        
        .stat-card.warning .stat-icon {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        }
        
        .stat-card.danger .stat-icon {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        }
        
        .stat-card h5 {
            font-size: 0.85rem;
            color: #6b7280;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
        
        .stat-card h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 10px;
        }
        
        .stat-card .stat-link {
            color: #0ea5e9;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s ease;
        }
        
        .stat-card .stat-link:hover {
            gap: 10px;
            color: #0284c7;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table thead th {
            border: none;
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px;
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        /* Buttons */
        .btn-sm {
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: 500;
        }
        
        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-store"></i> APPLE STORE</h4>
            <div class="admin-name"><?= e($_SESSION['full_name']) ?></div>
        </div>
        
        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-list"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i> Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php">
                        <i class="fas fa-home"></i> Về trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=logout">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1>Dashboard</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active">Tổng quan hệ thống</li>
                    </ol>
                </nav>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-box"></i>
                </div>
                <h5>Sản phẩm</h5>
                <h2><?= $totalProducts ?></h2>
                <a href="<?= BASE_URL ?>admin/products.php" class="stat-link">
                    Xem chi tiết <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <div class="stat-card success">
                <div class="stat-icon">
                    <i class="fas fa-list"></i>
                </div>
                <h5>Danh mục</h5>
                <h2><?= $totalCategories ?></h2>
                <a href="<?= BASE_URL ?>admin/categories.php" class="stat-link">
                    Xem chi tiết <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <div class="stat-card warning">
                <div class="stat-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h5>Đơn hàng</h5>
                <h2><?= $totalOrders ?></h2>
                <a href="<?= BASE_URL ?>admin/orders.php" class="stat-link">
                    Xem chi tiết <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <div class="stat-card danger">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h5>Người dùng</h5>
                <h2><?= $totalUsers ?></h2>
                <a href="<?= BASE_URL ?>admin/users.php" class="stat-link">
                    Xem chi tiết <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
                
        <!-- Charts Row -->
        <div class="row">
            <!-- Order Statistics Chart -->
            <div class="col-md-6">
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-pie"></i> Thống kê đơn hàng</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="orderStatusChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Revenue Chart -->
            <div class="col-md-6">
                <div class="custom-card">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-line"></i> Doanh thu theo tháng</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="revenueChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Additional Statistics -->
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-chart-bar"></i> Thống kê chi tiết</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 text-center">
                        <div style="padding: 20px; background: #fef3c7; border-radius: 10px; margin-bottom: 10px;">
                            <i class="fas fa-clock" style="font-size: 2rem; color: #f59e0b;"></i>
                        </div>
                        <h3 style="font-weight: 700; color: #1a1a2e;"><?= $orderStats['pending_orders'] ?></h3>
                        <p style="color: #6b7280; font-weight: 500;">Chờ xác nhận</p>
                    </div>
                    <div class="col-md-3 text-center">
                        <div style="padding: 20px; background: #d1fae5; border-radius: 10px; margin-bottom: 10px;">
                            <i class="fas fa-check-circle" style="font-size: 2rem; color: #10b981;"></i>
                        </div>
                        <h3 style="font-weight: 700; color: #1a1a2e;"><?= $orderStats['completed_orders'] ?></h3>
                        <p style="color: #6b7280; font-weight: 500;">Hoàn thành</p>
                    </div>
                    <div class="col-md-3 text-center">
                        <div style="padding: 20px; background: #fee2e2; border-radius: 10px; margin-bottom: 10px;">
                            <i class="fas fa-times-circle" style="font-size: 2rem; color: #ef4444;"></i>
                        </div>
                        <h3 style="font-weight: 700; color: #1a1a2e;"><?= $orderStats['cancelled_orders'] ?></h3>
                        <p style="color: #6b7280; font-weight: 500;">Đã hủy</p>
                    </div>
                    <div class="col-md-3 text-center">
                        <div style="padding: 20px; background: #dbeafe; border-radius: 10px; margin-bottom: 10px;">
                            <i class="fas fa-money-bill-wave" style="font-size: 2rem; color: #0ea5e9;"></i>
                        </div>
                        <h3 style="font-weight: 700; color: #1a1a2e; font-size: 1.3rem;"><?= formatCurrency($orderStats['total_revenue']) ?></h3>
                        <p style="color: #6b7280; font-weight: 500;">Doanh thu</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Orders -->
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-shopping-bag"></i> Đơn hàng gần đây</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Mã đơn</th>
                                <th>Khách hàng</th>
                                <th>Tổng tiền</th>
                                <th>Trạng thái</th>
                                <th>Ngày đặt</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="6" class="text-center" style="padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 3rem; color: #d1d5db; margin-bottom: 15px;"></i>
                                        <p style="color: #6b7280; font-size: 1.1rem;">Chưa có đơn hàng nào</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td><strong><?= e($order['order_number']) ?></strong></td>
                                        <td><?= e($order['full_name']) ?></td>
                                        <td><strong><?= formatCurrency($order['final_amount']) ?></strong></td>
                                        <td>
                                            <span class="badge badge-warning">
                                                <?= getOrderStatus($order['order_status']) ?>
                                            </span>
                                        </td>
                                        <td><?= formatDate($order['created_at']) ?></td>
                                        <td>
                                            <a href="<?= BASE_URL ?>admin/order_detail.php?id=<?= $order['order_id'] ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i> Xem
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct"
            crossorigin="anonymous"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });

        // Highlight current nav item
        const currentPath = window.location.pathname;
        document.querySelectorAll('.sidebar-menu .nav-link').forEach(link => {
            if (link.href.includes(currentPath.split('/').pop())) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });

        // Initialize Charts
        $(document).ready(function() {
            // Order Status Pie Chart
            const orderStatusCtx = document.getElementById('orderStatusChart').getContext('2d');
            const orderStatusChart = new Chart(orderStatusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Chờ xác nhận', 'Hoàn thành', 'Đã hủy'],
                    datasets: [{
                        data: [
                            <?= $orderStats['pending_orders'] ?>,
                            <?= $orderStats['completed_orders'] ?>,
                            <?= $orderStats['cancelled_orders'] ?>
                        ],
                        backgroundColor: [
                            '#f59e0b',
                            '#10b981',
                            '#ef4444'
                        ],
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true,
                                font: {
                                    size: 12,
                                    family: 'Inter'
                                }
                            }
                        }
                    }
                }
            });

            // Revenue Line Chart (Sample data - you can replace with real data)
            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            const revenueChart = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],
                    datasets: [{
                        label: 'Doanh thu (VNĐ)',
                        data: [
                            // Sample data - replace with real monthly revenue data
                            12000000, 15000000, 18000000, 22000000, 25000000, 28000000,
                            32000000, 35000000, 38000000, 42000000, 45000000, 48000000
                        ],
                        borderColor: '#0ea5e9',
                        backgroundColor: 'rgba(14, 165, 233, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#0ea5e9',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 7
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return new Intl.NumberFormat('vi-VN', {
                                        style: 'currency',
                                        currency: 'VND'
                                    }).format(value);
                                },
                                font: {
                                    family: 'Inter'
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    family: 'Inter'
                                }
                            },
                            grid: {
                                display: false
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
        });
    </script>
</body>
</html>

