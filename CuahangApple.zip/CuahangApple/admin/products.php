<?php
/**
 * Admin Products Management
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

$productModel = new Product();
$categoryModel = new Category();

// Handle actions
$action = $_GET['action'] ?? 'list';
$productId = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                // Handle image upload
                $imageName = '';
                if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
                    $uploadDir = UPLOAD_PATH;
                    $fileName = $_FILES['image_file']['name'];
                    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'jfif'];
                    
                    if (in_array($fileExt, $allowedExt)) {
                        $newFileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $fileName);
                        $uploadPath = $uploadDir . $newFileName;
                        
                        if (move_uploaded_file($_FILES['image_file']['tmp_name'], $uploadPath)) {
                            $imageName = $newFileName;
                        }
                    }
                }
                
                // If no file uploaded, use URL
                if (empty($imageName) && !empty($_POST['image_url'])) {
                    $imageName = trim($_POST['image_url']);
                }
                
                $data = [
                    'product_name' => trim($_POST['product_name']),
                    'description' => trim($_POST['description']),
                    'price' => floatval($_POST['price']),
                    'discount_percent' => floatval($_POST['discount_percent'] ?? 0),
                    'stock_quantity' => intval($_POST['stock_quantity']),
                    'category_id' => intval($_POST['category_id']),
                    'image' => $imageName,
                    'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                if ($productModel->create($data)) {
                    $_SESSION['success'] = 'Thêm sản phẩm thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi thêm sản phẩm'];
                }
                header('Location: ' . BASE_URL . 'admin/products.php');
                exit;
                
            case 'update':
                // Handle image upload
                $imageName = trim($_POST['current_image']);
                if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
                    $uploadDir = UPLOAD_PATH;
                    $fileName = $_FILES['image_file']['name'];
                    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'jfif'];
                    
                    if (in_array($fileExt, $allowedExt)) {
                        $newFileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $fileName);
                        $uploadPath = $uploadDir . $newFileName;
                        
                        if (move_uploaded_file($_FILES['image_file']['tmp_name'], $uploadPath)) {
                            // Delete old image if exists
                            if (!empty($imageName) && file_exists($uploadDir . $imageName)) {
                                @unlink($uploadDir . $imageName);
                            }
                            $imageName = $newFileName;
                        }
                    }
                }
                
                // If no file uploaded, check for URL
                if ($imageName === trim($_POST['current_image']) && !empty($_POST['image_url'])) {
                    $imageName = trim($_POST['image_url']);
                }
                
                $data = [
                    'product_name' => trim($_POST['product_name']),
                    'description' => trim($_POST['description']),
                    'price' => floatval($_POST['price']),
                    'discount_percent' => floatval($_POST['discount_percent'] ?? 0),
                    'stock_quantity' => intval($_POST['stock_quantity']),
                    'category_id' => intval($_POST['category_id']),
                    'image' => $imageName,
                    'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                if ($productModel->update($_POST['product_id'], $data)) {
                    $_SESSION['success'] = 'Cập nhật sản phẩm thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật sản phẩm'];
                }
                header('Location: ' . BASE_URL . 'admin/products.php');
                exit;
                
            case 'delete':
                if ($productModel->delete($_POST['product_id'])) {
                    $_SESSION['success'] = 'Xóa sản phẩm thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi xóa sản phẩm'];
                }
                header('Location: ' . BASE_URL . 'admin/products.php');
                exit;
        }
    }
}

// Get data based on action
$products = [];
$product = null;
$categories = $categoryModel->getActiveCategories();

switch ($action) {
    case 'list':
        $products = $productModel->getAllProducts();
        break;
    case 'view':
        if ($productId) {
            $product = $productModel->getProductDetails($productId);
        }
        break;
    case 'edit':
        if ($productId) {
            $product = $productModel->find($productId);
        }
        break;
}

$title = 'Quản lý sản phẩm - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table thead th {
            border: none;
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px;
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 8px 16px;
        }
        
        .btn-sm {
            padding: 6px 12px;
        }
        
        /* Forms */
        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 10px 15px;
        }
        
        .form-control:focus {
            border-color: #0ea5e9;
            box-shadow: 0 0 0 0.2rem rgba(14, 165, 233, 0.25);
        }
        
        /* Product Image */
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        /* Modal */
        .modal-content {
            border-radius: 15px;
            border: none;
        }
        
        .modal-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-store"></i> APPLE STORE</h4>
            <div class="admin-name"><?= e($_SESSION['full_name']) ?></div>
        </div>

        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-list"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i> Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php">
                        <i class="fas fa-home"></i> Về trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=logout">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1>Quản lý sản phẩm</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>admin/index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Sản phẩm</li>
                    </ol>
                </nav>
            </div>
            <div>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addProductModal">
                    <i class="fas fa-plus"></i> Thêm sản phẩm
                </button>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?= e($error) ?><br>
                <?php endforeach; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <!-- Products List -->
        <?php if ($action === 'list'): ?>
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-box"></i> Danh sách sản phẩm</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="productsTable">
                        <thead>
                            <tr>
                                <th>Hình ảnh</th>
                                <th>Tên sản phẩm</th>
                                <th>Danh mục</th>
                                <th>Giá</th>
                                <th>Giảm giá</th>
                                <th>Tồn kho</th>
                                <th>Nổi bật</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($products)): ?>
                                <tr>
                                    <td colspan="9" class="text-center" style="padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 3rem; color: #d1d5db; margin-bottom: 15px;"></i>
                                        <p style="color: #6b7280; font-size: 1.1rem;">Chưa có sản phẩm nào</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td>
                                            <img src="<?= getProductImage($product['image_url']) ?>" alt="<?= e($product['product_name']) ?>" class="product-image">
                                        </td>
                                        <td>
                                            <strong><?= e($product['product_name']) ?></strong>
                                            <br>
                                            <small class="text-muted"><?= e(substr($product['description'], 0, 50)) ?>...</small>
                                        </td>
                                        <td><?= e($product['category_name']) ?></td>
                                        <td><strong><?= formatCurrency($product['price']) ?></strong></td>
                                        <td>
                                            <?php if ($product['discount_percent'] > 0): ?>
                                                <span class="badge badge-warning"><?= $product['discount_percent'] ?>%</span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?= $product['stock_quantity'] > 0 ? 'badge-success' : 'badge-danger' ?>">
                                                <?= $product['stock_quantity'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($product['is_featured']): ?>
                                                <span class="badge badge-info">Nổi bật</span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?= $product['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>">
                                                <?= $product['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" onclick="viewProduct(<?= $product['product_id'] ?>)" title="Xem chi tiết">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-info" onclick="editProduct(<?= $product['product_id'] ?>)" title="Chỉnh sửa">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteProduct(<?= $product['product_id'] ?>, '<?= e($product['product_name']) ?>')" title="Xóa">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Thêm sản phẩm mới</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="create">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tên sản phẩm *</label>
                                    <input type="text" class="form-control" name="product_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Danh mục *</label>
                                    <select class="form-control" name="category_id" required>
                                        <option value="">Chọn danh mục</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?= $category['category_id'] ?>"><?= e($category['category_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Mô tả</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Giá *</label>
                                    <input type="number" class="form-control" name="price" step="0.01" min="0" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Giảm giá (%)</label>
                                    <input type="number" class="form-control" name="discount_percent" min="0" max="100" value="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Số lượng tồn kho *</label>
                                    <input type="number" class="form-control" name="stock_quantity" min="0" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Hình ảnh sản phẩm</label>
                            <div class="custom-file mb-2">
                                <input type="file" class="custom-file-input" id="imageFile" name="image_file" accept="image/*" onchange="previewImage(this, 'addPreview')">
                                <label class="custom-file-label" for="imageFile">Chọn file ảnh...</label>
                            </div>
                            <small class="form-text text-muted">Hoặc nhập URL hình ảnh bên dưới</small>
                            <input type="url" class="form-control mt-2" name="image_url" placeholder="https://example.com/image.jpg">
                            <div id="addPreview" class="mt-2"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Trạng thái</label>
                                    <select class="form-control" name="status">
                                        <option value="active">Hoạt động</option>
                                        <option value="inactive">Không hoạt động</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-check" style="margin-top: 35px;">
                                        <input class="form-check-input" type="checkbox" name="is_featured" id="is_featured">
                                        <label class="form-check-label" for="is_featured">
                                            Sản phẩm nổi bật
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Thêm sản phẩm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Product Modal -->
    <div class="modal fade" id="viewProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-eye"></i> Chi tiết sản phẩm</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" id="viewProductBody">
                    <!-- Content will be loaded dynamically -->
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Chỉnh sửa sản phẩm</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" enctype="multipart/form-data" id="editProductForm">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="product_id" id="edit_product_id">
                    <input type="hidden" name="current_image" id="edit_current_image">
                    <div class="modal-body" id="editProductBody">
                        <!-- Content will be loaded dynamically -->
                        <div class="text-center">
                            <div class="spinner-border" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteProductModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-trash"></i> Xác nhận xóa</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa sản phẩm <strong id="deleteProductName"></strong>?</p>
                    <p class="text-danger"><small>Hành động này không thể hoàn tác!</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="product_id" id="delete_product_id">
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize DataTable only if table has rows
            <?php if (!empty($products)): ?>
            $('#productsTable').DataTable({
                "language": {
                    "sProcessing": "Đang xử lý...",
                    "sLengthMenu": "Xem _MENU_ mục",
                    "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
                    "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
                    "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
                    "sInfoFiltered": "(được lọc từ _MAX_ mục)",
                    "sInfoPostFix": "",
                    "sSearch": "Tìm kiếm:",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "Đầu",
                        "sPrevious": "Trước",
                        "sNext": "Tiếp",
                        "sLast": "Cuối"
                    }
                },
                "order": [[ 1, "asc" ]],
                "pageLength": 25
            });
            <?php endif; ?>

            // Auto-hide alerts
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
            
            // Custom file input label update
            $('.custom-file-input').on('change', function() {
                var fileName = $(this).val().split('\\').pop();
                $(this).siblings('.custom-file-label').addClass("selected").html(fileName);
            });
        });

        // Preview image before upload
        function previewImage(input, previewId) {
            const preview = document.getElementById(previewId);
            preview.innerHTML = '';
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.innerHTML = '<img src="' + e.target.result + '" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // View product details
        function viewProduct(productId) {
            $('#viewProductModal').modal('show');
            
            // Fetch product details via AJAX
            $.ajax({
                url: '<?= BASE_URL ?>admin/products.php?action=view&id=' + productId,
                method: 'GET',
                success: function(response) {
                    // Extract modal body content
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const content = doc.getElementById('viewProductContent');
                    if (content) {
                        $('#viewProductBody').html(content.innerHTML);
                    }
                },
                error: function() {
                    $('#viewProductBody').html('<div class="alert alert-danger">Không thể tải thông tin sản phẩm</div>');
                }
            });
        }

        // Edit product
        function editProduct(productId) {
            $('#editProductModal').modal('show');
            
            // Fetch product details via AJAX
            $.ajax({
                url: '<?= BASE_URL ?>admin/products.php?action=edit&id=' + productId,
                method: 'GET',
                success: function(response) {
                    // Extract modal body content
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const content = doc.getElementById('editProductContent');
                    if (content) {
                        $('#editProductBody').html(content.innerHTML);
                        $('#edit_product_id').val(productId);
                    }
                },
                error: function() {
                    $('#editProductBody').html('<div class="alert alert-danger">Không thể tải thông tin sản phẩm</div>');
                }
            });
        }

        // Delete product
        function deleteProduct(productId, productName) {
            $('#delete_product_id').val(productId);
            $('#deleteProductName').text(productName);
            $('#deleteProductModal').modal('show');
        }
    </script>
</body>
</html>

<?php if ($action === 'view' && $product): ?>
    <!-- View Product Content (for AJAX) -->
    <div id="viewProductContent" style="display:none;">
        <div class="row">
            <div class="col-md-5">
                <img src="<?= getProductImage($product['image']) ?>" alt="<?= e($product['product_name']) ?>" class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-md-7">
                <h4 class="mb-3"><?= e($product['product_name']) ?></h4>
                
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Danh mục</th>
                        <td><?= e($product['category_name']) ?></td>
                    </tr>
                    <tr>
                        <th>Giá gốc</th>
                        <td><strong class="text-primary"><?= formatCurrency($product['price']) ?></strong></td>
                    </tr>
                    <?php if ($product['discount_percent'] > 0): ?>
                    <tr>
                        <th>Giảm giá</th>
                        <td><span class="badge badge-warning"><?= $product['discount_percent'] ?>%</span></td>
                    </tr>
                    <tr>
                        <th>Giá sau giảm</th>
                        <td><strong class="text-success"><?= formatCurrency($product['price'] * (1 - $product['discount_percent'] / 100)) ?></strong></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Số lượng tồn kho</th>
                        <td><span class="badge <?= $product['stock_quantity'] > 0 ? 'badge-success' : 'badge-danger' ?>"><?= $product['stock_quantity'] ?></span></td>
                    </tr>
                    <tr>
                        <th>Trạng thái</th>
                        <td><span class="badge <?= $product['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>"><?= $product['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?></span></td>
                    </tr>
                    <tr>
                        <th>Sản phẩm nổi bật</th>
                        <td><?= $product['is_featured'] ? '<i class="fas fa-check text-success"></i> Có' : '<i class="fas fa-times text-muted"></i> Không' ?></td>
                    </tr>
                    <tr>
                        <th>Lượt xem</th>
                        <td><?= number_format($product['views']) ?></td>
                    </tr>
                </table>
                
                <?php if (!empty($product['description'])): ?>
                <div class="mt-3">
                    <h6>Mô tả:</h6>
                    <p><?= nl2br(e($product['description'])) ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if ($action === 'edit' && $product): ?>
    <!-- Edit Product Content (for AJAX) -->
    <div id="editProductContent" style="display:none;">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tên sản phẩm *</label>
                    <input type="text" class="form-control" name="product_name" value="<?= e($product['product_name']) ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Danh mục *</label>
                    <select class="form-control" name="category_id" required>
                        <option value="">Chọn danh mục</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= $category['category_id'] ?>" <?= $product['category_id'] == $category['category_id'] ? 'selected' : '' ?>>
                                <?= e($category['category_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>Mô tả</label>
            <textarea class="form-control" name="description" rows="3"><?= e($product['description']) ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label>Giá *</label>
                    <input type="number" class="form-control" name="price" step="0.01" min="0" value="<?= $product['price'] ?>" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>Giảm giá (%)</label>
                    <input type="number" class="form-control" name="discount_percent" min="0" max="100" value="<?= $product['discount_percent'] ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>Số lượng tồn kho *</label>
                    <input type="number" class="form-control" name="stock_quantity" min="0" value="<?= $product['stock_quantity'] ?>" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>Hình ảnh hiện tại</label>
            <div class="mb-2">
                <img src="<?= getProductImage($product['image']) ?>" alt="Current Image" class="img-thumbnail" style="max-width: 200px;">
            </div>
            <div class="custom-file mb-2">
                <input type="file" class="custom-file-input" id="editImageFile" name="image_file" accept="image/*" onchange="previewImage(this, 'editPreview')">
                <label class="custom-file-label" for="editImageFile">Chọn ảnh mới...</label>
            </div>
            <small class="form-text text-muted">Hoặc nhập URL hình ảnh mới</small>
            <input type="url" class="form-control mt-2" name="image_url" placeholder="https://example.com/image.jpg">
            <div id="editPreview" class="mt-2"></div>
            <script>
                // Set current image value
                $('#edit_current_image').val('<?= e($product['image']) ?>');
            </script>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Trạng thái</label>
                    <select class="form-control" name="status">
                        <option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>Không hoạt động</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="form-check" style="margin-top: 35px;">
                        <input class="form-check-input" type="checkbox" name="is_featured" id="edit_is_featured" <?= $product['is_featured'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="edit_is_featured">
                            Sản phẩm nổi bật
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
