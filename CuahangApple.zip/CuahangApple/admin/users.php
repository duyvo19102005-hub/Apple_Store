<?php
/**
 * Admin Users Management
 */

// Start session
session_start();

// Load configuration first
require_once __DIR__ . '/../config/config.php';

// Load Database class before anything else that needs it
require_once __DIR__ . '/../config/Database.php';

// Load helpers
require_once __DIR__ . '/../helpers/Helper.php';
require_once __DIR__ . '/../helpers/Auth.php';

// Check if user is admin - use requireAdmin for better security
Auth::requireAdmin();

// Load core classes and models (Database must be loaded first)
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/../models/User.php';

$userModel = new User();

// Handle actions
$action = $_GET['action'] ?? 'list';
$userId = isset($_GET['id']) ? intval($_GET['id']) : null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $email = trim($_POST['email']);
                $fullName = trim($_POST['full_name']);
                
                // Validate email format
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $_SESSION['errors'] = ['Email không hợp lệ'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                // Check if email already exists
                if ($userModel->emailExists($email)) {
                    $_SESSION['errors'] = ['Email này đã được sử dụng'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                // Generate username from email if not provided
                $username = trim($_POST['username'] ?? '');
                if (empty($username)) {
                    // Use email prefix as username
                    $username = explode('@', $email)[0];
                    // Remove special characters and make lowercase
                    $username = preg_replace('/[^a-z0-9_]/', '', strtolower($username));
                    // Ensure username is not empty
                    if (empty($username)) {
                        // Fallback to full name
                        $username = preg_replace('/[^a-z0-9_]/', '', strtolower($fullName));
                        if (empty($username)) {
                            $username = 'user' . time();
                        }
                    }
                }
                
                // Ensure username is unique
                $originalUsername = $username;
                $counter = 1;
                while ($userModel->usernameExists($username)) {
                    $username = $originalUsername . $counter;
                    $counter++;
                }
                
                // Validate password
                if (empty($_POST['password']) || strlen($_POST['password']) < 6) {
                    $_SESSION['errors'] = ['Mật khẩu phải có ít nhất 6 ký tự'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                $data = [
                    'username' => $username,
                    'full_name' => $fullName,
                    'email' => $email,
                    'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                    'phone' => trim($_POST['phone']),
                    'address' => trim($_POST['address']),
                    'role' => $_POST['role'] ?? 'customer',
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                // Validate role - only allow valid roles
                if (!in_array($data['role'], ['customer', 'admin'])) {
                    $data['role'] = 'customer';
                }
                
                // Try to create with error handling
                try {
                if ($userModel->create($data)) {
                    $_SESSION['success'] = 'Thêm người dùng thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi thêm người dùng'];
                }
                } catch (PDOException $e) {
                    // Handle database errors
                    if ($e->getCode() == 23000) { // Integrity constraint violation
                        if (strpos($e->getMessage(), 'email') !== false) {
                            $_SESSION['errors'] = ['Email này đã được sử dụng'];
                        } elseif (strpos($e->getMessage(), 'username') !== false) {
                            $_SESSION['errors'] = ['Tên đăng nhập này đã được sử dụng'];
                        } else {
                            $_SESSION['errors'] = ['Dữ liệu bị trùng lặp. Vui lòng kiểm tra lại'];
                        }
                    } else {
                        $_SESSION['errors'] = ['Có lỗi xảy ra: ' . $e->getMessage()];
                    }
                }
                
                header('Location: ' . BASE_URL . 'admin/users.php');
                exit;
                
            case 'update':
                $userId = intval($_POST['user_id']);
                
                // Validate user exists
                $currentUser = $userModel->find($userId);
                if (!$currentUser) {
                    $_SESSION['errors'] = ['Người dùng không tồn tại'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                // Prevent self-demotion (admin cannot remove their own admin role)
                if ($userId == $_SESSION['user_id']) {
                    if ($currentUser['role'] === 'admin' && isset($_POST['role']) && $_POST['role'] !== 'admin') {
                        $_SESSION['errors'] = ['Bạn không thể tự hạ quyền của chính mình'];
                        header('Location: ' . BASE_URL . 'admin/users.php');
                        exit;
                    }
                }
                
                $email = trim($_POST['email']);
                
                // Validate email format
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $_SESSION['errors'] = ['Email không hợp lệ'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                // Check if email exists for another user (only if email is being changed)
                if ($email !== $currentUser['email']) {
                    if ($userModel->emailExistsForOtherUser($email, $userId)) {
                        $_SESSION['errors'] = ['Email này đã được sử dụng bởi người dùng khác'];
                        header('Location: ' . BASE_URL . 'admin/users.php');
                        exit;
                    }
                }
                
                $data = [
                    'full_name' => trim($_POST['full_name']),
                    'email' => $email,
                    'phone' => trim($_POST['phone']),
                    'address' => trim($_POST['address']),
                    'role' => $_POST['role'] ?? 'customer',
                    'status' => $_POST['status'] ?? 'active'
                ];
                
                // Validate role - only allow valid roles
                if (!in_array($data['role'], ['customer', 'admin'])) {
                    $data['role'] = 'customer';
                }
                
                // Only update password if provided
                if (!empty($_POST['password'])) {
                    if (strlen($_POST['password']) < 6) {
                        $_SESSION['errors'] = ['Mật khẩu phải có ít nhất 6 ký tự'];
                        header('Location: ' . BASE_URL . 'admin/users.php');
                        exit;
                    }
                    
                    // Validate password confirmation if provided
                    if (isset($_POST['password_confirm']) && !empty($_POST['password_confirm'])) {
                        if ($_POST['password'] !== $_POST['password_confirm']) {
                            $_SESSION['errors'] = ['Mật khẩu xác nhận không khớp'];
                            header('Location: ' . BASE_URL . 'admin/users.php');
                            exit;
                        }
                    }
                    
                    $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                }
                
                // Validate username if provided
                if (isset($_POST['username']) && !empty(trim($_POST['username']))) {
                    $username = trim($_POST['username']);
                    
                    // Validate username format (alphanumeric and underscore only)
                    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
                        $_SESSION['errors'] = ['Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới'];
                        header('Location: ' . BASE_URL . 'admin/users.php');
                        exit;
                    }
                    
                    // Check if username exists for another user
                    if ($username !== $currentUser['username']) {
                        if ($userModel->usernameExistsForOtherUser($username, $userId)) {
                            $_SESSION['errors'] = ['Tên đăng nhập này đã được sử dụng bởi người dùng khác'];
                            header('Location: ' . BASE_URL . 'admin/users.php');
                            exit;
                        }
                    }
                    
                    $data['username'] = $username;
                }
                
                // Try to update with error handling
                try {
                    if ($userModel->update($userId, $data)) {
                    $_SESSION['success'] = 'Cập nhật người dùng thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi cập nhật người dùng'];
                }
                } catch (PDOException $e) {
                    // Handle database errors
                    if ($e->getCode() == 23000) { // Integrity constraint violation
                        if (strpos($e->getMessage(), 'email') !== false) {
                            $_SESSION['errors'] = ['Email này đã được sử dụng bởi người dùng khác'];
                        } elseif (strpos($e->getMessage(), 'username') !== false) {
                            $_SESSION['errors'] = ['Tên đăng nhập này đã được sử dụng bởi người dùng khác'];
                        } else {
                            $_SESSION['errors'] = ['Dữ liệu bị trùng lặp. Vui lòng kiểm tra lại'];
                        }
                    } else {
                        $_SESSION['errors'] = ['Có lỗi xảy ra: ' . $e->getMessage()];
                    }
                }
                
                header('Location: ' . BASE_URL . 'admin/users.php');
                exit;
                
            case 'delete':
                $userId = intval($_POST['user_id']);
                
                // Prevent self-deletion
                if ($userId == $_SESSION['user_id']) {
                    $_SESSION['errors'] = ['Bạn không thể xóa chính tài khoản của mình'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                // Prevent deleting the last admin
                $allAdmins = $userModel->query(
                    "SELECT user_id FROM users WHERE role = 'admin' AND status = 'active'"
                );
                $userToDelete = $userModel->find($userId);
                
                if ($userToDelete && $userToDelete['role'] === 'admin' && count($allAdmins) <= 1) {
                    $_SESSION['errors'] = ['Không thể xóa admin cuối cùng trong hệ thống'];
                    header('Location: ' . BASE_URL . 'admin/users.php');
                    exit;
                }
                
                if ($userModel->delete($userId)) {
                    $_SESSION['success'] = 'Xóa người dùng thành công!';
                } else {
                    $_SESSION['errors'] = ['Có lỗi xảy ra khi xóa người dùng'];
                }
                header('Location: ' . BASE_URL . 'admin/users.php');
                exit;
        }
    }
}

// Get data based on action
$users = [];
$user = null;

switch ($action) {
    case 'view':
        if ($userId && $userId > 0) {
            $user = $userModel->getUserWithOrders($userId);
            if (!$user) {
                // User not found, redirect to list
                $_SESSION['errors'] = ['Không tìm thấy người dùng'];
                header('Location: ' . BASE_URL . 'admin/users.php');
                exit;
            }
        } else {
            // Invalid user ID, redirect to list
            $_SESSION['errors'] = ['ID người dùng không hợp lệ'];
            header('Location: ' . BASE_URL . 'admin/users.php');
            exit;
        }
        // Don't load all users for view action (only for AJAX response)
        if (!isset($_GET['ajax'])) {
        $users = $userModel->getAllUsers();
        }
        break;
    case 'edit':
        if ($userId && $userId > 0) {
            $user = $userModel->find($userId);
            if (!$user) {
                $_SESSION['errors'] = ['Không tìm thấy người dùng'];
                header('Location: ' . BASE_URL . 'admin/users.php');
                exit;
            }
        } else {
            $_SESSION['errors'] = ['ID người dùng không hợp lệ'];
            header('Location: ' . BASE_URL . 'admin/users.php');
            exit;
        }
        // Don't load all users for edit action (only for AJAX response)
        if (!isset($_GET['ajax'])) {
        $users = $userModel->getAllUsers();
        }
        break;
    case 'list':
    default:
        $users = $userModel->getAllUsers();
        break;
}

$title = 'Quản lý người dùng - ' . APP_NAME;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f8f9fa;
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            background: rgba(0,0,0,0.2);
        }
        
        .sidebar-header h4 {
            color: #fff;
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .sidebar-header .admin-name {
            color: #0ea5e9;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu .nav-item {
            margin: 5px 15px;
        }
        
        .sidebar-menu .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .sidebar-menu .nav-link i {
            width: 24px;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        
        .sidebar-menu .nav-link:hover {
            background: rgba(14, 165, 233, 0.1);
            color: #0ea5e9;
            transform: translateX(5px);
        }
        
        .sidebar-menu .nav-link.active {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        /* Header */
        .content-header {
            background: #fff;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .content-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
        }
        
        /* Cards */
        .custom-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border: none;
        }
        
        .custom-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .custom-card .card-header h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .custom-card .card-body {
            padding: 25px;
        }
        
        /* Table */
        .table {
            margin: 0;
        }
        
        .table thead th {
            border: none;
            background: #f8f9fa;
            color: #6b7280;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px;
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 8px 16px;
        }
        
        .btn-sm {
            padding: 6px 12px;
        }
        
        /* Forms */
        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 10px 15px;
        }
        
        .form-control:focus {
            border-color: #0ea5e9;
            box-shadow: 0 0 0 0.2rem rgba(14, 165, 233, 0.25);
        }
        
        /* Modal */
        .modal-content {
            border-radius: 15px;
            border: none;
        }
        
        .modal-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 25px;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h4><i class="fas fa-store"></i> APPLE STORE</h4>
            <div class="admin-name"><?= e($_SESSION['full_name']) ?></div>
        </div>

        <nav class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/index.php">
                        <i class="fas fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/products.php">
                        <i class="fas fa-box"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/categories.php">
                        <i class="fas fa-list"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>admin/orders.php">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= BASE_URL ?>admin/users.php">
                        <i class="fas fa-users"></i> Người dùng
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php">
                        <i class="fas fa-home"></i> Về trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>index.php?navigate=logout">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                </li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="content-header">
            <div>
                <h1>Quản lý người dùng</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>admin/index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Người dùng</li>
                    </ol>
                </nav>
            </div>
            <div>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">
                    <i class="fas fa-plus"></i> Thêm người dùng
                </button>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?= e($error) ?><br>
                <?php endforeach; ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php unset($_SESSION['errors']); ?>
        <?php endif; ?>

        <!-- Users List -->
        <div class="custom-card">
            <div class="card-header">
                <h5><i class="fas fa-users"></i> Danh sách người dùng</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table" id="usersTable">
                        <thead>
                            <tr>
                                <th>Họ tên</th>
                                <th>Email</th>
                                <th>Số điện thoại</th>
                                <th>Vai trò</th>
                                <th>Trạng thái</th>
                                <th>Ngày tạo</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="7" class="text-center" style="padding: 40px;">
                                        <i class="fas fa-inbox" style="font-size: 3rem; color: #d1d5db; margin-bottom: 15px;"></i>
                                        <p style="color: #6b7280; font-size: 1.1rem;">Chưa có người dùng nào</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($user['full_name']) ?></strong>
                                        </td>
                                        <td><?= e($user['email']) ?></td>
                                        <td><?= e($user['phone'] ?? '') ?></td>
                                        <td>
                                            <span class="badge <?= $user['role'] === 'admin' ? 'badge-danger' : 'badge-info' ?>">
                                                <?= $user['role'] === 'admin' ? 'Quản trị viên' : 'Khách hàng' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge <?= $user['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>">
                                                <?= $user['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?>
                                            </span>
                                        </td>
                                        <td><?= formatDate($user['created_at']) ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" onclick="viewUser(<?= $user['user_id'] ?>)" data-toggle="tooltip" title="Xem chi tiết">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-info" onclick="editUser(<?= $user['user_id'] ?>)" data-toggle="tooltip" title="Sửa">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                                <button type="button" class="btn btn-sm btn-danger" onclick="deleteUser(<?= $user['user_id'] ?>, '<?= e($user['full_name']) ?>')" data-toggle="tooltip" title="Xóa">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- View User Modal -->
    <div class="modal fade" id="viewUserModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-eye"></i> Chi tiết người dùng</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" id="viewUserBody">
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Thêm người dùng mới</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="create">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Họ tên *</label>
                                    <input type="text" class="form-control" name="full_name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email *</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mật khẩu *</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Số điện thoại</label>
                                    <input type="text" class="form-control" name="phone">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Địa chỉ</label>
                            <textarea class="form-control" name="address" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Vai trò</label>
                                    <select class="form-control" name="role">
                                        <option value="customer">Khách hàng</option>
                                        <option value="admin">Quản trị viên</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Trạng thái</label>
                                    <select class="form-control" name="status">
                                        <option value="active">Hoạt động</option>
                                        <option value="inactive">Không hoạt động</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Thêm người dùng</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Chỉnh sửa người dùng</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" id="editUserForm">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    <div class="modal-body" id="editUserBody">
                        <div class="text-center py-5">
                            <div class="spinner-border text-info" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            <i class="fas fa-times"></i> Hủy
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Cập nhật
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-trash"></i> Xác nhận xóa</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa người dùng <strong id="deleteUserName"></strong>?</p>
                    <p class="text-danger"><small>Hành động này không thể hoàn tác!</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="user_id" id="delete_user_id">
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            // Initialize DataTable only if table has rows
            <?php if (!empty($users)): ?>
            $('#usersTable').DataTable({
                "language": {
                    "sProcessing": "Đang xử lý...",
                    "sLengthMenu": "Xem _MENU_ mục",
                    "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
                    "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
                    "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
                    "sInfoFiltered": "(được lọc từ _MAX_ mục)",
                    "sInfoPostFix": "",
                    "sSearch": "Tìm kiếm:",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "Đầu",
                        "sPrevious": "Trước",
                        "sNext": "Tiếp",
                        "sLast": "Cuối"
                    }
                },
                "order": [[ 5, "desc" ]],
                "pageLength": 25
            });
            <?php endif; ?>

            // Auto-hide alerts
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
        });

        function viewUser(userId) {
            if (!userId || userId <= 0) {
                alert('ID người dùng không hợp lệ');
                return;
            }
            
            $('#viewUserModal').modal('show');
            $('#viewUserBody').html('<div class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>');
            
            $.ajax({
                url: '<?= BASE_URL ?>admin/users.php?action=view&id=' + userId + '&ajax=1',
                method: 'GET',
                dataType: 'html',
                success: function(response) {
                    try {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const content = doc.getElementById('viewUserContent');
                    
                    if (content) {
                        $('#viewUserBody').html(content.innerHTML);
                        } else {
                            $('#viewUserBody').html('<div class="alert alert-danger">Không tìm thấy thông tin người dùng</div>');
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        $('#viewUserBody').html('<div class="alert alert-danger">Lỗi khi xử lý dữ liệu</div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    $('#viewUserBody').html('<div class="alert alert-danger">Không thể tải thông tin người dùng. Vui lòng thử lại.</div>');
                }
            });
        }

        function editUser(userId) {
            if (!userId || userId <= 0) {
                alert('ID người dùng không hợp lệ');
                return;
            }
            
            $('#edit_user_id').val(userId);
            $('#editUserModal').modal('show');
            
            // Reset form
            $('#editUserBody').html('<div class="text-center py-5"><div class="spinner-border text-info" role="status"><span class="sr-only">Loading...</span></div></div>');
            
            $.ajax({
                url: '<?= BASE_URL ?>admin/users.php?action=edit&id=' + userId + '&ajax=1',
                method: 'GET',
                dataType: 'html',
                success: function(response) {
                    try {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const content = doc.getElementById('editUserContent');
                    
                    if (content) {
                        $('#editUserBody').html(content.innerHTML);
                            initPasswordValidation();
                        } else {
                            $('#editUserBody').html('<div class="alert alert-danger">Không tìm thấy thông tin người dùng</div>');
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        $('#editUserBody').html('<div class="alert alert-danger">Lỗi khi xử lý dữ liệu</div>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    $('#editUserBody').html('<div class="alert alert-danger">Không thể tải thông tin người dùng. Vui lòng thử lại.</div>');
                }
            });
        }
        
        // Password validation and strength indicator
        function initPasswordValidation() {
            const passwordInput = $('#edit_password');
            const passwordConfirmInput = $('#edit_password_confirm');
            const strengthDiv = $('.password-strength');
            const strengthBar = $('.password-strength .progress-bar');
            const strengthText = $('.password-strength-text');
            
            passwordInput.on('input', function() {
                const password = $(this).val();
                
                if (password.length === 0) {
                    strengthDiv.hide();
                    return;
                }
                
                strengthDiv.show();
                
                let strength = 0;
                let feedback = [];
                
                // Length check
                if (password.length >= 6) strength += 1;
                else feedback.push('Tối thiểu 6 ký tự');
                
                if (password.length >= 8) strength += 1;
                
                // Character variety
                if (/[a-z]/.test(password)) strength += 1;
                if (/[A-Z]/.test(password)) strength += 1;
                if (/[0-9]/.test(password)) strength += 1;
                if (/[^a-zA-Z0-9]/.test(password)) strength += 1;
                
                // Calculate percentage
                const percentage = (strength / 5) * 100;
                strengthBar.css('width', percentage + '%');
                
                // Set color and text
                if (strength <= 2) {
                    strengthBar.removeClass('bg-success bg-warning').addClass('bg-danger');
                    strengthText.text('Mật khẩu yếu').removeClass('text-success text-warning').addClass('text-danger');
                } else if (strength <= 3) {
                    strengthBar.removeClass('bg-danger bg-success').addClass('bg-warning');
                    strengthText.text('Mật khẩu trung bình').removeClass('text-danger text-success').addClass('text-warning');
                } else {
                    strengthBar.removeClass('bg-danger bg-warning').addClass('bg-success');
                    strengthText.text('Mật khẩu mạnh').removeClass('text-danger text-warning').addClass('text-success');
                }
            });
            
            // Password confirmation check
            passwordConfirmInput.on('input', function() {
                const password = passwordInput.val();
                const confirm = $(this).val();
                
                if (confirm.length === 0) {
                    $(this).removeClass('is-invalid is-valid');
                    return;
                }
                
                if (password === confirm) {
                    $(this).removeClass('is-invalid').addClass('is-valid');
                } else {
                    $(this).removeClass('is-valid').addClass('is-invalid');
                }
            });
            
            // Form validation before submit
            $('#editUserForm').on('submit', function(e) {
                const password = passwordInput.val();
                const passwordConfirm = passwordConfirmInput.val();
                
                if (password.length > 0) {
                    if (password.length < 6) {
                        e.preventDefault();
                        alert('Mật khẩu phải có ít nhất 6 ký tự');
                        return false;
                    }
                    
                    if (passwordConfirm.length > 0 && password !== passwordConfirm) {
                        e.preventDefault();
                        alert('Mật khẩu xác nhận không khớp');
                        return false;
                    }
                }
            });
        }

        function deleteUser(userId, userName) {
            $('#delete_user_id').val(userId);
            $('#deleteUserName').text(userName);
            $('#deleteUserModal').modal('show');
        }
    </script>
</body>
</html>

<?php if ($action === 'view' && $user && isset($_GET['ajax'])): ?>
    <!-- View User Content (for AJAX) -->
    <div id="viewUserContent" style="display:none;">
        <div class="row">
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-user"></i> Thông tin cá nhân</h5>
                <table class="table table-bordered">
                    <tr>
                        <th width="40%">Tên đăng nhập</th>
                        <td><strong><?= e($user['username']) ?></strong></td>
                    </tr>
                    <tr>
                        <th>Họ tên</th>
                        <td><strong><?= e($user['full_name']) ?></strong></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>
                            <i class="fas fa-envelope text-muted"></i> <?= e($user['email']) ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Số điện thoại</th>
                        <td>
                            <?php if (!empty($user['phone'])): ?>
                                <i class="fas fa-phone text-muted"></i> <?= e($user['phone']) ?>
                            <?php else: ?>
                                <span class="text-muted">Chưa cập nhật</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Địa chỉ</th>
                        <td>
                            <?php if (!empty($user['address'])): ?>
                                <i class="fas fa-map-marker-alt text-muted"></i> <?= e($user['address']) ?>
                            <?php else: ?>
                                <span class="text-muted">Chưa cập nhật</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Vai trò</th>
                        <td>
                            <span class="badge <?= $user['role'] === 'admin' ? 'badge-danger' : 'badge-info' ?>" style="font-size: 14px;">
                                <i class="fas fa-<?= $user['role'] === 'admin' ? 'user-shield' : 'user' ?>"></i>
                                <?= $user['role'] === 'admin' ? 'Quản trị viên' : 'Khách hàng' ?>
                            </span>
                            <?php if ($user['user_id'] == 1): ?>
                                <span class="badge badge-warning ml-2" style="font-size: 12px;">
                                    <i class="fas fa-star"></i> Admin mặc định
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Trạng thái</th>
                        <td>
                            <span class="badge <?= $user['status'] === 'active' ? 'badge-success' : 'badge-secondary' ?>" style="font-size: 14px;">
                                <i class="fas fa-<?= $user['status'] === 'active' ? 'check-circle' : 'times-circle' ?>"></i>
                                <?= $user['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động' ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>Ngày đăng ký</th>
                        <td>
                            <i class="fas fa-calendar text-muted"></i> <?= date('d/m/Y H:i', strtotime($user['created_at'])) ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Cập nhật lần cuối</th>
                        <td>
                            <i class="fas fa-clock text-muted"></i> <?= date('d/m/Y H:i', strtotime($user['updated_at'] ?? $user['created_at'])) ?>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-shopping-bag"></i> Thống kê đơn hàng</h5>
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="card text-center" style="border-left: 4px solid #3b82f6;">
                            <div class="card-body">
                                <h3 class="mb-0 text-primary"><?= isset($user['order_count']) ? $user['order_count'] : 0 ?></h3>
                                <small class="text-muted">Tổng đơn hàng</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card text-center" style="border-left: 4px solid #10b981;">
                            <div class="card-body">
                                <h3 class="mb-0 text-success"><?= formatCurrency(isset($user['total_spent']) ? $user['total_spent'] : 0) ?></h3>
                                <small class="text-muted">Tổng chi tiêu</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($user['recent_orders']) && !empty($user['recent_orders'])): ?>
                <h6 class="mt-3 mb-2">Đơn hàng gần đây</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Mã đơn</th>
                                <th>Trạng thái</th>
                                <th>Giá trị</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($user['recent_orders'] as $order): ?>
                            <tr>
                                <td><small><?= e($order['order_number']) ?></small></td>
                                <td>
                                    <?php
                                    $statusClass = 'badge-secondary';
                                    $statusText = 'Không xác định';
                                    switch($order['order_status']) {
                                        case 'pending': $statusClass = 'badge-warning'; $statusText = 'Chờ'; break;
                                        case 'confirmed': $statusClass = 'badge-info'; $statusText = 'Xác nhận'; break;
                                        case 'shipping': $statusClass = 'badge-primary'; $statusText = 'Giao'; break;
                                        case 'delivered': $statusClass = 'badge-success'; $statusText = 'Hoàn thành'; break;
                                        case 'cancelled': $statusClass = 'badge-danger'; $statusText = 'Hủy'; break;
                                    }
                                    ?>
                                    <span class="badge <?= $statusClass ?>"><?= $statusText ?></span>
                                </td>
                                <td><small><strong><?= formatCurrency($order['final_amount']) ?></strong></small></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-info mt-3">
                    <small><i class="fas fa-info-circle"></i> Người dùng chưa có đơn hàng nào</small>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if ($action === 'edit' && $user && isset($_GET['ajax'])): ?>
    <!-- Edit User Content (for AJAX) -->
    <div id="editUserContent" style="display:none;">
        <?php 
        $isCurrentUser = ($user['user_id'] == $_SESSION['user_id']);
        $isDefaultAdmin = ($user['user_id'] == 1);
        $userStats = $userModel->getUserWithOrders($user['user_id']);
        ?>
        
        <?php if ($isDefaultAdmin): ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i> <strong>Lưu ý:</strong> Đây là tài khoản admin mặc định của hệ thống.
        </div>
        <?php endif; ?>
        
        <?php if ($isCurrentUser): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Bạn đang chỉnh sửa thông tin của chính mình.
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tên đăng nhập *</label>
                    <input type="text" class="form-control" name="username" value="<?= e($user['username']) ?>" required>
                    <small class="form-text text-muted">Tên đăng nhập phải là duy nhất</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Họ tên *</label>
                    <input type="text" class="form-control" name="full_name" value="<?= e($user['full_name']) ?>" required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" class="form-control" name="email" value="<?= e($user['email']) ?>" required>
                    <small class="form-text text-muted">Email phải là duy nhất</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Số điện thoại</label>
                    <input type="tel" class="form-control" name="phone" value="<?= e($user['phone'] ?? '') ?>" placeholder="VD: 0123456789">
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>Địa chỉ</label>
            <textarea class="form-control" name="address" rows="2" placeholder="Nhập địa chỉ đầy đủ"><?= e($user['address'] ?? '') ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Mật khẩu mới</label>
                    <input type="password" class="form-control" name="password" id="edit_password" placeholder="Để trống nếu không đổi">
                    <small class="form-text text-muted">
                        <i class="fas fa-info-circle"></i> Chỉ nhập nếu muốn thay đổi mật khẩu (tối thiểu 6 ký tự)
                    </small>
                    <div class="password-strength mt-2" style="display: none;">
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                </div>
                        <small class="text-muted password-strength-text"></small>
            </div>
        </div>
            </div>
            <div class="col-md-6">
        <div class="form-group">
                    <label>Xác nhận mật khẩu</label>
                    <input type="password" class="form-control" name="password_confirm" id="edit_password_confirm" placeholder="Nhập lại mật khẩu mới">
                    <small class="form-text text-muted">Chỉ cần nhập nếu đổi mật khẩu</small>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Vai trò *</label>
                    <select class="form-control" name="role" <?= ($isCurrentUser && $user['role'] === 'admin') ? 'disabled' : '' ?>>
                        <option value="customer" <?= $user['role'] === 'customer' ? 'selected' : '' ?>>Khách hàng</option>
                        <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Quản trị viên</option>
                    </select>
                    <?php if ($isCurrentUser && $user['role'] === 'admin'): ?>
                        <input type="hidden" name="role" value="admin">
                        <small class="form-text text-danger">
                            <i class="fas fa-lock"></i> Bạn không thể tự hạ quyền của chính mình
                        </small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Trạng thái *</label>
                    <select class="form-control" name="status" <?= ($isCurrentUser) ? 'disabled' : '' ?>>
                        <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>Không hoạt động</option>
                    </select>
                    <?php if ($isCurrentUser): ?>
                        <input type="hidden" name="status" value="active">
                        <small class="form-text text-danger">
                            <i class="fas fa-lock"></i> Bạn không thể tự khóa tài khoản của mình
                        </small>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card bg-light mt-3">
            <div class="card-body">
                <h6 class="card-title"><i class="fas fa-chart-line"></i> Thống kê người dùng</h6>
                <div class="row">
                    <div class="col-6">
                        <p class="mb-0"><strong>Tổng đơn hàng:</strong></p>
                        <h4 class="text-primary"><?= $userStats['order_count'] ?? 0 ?></h4>
                    </div>
                    <div class="col-6">
                        <p class="mb-0"><strong>Tổng chi tiêu:</strong></p>
                        <h4 class="text-success"><?= formatCurrency($userStats['total_spent'] ?? 0) ?></h4>
                    </div>
                </div>
                <hr>
                <p class="mb-0 text-muted">
                    <small>
                        <i class="fas fa-calendar"></i> Ngày đăng ký: <?= date('d/m/Y H:i', strtotime($user['created_at'])) ?><br>
                        <i class="fas fa-clock"></i> Cập nhật lần cuối: <?= date('d/m/Y H:i', strtotime($user['updated_at'] ?? $user['created_at'])) ?>
                    </small>
                </p>
            </div>
        </div>
    </div>
<?php endif; ?>

