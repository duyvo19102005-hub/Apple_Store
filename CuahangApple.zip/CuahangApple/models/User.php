<?php
require_once __DIR__ . '/../core/Model.php';

/**
 * User Model
 */
class User extends Model {
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    
    /**
     * Register new user
     */
    public function register($data) {
        // Hash password
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        
        // Force customer role for security - prevent privilege escalation
        $data['role'] = 'customer';
        
        // Set default status if not provided
        if (!isset($data['status'])) {
            $data['status'] = 'active';
        }
        
        return $this->create($data);
    }
    
    /**
     * Login user
     */
    public function login($email, $password) {
        $user = $this->findWhere('email', $email);
        
        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                return ['success' => false, 'message' => 'Tài khoản đã bị khóa'];
            }
            
            // Set session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['full_name'] = $user['full_name'];
            
            return ['success' => true, 'user' => $user];
        }
        
        return ['success' => false, 'message' => 'Email hoặc mật khẩu không đúng'];
    }
    
    /**
     * Logout user
     */
    public function logout() {
        session_unset();
        session_destroy();
        return true;
    }
    
    /**
     * Check if email exists
     */
    public function emailExists($email) {
        $user = $this->findWhere('email', $email);
        return $user !== false;
    }
    
    /**
     * Check if email exists for another user (exclude current user)
     */
    public function emailExistsForOtherUser($email, $excludeUserId) {
        $stmt = $this->db->prepare("SELECT user_id FROM {$this->table} WHERE email = ? AND user_id != ?");
        $stmt->execute([$email, $excludeUserId]);
        $user = $stmt->fetch();
        return $user !== false;
    }
    
    /**
     * Check if username exists
     */
    public function usernameExists($username) {
        $user = $this->findWhere('username', $username);
        return $user !== false;
    }
    
    /**
     * Check if username exists for another user (exclude current user)
     */
    public function usernameExistsForOtherUser($username, $excludeUserId) {
        $stmt = $this->db->prepare("SELECT user_id FROM {$this->table} WHERE username = ? AND user_id != ?");
        $stmt->execute([$username, $excludeUserId]);
        $user = $stmt->fetch();
        return $user !== false;
    }
    
    /**
     * Get user by ID
     */
    public function getUserById($id) {
        return $this->find($id);
    }
    
    /**
     * Update user profile
     */
    public function updateProfile($userId, $data) {
        // Remove password if empty
        if (empty($data['password'])) {
            unset($data['password']);
        } else {
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        return $this->update($userId, $data);
    }
    
    /**
     * Change password
     */
    public function changePassword($userId, $oldPassword, $newPassword) {
        $user = $this->find($userId);
        
        if (password_verify($oldPassword, $user['password'])) {
            return $this->update($userId, [
                'password' => password_hash($newPassword, PASSWORD_DEFAULT)
            ]);
        }
        
        return false;
    }
    
    /**
     * Get all users (admin)
     */
    public function getAllUsers($limit = 50, $offset = 0) {
        return $this->query(
            "SELECT user_id, username, email, full_name, phone, role, status, created_at 
             FROM {$this->table} 
             ORDER BY created_at DESC 
             LIMIT ? OFFSET ?",
            [$limit, $offset]
        );
    }
    
    /**
     * Update user status
     */
    public function updateStatus($userId, $status) {
        return $this->update($userId, ['status' => $status]);
    }
    
    /**
     * Get user with orders (for admin view)
     */
    public function getUserWithOrders($userId) {
        $user = $this->find($userId);
        if (!$user) {
            return null;
        }
        
        // Get order count and total spent
        $orderStats = $this->queryOne(
            "SELECT COUNT(*) as order_count, 
                    COALESCE(SUM(final_amount), 0) as total_spent
             FROM orders 
             WHERE user_id = ?",
            [$userId]
        );
        
        $user['order_count'] = $orderStats['order_count'] ?? 0;
        $user['total_spent'] = $orderStats['total_spent'] ?? 0;
        
        // Get recent orders
        $user['recent_orders'] = $this->query(
            "SELECT order_id, order_number, order_status, final_amount, created_at 
             FROM orders 
             WHERE user_id = ?
             ORDER BY created_at DESC 
             LIMIT 5",
            [$userId]
        );
        
        return $user;
    }
}


