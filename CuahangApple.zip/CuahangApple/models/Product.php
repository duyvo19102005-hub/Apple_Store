<?php
require_once __DIR__ . '/../core/Model.php';

/**
 * Product Model
 */
class Product extends Model {
    protected $table = 'products';
    protected $primaryKey = 'product_id';
    
    /**
     * Get all products with category info
     */
    public function getAllProducts($limit = null, $offset = 0) {
        $sql = "SELECT p.*, c.category_name, p.image as image_url 
                FROM {$this->table} p 
                LEFT JOIN categories c ON p.category_id = c.category_id 
                WHERE p.status = 'active'
                ORDER BY p.created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            return $this->query($sql, [$limit, $offset]);
        }
        
        return $this->query($sql);
    }
    
    /**
     * Get products by category
     */
    public function getByCategory($categoryId, $limit = null, $offset = 0) {
        $sql = "SELECT p.*, c.category_name, p.image as image_url 
                FROM {$this->table} p 
                LEFT JOIN categories c ON p.category_id = c.category_id 
                WHERE p.category_id = ? AND p.status = 'active'
                ORDER BY p.created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            return $this->query($sql, [$categoryId, $limit, $offset]);
        }
        
        return $this->query($sql, [$categoryId]);
    }
    
    /**
     * Get featured products
     */
    public function getFeaturedProducts($limit = 6) {
        return $this->query(
            "SELECT p.*, c.category_name, p.image as image_url 
             FROM {$this->table} p 
             LEFT JOIN categories c ON p.category_id = c.category_id 
             WHERE p.is_featured = 1 AND p.status = 'active'
             ORDER BY p.views DESC, p.created_at DESC 
             LIMIT ?",
            [$limit]
        );
    }
    
    /**
     * Search products
     */
    public function search($keyword, $categoryId = null, $limit = null, $offset = 0) {
        $sql = "SELECT p.*, c.category_name, p.image as image_url 
                FROM {$this->table} p 
                LEFT JOIN categories c ON p.category_id = c.category_id 
                WHERE p.status = 'active' 
                AND (p.product_name LIKE ? OR p.description LIKE ?)";
        
        $params = ["%{$keyword}%", "%{$keyword}%"];
        
        if ($categoryId && $categoryId != 0) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
        }
        
        $sql .= " ORDER BY p.product_name ASC";
        
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
        }
        
        return $this->query($sql, $params);
    }
    
    /**
     * Advanced search with filters
     */
    public function searchWithFilters($filters, $limit = null, $offset = 0) {
        $sql = "SELECT p.*, c.category_name, p.image as image_url,
                       CASE 
                           WHEN p.discount_percent > 0 THEN 
                               ROUND(p.price * (1 - p.discount_percent / 100))
                           ELSE p.price 
                       END as final_price
                FROM {$this->table} p 
                LEFT JOIN categories c ON p.category_id = c.category_id 
                WHERE p.status = 'active'";
        
        $params = [];
        
        // Search keyword
        if (!empty($filters['keyword'])) {
            $sql .= " AND (p.product_name LIKE ? OR p.description LIKE ?)";
            $params[] = "%{$filters['keyword']}%";
            $params[] = "%{$filters['keyword']}%";
        }
        
        // Category filter
        if (!empty($filters['category_id']) && $filters['category_id'] != 0) {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category_id'];
        }
        
        // Price range filter
        if (!empty($filters['price_range'])) {
            $priceRange = explode('-', $filters['price_range']);
            if (count($priceRange) == 2) {
                $minPrice = (int)$priceRange[0];
                $maxPrice = (int)$priceRange[1];
                
                $sql .= " AND (CASE 
                              WHEN p.discount_percent > 0 THEN 
                                  ROUND(p.price * (1 - p.discount_percent / 100))
                              ELSE p.price 
                              END) BETWEEN ? AND ?";
                $params[] = $minPrice;
                $params[] = $maxPrice;
            }
        }
        
        // Status filter
        if (!empty($filters['status'])) {
            switch ($filters['status']) {
                case 'in_stock':
                    $sql .= " AND p.stock_quantity > 0";
                    break;
                case 'featured':
                    $sql .= " AND p.is_featured = 1";
                    break;
            }
        }
        
        // Sorting
        $orderBy = $this->getSortClause($filters['sort'] ?? 'name_asc');
        $sql .= " ORDER BY " . $orderBy;
        
        // Pagination
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
        }
        
        return $this->query($sql, $params);
    }
    
    /**
     * Count products with filters
     */
    public function countWithFilters($filters) {
        $sql = "SELECT COUNT(*) as total 
                FROM {$this->table} p 
                WHERE p.status = 'active'";
        
        $params = [];
        
        // Search keyword
        if (!empty($filters['keyword'])) {
            $sql .= " AND (p.product_name LIKE ? OR p.description LIKE ?)";
            $params[] = "%{$filters['keyword']}%";
            $params[] = "%{$filters['keyword']}%";
        }
        
        // Category filter
        if (!empty($filters['category_id']) && $filters['category_id'] != 0) {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category_id'];
        }
        
        // Price range filter
        if (!empty($filters['price_range'])) {
            $priceRange = explode('-', $filters['price_range']);
            if (count($priceRange) == 2) {
                $minPrice = (int)$priceRange[0];
                $maxPrice = (int)$priceRange[1];
                
                $sql .= " AND (CASE 
                              WHEN p.discount_percent > 0 THEN 
                                  ROUND(p.price * (1 - p.discount_percent / 100))
                              ELSE p.price 
                              END) BETWEEN ? AND ?";
                $params[] = $minPrice;
                $params[] = $maxPrice;
            }
        }
        
        // Status filter
        if (!empty($filters['status'])) {
            switch ($filters['status']) {
                case 'in_stock':
                    $sql .= " AND p.stock_quantity > 0";
                    break;
                case 'featured':
                    $sql .= " AND p.is_featured = 1";
                    break;
            }
        }
        
        $result = $this->queryOne($sql, $params);
        return (int)$result['total'];
    }
    
    /**
     * Get sort clause for ORDER BY
     */
    private function getSortClause($sort) {
        switch ($sort) {
            case 'name_asc':
                return 'p.product_name ASC';
            case 'name_desc':
                return 'p.product_name DESC';
            case 'price_asc':
                return 'final_price ASC';
            case 'price_desc':
                return 'final_price DESC';
            case 'newest':
                return 'p.created_at DESC';
            case 'popular':
                return 'p.views DESC, p.created_at DESC';
            default:
                return 'p.product_name ASC';
        }
    }
    
    /**
     * Get product details
     */
    public function getProductDetails($productId) {
        $product = $this->queryOne(
            "SELECT p.*, c.category_name, p.image as image_url 
             FROM {$this->table} p 
             LEFT JOIN categories c ON p.category_id = c.category_id 
             WHERE p.product_id = ?",
            [$productId]
        );
        
        if ($product) {
            // Increment views
            $this->query(
                "UPDATE {$this->table} SET views = views + 1 WHERE product_id = ?",
                [$productId]
            );
        }
        
        return $product;
    }
    
    /**
     * Get related products
     */
    public function getRelatedProducts($productId, $categoryId, $limit = 4) {
        return $this->query(
            "SELECT * FROM {$this->table} 
             WHERE category_id = ? AND product_id != ? AND status = 'active'
             ORDER BY RAND() 
             LIMIT ?",
            [$categoryId, $productId, $limit]
        );
    }
    
    /**
     * Calculate discounted price
     */
    public function getDiscountedPrice($product) {
        if ($product['discount_percent'] > 0) {
            return $product['price'] * (1 - $product['discount_percent'] / 100);
        }
        return $product['price'];
    }
    
    /**
     * Get product count by category
     */
    public function countByCategory($categoryId = null) {
        if ($categoryId) {
            $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                    WHERE category_id = ? AND status = 'active'";
            $result = $this->queryOne($sql, [$categoryId]);
        } else {
            $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE status = 'active'";
            $result = $this->queryOne($sql);
        }
        
        return $result['count'];
    }
    
    /**
     * Update stock quantity
     */
    public function updateStock($productId, $quantity) {
        return $this->query(
            "UPDATE {$this->table} SET stock_quantity = stock_quantity - ? 
             WHERE product_id = ?",
            [$quantity, $productId]
        );
    }
    
    /**
     * Check stock availability
     */
    public function checkStock($productId, $quantity) {
        $product = $this->find($productId);
        return $product && $product['stock_quantity'] >= $quantity;
    }
}


