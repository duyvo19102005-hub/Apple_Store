<?php
require_once __DIR__ . '/../core/Model.php';

/**
 * Category Model
 */
class Category extends Model {
    protected $table = 'categories';
    protected $primaryKey = 'category_id';
    
    /**
     * Get all active categories
     */
    public function getActiveCategories() {
        return $this->query(
            "SELECT * FROM {$this->table} 
             WHERE status = 'active' 
             ORDER BY display_order ASC, category_name ASC"
        );
    }
    
    /**
     * Get categories with product count
     */
    public function getCategoriesWithCount() {
        return $this->query(
            "SELECT c.*, COUNT(p.product_id) as product_count 
             FROM {$this->table} c 
             LEFT JOIN products p ON c.category_id = p.category_id AND p.status = 'active'
             WHERE c.status = 'active'
             GROUP BY c.category_id 
             ORDER BY c.display_order ASC, c.category_name ASC"
        );
    }
    
    /**
     * Get category by ID
     */
    public function getCategoryById($id) {
        return $this->find($id);
    }
    
    /**
     * Get popular categories
     */
    public function getPopularCategories($limit = 4) {
        return $this->query(
            "SELECT c.*, COUNT(p.product_id) as product_count 
             FROM {$this->table} c 
             LEFT JOIN products p ON c.category_id = p.category_id AND p.status = 'active'
             WHERE c.status = 'active'
             GROUP BY c.category_id 
             HAVING product_count > 0
             ORDER BY product_count DESC, c.category_name ASC
             LIMIT ?",
            [$limit]
        );
    }
    
    /**
     * Get category with products (for admin view)
     */
    public function getCategoryWithProducts($id) {
        $category = $this->find($id);
        if (!$category) {
            return null;
        }
        
        // Get product count
        $countResult = $this->query(
            "SELECT COUNT(*) as product_count 
             FROM products 
             WHERE category_id = ?",
            [$id]
        );
        $category['product_count'] = $countResult[0]['product_count'] ?? 0;
        
        // Get products in this category
        $category['products'] = $this->query(
            "SELECT product_id, product_name, image, price, stock_quantity, status 
             FROM products 
             WHERE category_id = ?
             ORDER BY product_name ASC",
            [$id]
        );
        
        return $category;
    }
}


