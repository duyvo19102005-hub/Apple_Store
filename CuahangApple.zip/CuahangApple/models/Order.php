<?php
require_once __DIR__ . '/../core/Model.php';

/**
 * Order Model
 */
class Order extends Model {
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    
    /**
     * Create new order
     */
    public function createOrder($userId, $orderData, $cartItems) {
        try {
            $this->beginTransaction();
            
            // Generate order number
            $orderNumber = 'ORD' . date('Ymd') . sprintf('%06d', rand(1, 999999));
            
            // Calculate totals
            $totalAmount = 0;
            $discountAmount = 0;
            
            foreach ($cartItems as $item) {
                $itemPrice = $item['price'] * $item['quantity'];
                $totalAmount += $itemPrice;
                
                if ($item['discount_percent'] > 0) {
                    $discountAmount += $itemPrice * ($item['discount_percent'] / 100);
                }
            }
            
            $finalAmount = $totalAmount - $discountAmount;
            
            // Create order
            $orderId = $this->create([
                'user_id' => $userId,
                'order_number' => $orderNumber,
                'total_amount' => $totalAmount,
                'discount_amount' => $discountAmount,
                'final_amount' => $finalAmount,
                'shipping_address' => $orderData['shipping_address'],
                'phone' => $orderData['phone'],
                'payment_method' => $orderData['payment_method'] ?? 'cod',
                'notes' => $orderData['notes'] ?? ''
            ]);
            
            // Create order items
            foreach ($cartItems as $item) {
                $price = $item['price'];
                $subtotal = $price * $item['quantity'];
                
                if ($item['discount_percent'] > 0) {
                    $subtotal = $subtotal * (1 - $item['discount_percent'] / 100);
                }
                
                $this->query(
                    "INSERT INTO order_items (order_id, product_id, product_name, price, discount_percent, quantity, subtotal)
                     VALUES (?, ?, ?, ?, ?, ?, ?)",
                    [
                        $orderId,
                        $item['product_id'],
                        $item['product_name'],
                        $price,
                        $item['discount_percent'],
                        $item['quantity'],
                        $subtotal
                    ]
                );
                
                // Update product stock
                $this->query(
                    "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?",
                    [$item['quantity'], $item['product_id']]
                );
            }
            
            // Clear cart
            $this->query("DELETE FROM cart WHERE user_id = ?", [$userId]);
            
            $this->commit();
            
            return [
                'success' => true,
                'order_id' => $orderId,
                'order_number' => $orderNumber
            ];
            
        } catch (Exception $e) {
            $this->rollback();
            return [
                'success' => false,
                'message' => 'Có lỗi xảy ra khi tạo đơn hàng: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Get orders by user
     */
    public function getOrdersByUser($userId, $limit = null, $offset = 0) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE user_id = ? 
                ORDER BY created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            return $this->query($sql, [$userId, $limit, $offset]);
        }
        
        return $this->query($sql, [$userId]);
    }
    
    /**
     * Get order details
     */
    public function getOrderDetails($orderId) {
        $order = $this->find($orderId);
        
        if ($order) {
            $order['items'] = $this->query(
                "SELECT oi.*, p.image 
                 FROM order_items oi
                 LEFT JOIN products p ON oi.product_id = p.product_id
                 WHERE oi.order_id = ?",
                [$orderId]
            );
        }
        
        return $order;
    }
    
    /**
     * Get order by number
     */
    public function getOrderByNumber($orderNumber) {
        return $this->findWhere('order_number', $orderNumber);
    }
    
    /**
     * Update order status
     */
    public function updateOrderStatus($orderId, $status) {
        return $this->update($orderId, ['order_status' => $status]);
    }
    
    /**
     * Update payment status
     */
    public function updatePaymentStatus($orderId, $status) {
        return $this->update($orderId, ['payment_status' => $status]);
    }
    
    /**
     * Cancel order
     */
    public function cancelOrder($orderId) {
        try {
            $this->beginTransaction();
            
            // Get order items
            $items = $this->query(
                "SELECT product_id, quantity FROM order_items WHERE order_id = ?",
                [$orderId]
            );
            
            // Restore stock
            foreach ($items as $item) {
                $this->query(
                    "UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?",
                    [$item['quantity'], $item['product_id']]
                );
            }
            
            // Update order status
            $this->update($orderId, ['order_status' => 'cancelled']);
            
            $this->commit();
            return true;
            
        } catch (Exception $e) {
            $this->rollback();
            return false;
        }
    }
    
    /**
     * Get all orders (admin)
     */
    public function getAllOrders($limit = 50, $offset = 0, $status = null) {
        $sql = "SELECT o.*, u.full_name, u.email 
                FROM {$this->table} o
                LEFT JOIN users u ON o.user_id = u.user_id";
        
        $params = [];
        
        if ($status) {
            $sql .= " WHERE o.order_status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        return $this->query($sql, $params);
    }
    
    /**
     * Get order statistics
     */
    public function getStatistics() {
        return [
            'total_orders' => $this->count(),
            'pending_orders' => $this->count("order_status = 'pending'"),
            'completed_orders' => $this->count("order_status = 'delivered'"),
            'cancelled_orders' => $this->count("order_status = 'cancelled'"),
            'total_revenue' => $this->getTotalRevenue()
        ];
    }
    
    /**
     * Get total revenue
     */
    public function getTotalRevenue() {
        $result = $this->queryOne(
            "SELECT SUM(final_amount) as revenue 
             FROM {$this->table} 
             WHERE order_status != 'cancelled' AND payment_status = 'paid'"
        );
        return $result['revenue'] ?? 0;
    }
}


