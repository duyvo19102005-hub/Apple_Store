<?php
require_once __DIR__ . '/../core/Model.php';

/**
 * Cart Model
 */
class Cart extends Model {
    protected $table = 'cart';
    protected $primaryKey = 'cart_id';
    
    /**
     * Get cart items for user
     */
    public function getCartItems($userId) {
        return $this->query(
            "SELECT c.*, p.product_name, p.price, p.discount_percent, p.image, p.stock_quantity
             FROM {$this->table} c
             INNER JOIN products p ON c.product_id = p.product_id
             WHERE c.user_id = ? AND p.status = 'active'
             ORDER BY c.added_at DESC",
            [$userId]
        );
    }
    
    /**
     * Add item to cart
     */
    public function addItem($userId, $productId, $quantity = 1) {
        // Check if item already exists
        $existing = $this->queryOne(
            "SELECT * FROM {$this->table} WHERE user_id = ? AND product_id = ?",
            [$userId, $productId]
        );
        
        if ($existing) {
            // Update quantity
            return $this->query(
                "UPDATE {$this->table} SET quantity = quantity + ? 
                 WHERE user_id = ? AND product_id = ?",
                [$quantity, $userId, $productId]
            );
        } else {
            // Insert new item
            return $this->create([
                'user_id' => $userId,
                'product_id' => $productId,
                'quantity' => $quantity
            ]);
        }
    }
    
    /**
     * Update cart item quantity
     */
    public function updateQuantity($userId, $productId, $quantity) {
        if ($quantity <= 0) {
            return $this->removeItem($userId, $productId);
        }
        
        return $this->query(
            "UPDATE {$this->table} SET quantity = ? 
             WHERE user_id = ? AND product_id = ?",
            [$quantity, $userId, $productId]
        );
    }
    
    /**
     * Remove item from cart
     */
    public function removeItem($userId, $productId) {
        return $this->query(
            "DELETE FROM {$this->table} WHERE user_id = ? AND product_id = ?",
            [$userId, $productId]
        );
    }
    
    /**
     * Clear cart for user
     */
    public function clearCart($userId) {
        return $this->query(
            "DELETE FROM {$this->table} WHERE user_id = ?",
            [$userId]
        );
    }
    
    /**
     * Get cart count
     */
    public function getCartCount($userId) {
        $result = $this->queryOne(
            "SELECT SUM(quantity) as count FROM {$this->table} WHERE user_id = ?",
            [$userId]
        );
        return $result['count'] ?? 0;
    }
    
    /**
     * Calculate cart total
     */
    public function getCartTotal($userId) {
        $items = $this->getCartItems($userId);
        $total = 0;
        
        foreach ($items as $item) {
            $price = $item['price'];
            if ($item['discount_percent'] > 0) {
                $price = $price * (1 - $item['discount_percent'] / 100);
            }
            $total += $price * $item['quantity'];
        }
        
        return $total;
    }
    
    /**
     * Validate cart items
     */
    public function validateCart($userId) {
        $items = $this->getCartItems($userId);
        $errors = [];
        
        foreach ($items as $item) {
            if ($item['stock_quantity'] < $item['quantity']) {
                $errors[] = "Sản phẩm {$item['product_name']} chỉ còn {$item['stock_quantity']} sản phẩm";
            }
        }
        
        return $errors;
    }
}


