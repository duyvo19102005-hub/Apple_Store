<?php
/**
 * Base Controller Class
 * All controllers extend this class
 */
abstract class Controller {
    
    /**
     * Load view file
     */
    protected function view($view, $data = []) {
        extract($data);
        $viewPath = ROOT_PATH . "/views/{$view}.php";
        
        if (file_exists($viewPath)) {
            require_once $viewPath;
        } else {
            die("View not found: {$view}");
        }
    }
    
    /**
     * Load model
     */
    protected function model($model) {
        $modelPath = ROOT_PATH . "/models/{$model}.php";
        
        if (file_exists($modelPath)) {
            require_once $modelPath;
            return new $model();
        } else {
            die("Model not found: {$model}");
        }
    }
    
    /**
     * Redirect to URL
     */
    protected function redirect($url) {
        // If URL already contains http:// or https://, use it as is
        if (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) {
            header("Location: " . $url);
        } else {
            // Otherwise, prepend BASE_URL
            header("Location: " . BASE_URL . $url);
        }
        exit;
    }
    
    /**
     * Return JSON response
     */
    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Get request method
     */
    protected function getMethod() {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    /**
     * Get POST data
     */
    protected function getPost($key = null, $default = null) {
        if ($key === null) {
            return $_POST;
        }
        return isset($_POST[$key]) ? $_POST[$key] : $default;
    }
    
    /**
     * Get GET data
     */
    protected function getGet($key = null, $default = null) {
        if ($key === null) {
            return $_GET;
        }
        return isset($_GET[$key]) ? $_GET[$key] : $default;
    }
    
    /**
     * Get request input (works with JSON too)
     */
    protected function getInput() {
        $contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        
        if (strpos($contentType, 'application/json') !== false) {
            return json_decode(file_get_contents('php://input'), true);
        }
        
        return $_POST;
    }
    
    /**
     * Check if user is logged in
     */
    protected function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    /**
     * Check if user is admin
     */
    protected function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
    
    /**
     * Require login
     */
    protected function requireLogin() {
        if (!$this->isLoggedIn()) {
            $this->redirect('index.php?navigate=login');
        }
    }
    
    /**
     * Require admin
     */
    protected function requireAdmin() {
        if (!$this->isLoggedIn()) {
            $_SESSION['errors'] = ['Vui lòng đăng nhập để truy cập trang này'];
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            $this->redirect('index.php?navigate=login');
        }
        
        if (!$this->isAdmin()) {
            $_SESSION['errors'] = ['Bạn không có quyền truy cập trang quản trị'];
            $this->redirect('index.php');
        }
    }
    
    /**
     * Validate CSRF token
     */
    protected function validateCSRF($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Generate CSRF token
     */
    protected function generateCSRF() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}


