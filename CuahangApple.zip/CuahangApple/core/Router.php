<?php
/**
 * Router Class - OOP Router
 * Chuyển switch-case router sang OOP
 */
class Router {
    private $routes = [];
    private $currentRoute;
    
    /**
     * Register a route
     */
    public function register($navigate, $controller, $method = 'index') {
        $this->routes[$navigate] = [
            'controller' => $controller,
            'method' => $method
        ];
    }
    
    /**
     * Dispatch current request
     */
    public function dispatch() {
        $navigate = $_GET['navigate'] ?? 'home';
        
        if (!isset($this->routes[$navigate])) {
            $navigate = 'home';
        }
        
        $route = $this->routes[$navigate];
        $controllerName = $route['controller'];
        $method = $route['method'];
        
        try {
            $controller = new $controllerName();
            
            if (method_exists($controller, $method)) {
                $controller->$method();
            } else {
                throw new Exception("Method {$method} not found in {$controllerName}");
            }
        } catch (Exception $e) {
            error_log($e->getMessage());
            $_SESSION['errors'] = ['Có lỗi xảy ra: ' . $e->getMessage()];
            $controller = new HomeController();
            $controller->index();
        }
    }
    
    /**
     * Register all application routes
     */
    public function registerRoutes() {
        // Home
        $this->register('home', 'HomeController', 'index');
        
        // Authentication
        $this->register('login', 'AuthController', 'login');
        $this->register('process_login', 'AuthController', 'processLogin');
        $this->register('signup', 'AuthController', 'signup');
        $this->register('process_signup', 'AuthController', 'processSignup');
        $this->register('logout', 'AuthController', 'logout');
        
        // Products
        $this->register('search1', 'ProductController', 'search');
        $this->register('products', 'ProductController', 'search');
        $this->register('product_info', 'ProductController', 'detail');
        $this->register('product_detail', 'ProductController', 'detail');
        
        // Cart
        $this->register('cart', 'CartController', 'index');
        $this->register('cart_add', 'CartController', 'add');
        $this->register('cart_update', 'CartController', 'update');
        $this->register('cart_remove', 'CartController', 'remove');
        $this->register('cart_clear', 'CartController', 'clear');
        
        // Orders
        $this->register('checkout', 'OrderController', 'checkout');
        $this->register('process_checkout', 'OrderController', 'processCheckout');
        $this->register('my_orders', 'OrderController', 'myOrders');
        $this->register('order_detail', 'OrderController', 'detail');
        $this->register('order_cancel', 'OrderController', 'cancel');
    }
}


