<?php
/**
 * Authentication Helper Class
 */
class Auth {
    
    /**
     * Check if user is logged in
     */
    public static function check() {
        return isset($_SESSION['user_id']);
    }
    
    /**
     * Get logged in user ID
     */
    public static function id() {
        return $_SESSION['user_id'] ?? null;
    }
    
    /**
     * Get logged in user data
     */
    public static function user() {
        if (!self::check()) {
            return null;
        }
        
        return [
            'user_id' => $_SESSION['user_id'] ?? null,
            'username' => $_SESSION['username'] ?? null,
            'email' => $_SESSION['email'] ?? null,
            'full_name' => $_SESSION['full_name'] ?? null,
            'role' => $_SESSION['role'] ?? null
        ];
    }
    
    /**
     * Check if user is admin
     */
    public static function isAdmin() {
        return self::check() && $_SESSION['role'] === 'admin';
    }
    
    /**
     * Check if user is customer
     */
    public static function isCustomer() {
        return self::check() && $_SESSION['role'] === 'customer';
    }
    
    /**
     * Require login
     */
    public static function requireLogin() {
        if (!self::check()) {
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            redirect('index.php?navigate=login');
        }
    }
    
    /**
     * Require admin
     */
    public static function requireAdmin() {
        if (!self::check()) {
            $_SESSION['errors'] = ['Vui lòng đăng nhập để truy cập trang này'];
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            redirect('index.php?navigate=login');
        }
        
        if (!self::isAdmin()) {
            $_SESSION['errors'] = ['Bạn không có quyền truy cập trang quản trị'];
            redirect('index.php');
        }
    }
    
    /**
     * Require customer (block admin from customer pages if needed)
     */
    public static function requireCustomer() {
        if (!self::check()) {
            $_SESSION['errors'] = ['Vui lòng đăng nhập để truy cập trang này'];
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            redirect('index.php?navigate=login');
        }
        
        if (!self::isCustomer()) {
            // Admin can access customer pages, but we can restrict if needed
            // For now, allow admin to access customer pages
            return true;
        }
    }
    
    /**
     * Check if user can access admin panel
     */
    public static function canAccessAdmin() {
        return self::isAdmin();
    }
    
    /**
     * Get user role
     */
    public static function role() {
        return $_SESSION['role'] ?? null;
    }
    
    /**
     * Generate CSRF token
     */
    public static function generateCSRF() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * Verify CSRF token
     */
    public static function verifyCSRF($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Get CSRF field
     */
    public static function csrfField() {
        $token = self::generateCSRF();
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }
}


