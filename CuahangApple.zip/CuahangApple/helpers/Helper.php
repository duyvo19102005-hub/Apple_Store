<?php
/**
 * Helper Class - OOP Version
 * Chuyển tất cả functions sang static methods
 */
if (!class_exists('Helper')) {
    class Helper {
        
        /**
         * Format currency (VND)
         */
    public static function formatCurrency($amount) {
        if ($amount === null) {
            $amount = 0;
        }
        return number_format($amount, 0, ',', '.') . 'đ';
    }
    
    /**
     * Format date
     */
    public static function formatDate($date, $format = 'd/m/Y H:i') {
        return date($format, strtotime($date));
    }
    
    /**
     * Sanitize input
     */
    public static function sanitize($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Escape output
     */
    public static function e($string) {
        if ($string === null) {
            return '';
        }
        return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Redirect
     */
    public static function redirect($url) {
        // If URL already contains http:// or https://, use it as is
        if (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) {
            header("Location: " . $url);
        } else {
            // Otherwise, prepend BASE_URL
            header("Location: " . BASE_URL . $url);
        }
        exit;
    }
    
    /**
     * Get asset URL
     */
    public static function asset($path) {
        return ASSETS_PATH . $path;
    }
    
    /**
     * Get product image URL
     */
    public static function getProductImage($imageName) {
        if (empty($imageName)) {
            return ASSETS_PATH . 'images/products/image.png'; // default image
        }
        // If already a full URL, return as is
        if (strpos($imageName, 'http') === 0) {
            return $imageName;
        }
        // If already has assets path, return as is
        if (strpos($imageName, 'assets/') === 0) {
            return BASE_URL . $imageName;
        }
        // Otherwise, prepend the products path
        return ASSETS_PATH . 'images/products/' . $imageName;
    }
    
    /**
     * Generate random string
     */
    public static function generateRandomString($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    /**
     * Calculate discount price
     */
    public static function getDiscountedPrice($price, $discountPercent) {
        if ($discountPercent > 0) {
            return $price * (1 - $discountPercent / 100);
        }
        return $price;
    }
    
    /**
     * Get order status text
     */
    public static function getOrderStatus($status) {
        $statuses = [
            'pending' => 'Chờ xác nhận',
            'confirmed' => 'Đã xác nhận',
            'processing' => 'Đang xử lý',
            'shipping' => 'Đang giao hàng',
            'delivered' => 'Đã giao hàng',
            'cancelled' => 'Đã hủy'
        ];
        return $statuses[$status] ?? $status;
    }
    
    /**
     * Get payment status text
     */
    public static function getPaymentStatus($status) {
        $statuses = [
            'pending' => 'Chưa thanh toán',
            'paid' => 'Đã thanh toán',
            'failed' => 'Thanh toán thất bại'
        ];
        return $statuses[$status] ?? $status;
    }
    
    /**
     * Get payment method text
     */
    public static function getPaymentMethod($method) {
        $methods = [
            'cod' => 'Thanh toán khi nhận hàng',
            'bank_transfer' => 'Chuyển khoản ngân hàng',
            'momo' => 'Ví MoMo',
            'vnpay' => 'VNPay'
        ];
        return $methods[$method] ?? $method;
    }
    
    /**
     * Truncate string
     */
    public static function truncate($string, $length = 100, $append = '...') {
        if (strlen($string) > $length) {
            return substr($string, 0, $length) . $append;
        }
        return $string;
    }
    }
}

// Backward compatibility - Global functions that call static methods
if (!function_exists('formatCurrency')) {
    function formatCurrency($amount) { return Helper::formatCurrency($amount); }
}
if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd/m/Y H:i') { return Helper::formatDate($date, $format); }
}
if (!function_exists('sanitize')) {
    function sanitize($input) { return Helper::sanitize($input); }
}
if (!function_exists('e')) {
    function e($string) { return Helper::e($string); }
}
if (!function_exists('redirect')) {
    function redirect($url) { return Helper::redirect($url); }
}
if (!function_exists('asset')) {
    function asset($path) { return Helper::asset($path); }
}
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 32) { return Helper::generateRandomString($length); }
}
if (!function_exists('getDiscountedPrice')) {
    function getDiscountedPrice($price, $discountPercent) { return Helper::getDiscountedPrice($price, $discountPercent); }
}
if (!function_exists('getOrderStatus')) {
    function getOrderStatus($status) { return Helper::getOrderStatus($status); }
}
if (!function_exists('getPaymentStatus')) {
    function getPaymentStatus($status) { return Helper::getPaymentStatus($status); }
}
if (!function_exists('getPaymentMethod')) {
    function getPaymentMethod($method) { return Helper::getPaymentMethod($method); }
}
if (!function_exists('truncate')) {
    function truncate($string, $length = 100, $append = '...') { return Helper::truncate($string, $length, $append); }
}

/**
 * Upload file
 */
if (!function_exists('uploadFile')) {
    function uploadFile($file, $destination, $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp']) {
        if (!isset($file['name']) || empty($file['name'])) {
            return ['success' => false, 'message' => 'Không có file nào được chọn'];
        }
        
        $fileName = basename($file['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        // Check file type
        if (!in_array($fileExt, $allowedTypes)) {
            return ['success' => false, 'message' => 'Định dạng file không được phép'];
        }
        
        // Check file size (5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            return ['success' => false, 'message' => 'File quá lớn (tối đa 5MB)'];
        }
        
        // Generate unique filename
        $newFileName = uniqid() . '_' . time() . '.' . $fileExt;
        $targetPath = $destination . '/' . $newFileName;
        
        // Create directory if not exists
        if (!is_dir($destination)) {
            mkdir($destination, 0755, true);
        }
        
        // Move file
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => true, 'filename' => $newFileName];
        }
        
        return ['success' => false, 'message' => 'Lỗi khi upload file'];
    }
}

/**
 * Delete file
 */
if (!function_exists('deleteFile')) {
    function deleteFile($filePath) {
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return false;
    }
}

/**
 * Generate slug
 */
if (!function_exists('generateSlug')) {
    function generateSlug($string) {
        $string = mb_strtolower($string, 'UTF-8');
        
        // Vietnamese characters
        $vietnamese = [
            'à', 'á', 'ạ', 'ả', 'ã', 'â', 'ầ', 'ấ', 'ậ', 'ẩ', 'ẫ', 'ă', 'ằ', 'ắ', 'ặ', 'ẳ', 'ẵ',
            'è', 'é', 'ẹ', 'ẻ', 'ẽ', 'ê', 'ề', 'ế', 'ệ', 'ể', 'ễ',
            'ì', 'í', 'ị', 'ỉ', 'ĩ',
            'ò', 'ó', 'ọ', 'ỏ', 'õ', 'ô', 'ồ', 'ố', 'ộ', 'ổ', 'ỗ', 'ơ', 'ờ', 'ớ', 'ợ', 'ở', 'ỡ',
            'ù', 'ú', 'ụ', 'ủ', 'ũ', 'ư', 'ừ', 'ứ', 'ự', 'ử', 'ữ',
            'ỳ', 'ý', 'ỵ', 'ỷ', 'ỹ',
            'đ'
        ];
        
        $latin = [
            'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a',
            'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e',
            'i', 'i', 'i', 'i', 'i',
            'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o',
            'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u',
            'y', 'y', 'y', 'y', 'y',
            'd'
        ];
        
        $string = str_replace($vietnamese, $latin, $string);
        $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
        $string = preg_replace('/[\s-]+/', '-', $string);
        $string = trim($string, '-');
        
        return $string;
    }
}

/**
 * Get product image URL - helper function
 */
if (!function_exists('getProductImage')) {
    function getProductImage($imageName) {
        return Helper::getProductImage($imageName);
    }
}
