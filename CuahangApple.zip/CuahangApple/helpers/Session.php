<?php
/**
 * Session Helper Class
 */
class Session {
    
    /**
     * Start session
     */
    public static function start() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    /**
     * Set session value
     */
    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }
    
    /**
     * Get session value
     */
    public static function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * Check if session key exists
     */
    public static function has($key) {
        return isset($_SESSION[$key]);
    }
    
    /**
     * Remove session key
     */
    public static function remove($key) {
        if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
    }
    
    /**
     * Destroy session
     */
    public static function destroy() {
        session_unset();
        session_destroy();
    }
    
    /**
     * Flash message (one-time message)
     */
    public static function flash($key, $value = null) {
        if ($value === null) {
            $value = self::get($key);
            self::remove($key);
            return $value;
        }
        self::set($key, $value);
    }
    
    /**
     * Get and display flash messages
     */
    public static function displayFlash($type = 'success') {
        $message = self::flash($type);
        if ($message) {
            $alertClass = $type === 'success' ? 'alert-success' : 'alert-danger';
            return "<div class='alert {$alertClass} alert-dismissible fade show' role='alert'>
                        {$message}
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                        </button>
                    </div>";
        }
        return '';
    }
}


