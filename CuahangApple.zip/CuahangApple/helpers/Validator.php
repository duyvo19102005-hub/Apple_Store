<?php
/**
 * Validation Helper Class
 */
class Validator {
    
    private $data = [];
    private $errors = [];
    private $rules = [];
    
    public function __construct($data) {
        $this->data = $data;
    }
    
    /**
     * Add validation rule
     */
    public function rule($field, $rules) {
        $this->rules[$field] = explode('|', $rules);
        return $this;
    }
    
    /**
     * Validate data
     */
    public function validate() {
        foreach ($this->rules as $field => $rules) {
            $value = $this->data[$field] ?? null;
            
            foreach ($rules as $rule) {
                $this->applyRule($field, $value, $rule);
            }
        }
        
        return empty($this->errors);
    }
    
    /**
     * Apply validation rule
     */
    private function applyRule($field, $value, $rule) {
        if (strpos($rule, ':') !== false) {
            list($rule, $param) = explode(':', $rule);
        } else {
            $param = null;
        }
        
        switch ($rule) {
            case 'required':
                if (empty($value)) {
                    $this->addError($field, 'Trường này không được để trống');
                }
                break;
                
            case 'email':
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->addError($field, 'Email không hợp lệ');
                }
                break;
                
            case 'min':
                if (strlen($value) < $param) {
                    $this->addError($field, "Tối thiểu {$param} ký tự");
                }
                break;
                
            case 'max':
                if (strlen($value) > $param) {
                    $this->addError($field, "Tối đa {$param} ký tự");
                }
                break;
                
            case 'numeric':
                if (!is_numeric($value)) {
                    $this->addError($field, 'Phải là số');
                }
                break;
                
            case 'alpha':
                if (!ctype_alpha($value)) {
                    $this->addError($field, 'Chỉ chứa chữ cái');
                }
                break;
                
            case 'alphanumeric':
                if (!ctype_alnum($value)) {
                    $this->addError($field, 'Chỉ chứa chữ và số');
                }
                break;
                
            case 'phone':
                if (!preg_match('/^[0-9]{10,11}$/', $value)) {
                    $this->addError($field, 'Số điện thoại không hợp lệ');
                }
                break;
                
            case 'url':
                if (!filter_var($value, FILTER_VALIDATE_URL)) {
                    $this->addError($field, 'URL không hợp lệ');
                }
                break;
        }
    }
    
    /**
     * Add error
     */
    private function addError($field, $message) {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }
    
    /**
     * Get errors
     */
    public function errors() {
        return $this->errors;
    }
    
    /**
     * Get first error for field
     */
    public function first($field) {
        return $this->errors[$field][0] ?? null;
    }
}


