<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

/**
 * Home Controller
 */
class HomeController extends Controller {
    
    public function index() {
        $productModel = new Product();
        $categoryModel = new Category();
        
        // Get featured products
        $featuredProducts = $productModel->getFeaturedProducts(FEATURED_PRODUCTS_LIMIT);
        
        // Get popular categories
        $popularCategories = $categoryModel->getCategoriesWithCount();
        
        // Get all categories for navigation
        $categories = $categoryModel->getActiveCategories();
        
        // Get latest products
        $latestProducts = $productModel->getAllProducts(6);
        
        $data = [
            'title' => 'Trang chủ - ' . APP_NAME,
            'featuredProducts' => $featuredProducts,
            'popularCategories' => $popularCategories,
            'categories' => $categories,
            'latestProducts' => $latestProducts
        ];
        
        $this->view('home', $data);
    }
}


