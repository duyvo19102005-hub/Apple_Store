<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

/**
 * Product Controller
 */
class ProductController extends Controller {
    
    /**
     * Product listing/search page with advanced filters
     */
    public function search() {
        $productModel = new Product();
        $categoryModel = new Category();
        
        // Get search parameters
        $keyword = $this->getGet('search', '');
        $categoryId = $this->getGet('category_id', 0);
        $priceRange = $this->getGet('price_range', '');
        $status = $this->getGet('status', '');
        $sortBy = $this->getGet('sort', 'name_asc');
        $page = max(1, (int)$this->getGet('page', 1));
        $offset = ($page - 1) * ITEMS_PER_PAGE;
        
        // Build filter array
        $filters = [
            'keyword' => $keyword,
            'category_id' => $categoryId,
            'price_range' => $priceRange,
            'status' => $status,
            'sort' => $sortBy
        ];
        
        // Get filtered products
        $products = $productModel->searchWithFilters($filters, ITEMS_PER_PAGE, $offset);
        $totalProducts = $productModel->countWithFilters($filters);
        
        // Get categories
        $categories = $categoryModel->getCategoriesWithCount();
        
        // Define price ranges
        $priceRanges = [
            '' => 'Tất cả giá',
            '0-10000000' => 'Dưới 10 triệu',
            '10000000-20000000' => '10 - 20 triệu',
            '20000000-30000000' => '20 - 30 triệu',
            '30000000-999999999' => 'Trên 30 triệu'
        ];
        
        // Define status options
        $statusOptions = [
            '' => 'Tất cả trạng thái',
            'in_stock' => 'Còn hàng',
            'featured' => 'Nổi bật'
        ];
        
        // Define sort options
        $sortOptions = [
            'name_asc' => 'Tên A-Z',
            'name_desc' => 'Tên Z-A',
            'price_asc' => 'Giá thấp đến cao',
            'price_desc' => 'Giá cao đến thấp',
            'newest' => 'Mới nhất',
            'popular' => 'Phổ biến'
        ];
        
        // Calculate pagination
        $totalPages = ceil($totalProducts / ITEMS_PER_PAGE);
        
        $data = [
            'title' => 'Sản phẩm - ' . APP_NAME,
            'products' => $products,
            'categories' => $categories,
            'priceRanges' => $priceRanges,
            'statusOptions' => $statusOptions,
            'sortOptions' => $sortOptions,
            'filters' => $filters,
            'keyword' => $keyword,
            'categoryId' => $categoryId,
            'priceRange' => $priceRange,
            'status' => $status,
            'sortBy' => $sortBy,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalProducts' => $totalProducts
        ];
        
        $this->view('product/search', $data);
    }
    
    /**
     * Product detail page
     */
    public function detail() {
        $productId = $this->getGet('product_id');
        
        if (!$productId) {
            $this->redirect('index.php');
        }
        
        $productModel = new Product();
        $product = $productModel->getProductDetails($productId);
        
        if (!$product) {
            $_SESSION['errors'] = ['Sản phẩm không tồn tại'];
            $this->redirect('index.php');
        }
        
        // Get related products
        $relatedProducts = $productModel->getRelatedProducts(
            $product['product_id'],
            $product['category_id'],
            4
        );
        
        $data = [
            'title' => $product['product_name'] . ' - ' . APP_NAME,
            'product' => $product,
            'relatedProducts' => $relatedProducts
        ];
        
        $this->view('product/detail', $data);
    }
}


