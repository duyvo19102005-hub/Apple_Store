<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Product.php';

/**
 * Cart Controller
 */
class CartController extends Controller {
    
    /**
     * View cart
     */
    public function index() {
        $this->requireLogin();
        
        $cartModel = new Cart();
        $userId = $_SESSION['user_id'];
        
        $cartItems = $cartModel->getCartItems($userId);
        $cartTotal = $cartModel->getCartTotal($userId);
        
        $data = [
            'title' => 'Giỏ hàng - ' . APP_NAME,
            'cartItems' => $cartItems,
            'cartTotal' => $cartTotal
        ];
        
        $this->view('cart/index', $data);
    }
    
    /**
     * Add to cart
     */
    public function add() {
        $this->requireLogin();
        
        $productId = $this->getPost('product_id');
        $quantity = (int)$this->getPost('quantity', 1);
        $buyNow = $this->getPost('buy_now'); // Check if this is "Buy Now" action
        
        if (!$productId || $quantity < 1) {
            $_SESSION['errors'] = ['Dữ liệu không hợp lệ'];
            $this->redirect('index.php');
        }
        
        // Check stock
        $productModel = new Product();
        if (!$productModel->checkStock($productId, $quantity)) {
            $_SESSION['errors'] = ['Sản phẩm không đủ số lượng trong kho'];
            $this->redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
        }
        
        $cartModel = new Cart();
        $result = $cartModel->addItem($_SESSION['user_id'], $productId, $quantity);
        
        if ($result) {
            $_SESSION['success'] = 'Đã thêm sản phẩm vào giỏ hàng';
            
            // If "Buy Now", redirect to checkout; otherwise go to cart
            if ($buyNow) {
                $this->redirect('index.php?navigate=checkout');
            } else {
                $this->redirect('index.php?navigate=cart');
            }
        } else {
            $_SESSION['errors'] = ['Có lỗi xảy ra, vui lòng thử lại'];
            $this->redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
        }
    }
    
    /**
     * Update cart quantity
     */
    public function update() {
        $this->requireLogin();
        
        $productId = $this->getPost('product_id');
        $quantity = (int)$this->getPost('quantity');
        
        if (!$productId) {
            $_SESSION['errors'] = ['Dữ liệu không hợp lệ'];
            $this->redirect('index.php?navigate=cart');
        }
        
        $cartModel = new Cart();
        $result = $cartModel->updateQuantity($_SESSION['user_id'], $productId, $quantity);
        
        if ($result) {
            $_SESSION['success'] = 'Đã cập nhật giỏ hàng';
        } else {
            $_SESSION['errors'] = ['Có lỗi xảy ra'];
        }
        
        $this->redirect('index.php?navigate=cart');
    }
    
    /**
     * Remove from cart
     */
    public function remove() {
        $this->requireLogin();
        
        $productId = $this->getGet('product_id');
        
        if (!$productId) {
            $_SESSION['errors'] = ['Dữ liệu không hợp lệ'];
            $this->redirect('index.php?navigate=cart');
        }
        
        $cartModel = new Cart();
        $result = $cartModel->removeItem($_SESSION['user_id'], $productId);
        
        if ($result) {
            $_SESSION['success'] = 'Đã xóa sản phẩm khỏi giỏ hàng';
        } else {
            $_SESSION['errors'] = ['Có lỗi xảy ra'];
        }
        
        $this->redirect('index.php?navigate=cart');
    }
    
    /**
     * Clear cart
     */
    public function clear() {
        $this->requireLogin();
        
        $cartModel = new Cart();
        $result = $cartModel->clearCart($_SESSION['user_id']);
        
        if ($result) {
            $_SESSION['success'] = 'Đã xóa tất cả sản phẩm trong giỏ hàng';
        }
        
        $this->redirect('index.php?navigate=cart');
    }
}


