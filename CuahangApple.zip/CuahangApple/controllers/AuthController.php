<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/User.php';

/**
 * Authentication Controller
 */
class AuthController extends Controller {
    
    /**
     * Show login page
     */
    public function login() {
        if ($this->isLoggedIn()) {
            $this->redirect('index.php');
        }
        
        $this->view('auth/login', ['title' => 'Đăng nhập']);
    }
    
    /**
     * Process login
     */
    public function processLogin() {
        if ($this->getMethod() !== 'POST') {
            $this->redirect('index.php?navigate=login');
        }
        
        $email = $this->getPost('email');
        $password = $this->getPost('password');
        
        // Validate
        $errors = [];
        if (empty($email)) {
            $errors[] = 'Email không được để trống';
        }
        if (empty($password)) {
            $errors[] = 'Mật khẩu không được để trống';
        }
        
        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $this->redirect('index.php?navigate=login');
        }
        
        // Login
        $userModel = new User();
        $result = $userModel->login($email, $password);
        
        if ($result['success']) {
            $_SESSION['success'] = 'Đăng nhập thành công!';
            
            // Redirect to admin or home
            if ($result['user']['role'] === 'admin') {
                $this->redirect('admin/index.php');
            } else {
                $this->redirect('index.php');
            }
        } else {
            $_SESSION['errors'] = [$result['message']];
            $this->redirect('index.php?navigate=login');
        }
    }
    
    /**
     * Show signup page
     */
    public function signup() {
        if ($this->isLoggedIn()) {
            $this->redirect('index.php');
        }
        
        $this->view('auth/signup', ['title' => 'Đăng ký']);
    }
    
    /**
     * Process signup
     */
    public function processSignup() {
        if ($this->getMethod() !== 'POST') {
            $this->redirect('index.php?navigate=signup');
        }
        
        $username = $this->getPost('username');
        $email = $this->getPost('email');
        $password = $this->getPost('password');
        $confirmPassword = $this->getPost('confirm_password');
        $fullName = $this->getPost('full_name');
        $phone = $this->getPost('phone');
        
        // Validate
        $errors = [];
        
        if (empty($username)) {
            $errors[] = 'Tên đăng nhập không được để trống';
        }
        if (empty($email)) {
            $errors[] = 'Email không được để trống';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email không hợp lệ';
        }
        if (empty($password)) {
            $errors[] = 'Mật khẩu không được để trống';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Mật khẩu phải có ít nhất 6 ký tự';
        }
        if ($password !== $confirmPassword) {
            $errors[] = 'Mật khẩu xác nhận không khớp';
        }
        if (empty($fullName)) {
            $errors[] = 'Họ tên không được để trống';
        }
        
        // Check existing user
        $userModel = new User();
        if ($userModel->emailExists($email)) {
            $errors[] = 'Email đã được sử dụng';
        }
        if ($userModel->usernameExists($username)) {
            $errors[] = 'Tên đăng nhập đã được sử dụng';
        }
        
        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = $_POST;
            $this->redirect('index.php?navigate=signup');
        }
        
        // Register - Always set role as customer for security
        $userId = $userModel->register([
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'full_name' => $fullName,
            'phone' => $phone,
            'role' => 'customer', // Force customer role on registration
            'status' => 'active'
        ]);
        
        if ($userId) {
            $_SESSION['success'] = 'Đăng ký thành công! Vui lòng đăng nhập.';
            $this->redirect('index.php?navigate=login');
        } else {
            $_SESSION['errors'] = ['Có lỗi xảy ra, vui lòng thử lại'];
            $this->redirect('index.php?navigate=signup');
        }
    }
    
    /**
     * Logout
     */
    public function logout() {
        $userModel = new User();
        $userModel->logout();
        $this->redirect('index.php');
    }
}


