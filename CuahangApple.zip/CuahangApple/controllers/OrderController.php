<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/Cart.php';

/**
 * Order Controller
 */
class OrderController extends Controller {
    
    /**
     * Checkout page
     */
    public function checkout() {
        $this->requireLogin();
        
        $cartModel = new Cart();
        $userId = $_SESSION['user_id'];
        
        $cartItems = $cartModel->getCartItems($userId);
        
        if (empty($cartItems)) {
            $_SESSION['errors'] = ['Giỏ hàng trống'];
            $this->redirect('index.php');
        }
        
        // Validate cart
        $errors = $cartModel->validateCart($userId);
        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $this->redirect('index.php?navigate=cart');
        }
        
        $cartTotal = $cartModel->getCartTotal($userId);
        
        $data = [
            'title' => 'Thanh toán - ' . APP_NAME,
            'cartItems' => $cartItems,
            'cartTotal' => $cartTotal
        ];
        
        $this->view('order/checkout', $data);
    }
    
    /**
     * Process checkout
     */
    public function processCheckout() {
        $this->requireLogin();
        
        if ($this->getMethod() !== 'POST') {
            $this->redirect('index.php?navigate=checkout');
        }
        
        $shippingAddress = $this->getPost('shipping_address');
        $phone = $this->getPost('phone');
        $paymentMethod = $this->getPost('payment_method', 'cod');
        $notes = $this->getPost('notes', '');
        
        // Validate
        $errors = [];
        if (empty($shippingAddress)) {
            $errors[] = 'Địa chỉ giao hàng không được để trống';
        }
        if (empty($phone)) {
            $errors[] = 'Số điện thoại không được để trống';
        }
        
        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $this->redirect('index.php?navigate=checkout');
        }
        
        // Get cart items
        $cartModel = new Cart();
        $userId = $_SESSION['user_id'];
        $cartItems = $cartModel->getCartItems($userId);
        
        if (empty($cartItems)) {
            $_SESSION['errors'] = ['Giỏ hàng trống'];
            $this->redirect('index.php');
        }
        
        // Create order
        $orderModel = new Order();
        $result = $orderModel->createOrder($userId, [
            'shipping_address' => $shippingAddress,
            'phone' => $phone,
            'payment_method' => $paymentMethod,
            'notes' => $notes
        ], $cartItems);
        
        if ($result['success']) {
            $_SESSION['success'] = 'Đặt hàng thành công! Mã đơn hàng: ' . $result['order_number'];
            $this->redirect('index.php?navigate=order_detail&order_id=' . $result['order_id']);
        } else {
            $_SESSION['errors'] = [$result['message']];
            $this->redirect('index.php?navigate=checkout');
        }
    }
    
    /**
     * View orders
     */
    public function myOrders() {
        $this->requireLogin();
        
        $orderModel = new Order();
        $orders = $orderModel->getOrdersByUser($_SESSION['user_id']);
        
        $data = [
            'title' => 'Đơn hàng của tôi - ' . APP_NAME,
            'orders' => $orders
        ];
        
        $this->view('order/my_orders', $data);
    }
    
    /**
     * Order detail
     */
    public function detail() {
        $this->requireLogin();
        
        $orderId = $this->getGet('order_id');
        
        if (!$orderId) {
            $this->redirect('index.php?navigate=my_orders');
        }
        
        $orderModel = new Order();
        $order = $orderModel->getOrderDetails($orderId);
        
        if (!$order || $order['user_id'] != $_SESSION['user_id']) {
            $_SESSION['errors'] = ['Đơn hàng không tồn tại'];
            $this->redirect('index.php?navigate=my_orders');
        }
        
        $data = [
            'title' => 'Chi tiết đơn hàng - ' . APP_NAME,
            'order' => $order
        ];
        
        $this->view('order/detail', $data);
    }
    
    /**
     * Cancel order
     */
    public function cancel() {
        $this->requireLogin();
        
        $orderId = $this->getGet('order_id');
        
        if (!$orderId) {
            $this->redirect('index.php?navigate=my_orders');
        }
        
        $orderModel = new Order();
        $order = $orderModel->find($orderId);
        
        if (!$order || $order['user_id'] != $_SESSION['user_id']) {
            $_SESSION['errors'] = ['Đơn hàng không tồn tại'];
            $this->redirect('index.php?navigate=my_orders');
        }
        
        if ($order['order_status'] !== 'pending') {
            $_SESSION['errors'] = ['Không thể hủy đơn hàng này'];
            $this->redirect('index.php?navigate=order_detail&order_id=' . $orderId);
        }
        
        $result = $orderModel->cancelOrder($orderId);
        
        if ($result) {
            $_SESSION['success'] = 'Đã hủy đơn hàng thành công';
        } else {
            $_SESSION['errors'] = ['Có lỗi xảy ra'];
        }
        
        $this->redirect('index.php?navigate=order_detail&order_id=' . $orderId);
    }
}


